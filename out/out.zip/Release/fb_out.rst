                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : free open source ANSI-C Compiler
                              3 ; Version 3.1.4 #7479 (Mar 23 2012) (MINGW32)
                              4 ; This file was generated Mon Apr 16 21:21:44 2012
                              5 ;--------------------------------------------------------
                              6 	.module fb_out
                              7 	.optsdcc -mmcs51 --model-small
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _main
                             13 	.globl _watchdog_start
                             14 	.globl _watchdog_feed
                             15 	.globl _watchdog_init
                             16 	.globl _restart_app
                             17 	.globl _bus_return
                             18 	.globl _port_schalten
                             19 	.globl _delay_timer
                             20 	.globl _process_tel
                             21 	.globl _restart_hw
                             22 	.globl _send_obj_value
                             23 	.globl _P3_1
                             24 	.globl _P3_0
                             25 	.globl _P1_7
                             26 	.globl _P1_6
                             27 	.globl _P1_5
                             28 	.globl _P1_4
                             29 	.globl _P1_3
                             30 	.globl _P1_2
                             31 	.globl _P1_1
                             32 	.globl _P1_0
                             33 	.globl _P0_7
                             34 	.globl _P0_6
                             35 	.globl _P0_5
                             36 	.globl _P0_4
                             37 	.globl _P0_3
                             38 	.globl _P0_2
                             39 	.globl _P0_1
                             40 	.globl _P0_0
                             41 	.globl _I2CON_0
                             42 	.globl _I2CON_2
                             43 	.globl _I2CON_3
                             44 	.globl _I2CON_4
                             45 	.globl _I2CON_5
                             46 	.globl _I2CON_6
                             47 	.globl _SCON_7
                             48 	.globl _SCON_6
                             49 	.globl _SCON_5
                             50 	.globl _SCON_4
                             51 	.globl _SCON_3
                             52 	.globl _SCON_2
                             53 	.globl _SCON_1
                             54 	.globl _SCON_0
                             55 	.globl _IP0_0
                             56 	.globl _IP0_1
                             57 	.globl _IP0_2
                             58 	.globl _IP0_3
                             59 	.globl _IP0_4
                             60 	.globl _IP0_5
                             61 	.globl _IP0_6
                             62 	.globl _IP1_0
                             63 	.globl _IP1_1
                             64 	.globl _IP1_2
                             65 	.globl _IP1_6
                             66 	.globl _IEN1_0
                             67 	.globl _IEN1_1
                             68 	.globl _IEN1_2
                             69 	.globl _IEN0_0
                             70 	.globl _IEN0_1
                             71 	.globl _IEN0_2
                             72 	.globl _IEN0_3
                             73 	.globl _IEN0_4
                             74 	.globl _IEN0_5
                             75 	.globl _IEN0_6
                             76 	.globl _IEN0_7
                             77 	.globl _TCON_0
                             78 	.globl _TCON_1
                             79 	.globl _TCON_2
                             80 	.globl _TCON_3
                             81 	.globl _TCON_4
                             82 	.globl _TCON_5
                             83 	.globl _TCON_6
                             84 	.globl _TCON_7
                             85 	.globl _PSW_7
                             86 	.globl _PSW_6
                             87 	.globl _PSW_5
                             88 	.globl _PSW_4
                             89 	.globl _PSW_3
                             90 	.globl _PSW_2
                             91 	.globl _PSW_1
                             92 	.globl _PSW_0
                             93 	.globl _IEN1
                             94 	.globl _IP0H
                             95 	.globl _WFEED2
                             96 	.globl _WFEED1
                             97 	.globl _WDL
                             98 	.globl _WDCON
                             99 	.globl _TRIM
                            100 	.globl _TAMOD
                            101 	.globl _SSTAT
                            102 	.globl _RTCL
                            103 	.globl _RTCH
                            104 	.globl _RTCCON
                            105 	.globl _RSTSRC
                            106 	.globl _PT0AD
                            107 	.globl _PCONA
                            108 	.globl _P3M2
                            109 	.globl _P3M1
                            110 	.globl _P1M2
                            111 	.globl _P1M1
                            112 	.globl _P0M2
                            113 	.globl _P0M1
                            114 	.globl _KBPATN
                            115 	.globl _KBMASK
                            116 	.globl _KBCON
                            117 	.globl _IP1H
                            118 	.globl _IP1
                            119 	.globl _I2STAT
                            120 	.globl _I2SCLL
                            121 	.globl _I2SCLH
                            122 	.globl _I2DAT
                            123 	.globl _I2CON
                            124 	.globl _I2ADR
                            125 	.globl _FMDATA
                            126 	.globl _FMCON
                            127 	.globl _FMADRL
                            128 	.globl _FMADRH
                            129 	.globl _DIVM
                            130 	.globl _CMP2
                            131 	.globl _CMP1
                            132 	.globl _BRGCON
                            133 	.globl _BRGR1
                            134 	.globl _BRGR0
                            135 	.globl _SADEN
                            136 	.globl _SADDR
                            137 	.globl _AUXR1
                            138 	.globl _SBUF
                            139 	.globl _SCON
                            140 	.globl _IP0
                            141 	.globl _IEN0
                            142 	.globl _TH1
                            143 	.globl _TH0
                            144 	.globl _TL1
                            145 	.globl _TL0
                            146 	.globl _TMOD
                            147 	.globl _TCON
                            148 	.globl _PCON
                            149 	.globl _DPH
                            150 	.globl _DPL
                            151 	.globl _SP
                            152 	.globl _B
                            153 	.globl _ACC
                            154 	.globl _PSW
                            155 	.globl _P3
                            156 	.globl _P1
                            157 	.globl _P0
                            158 ;--------------------------------------------------------
                            159 ; special function registers
                            160 ;--------------------------------------------------------
                            161 	.area RSEG    (ABS,DATA)
   0000                     162 	.org 0x0000
                    0080    163 _P0	=	0x0080
                    0090    164 _P1	=	0x0090
                    00B0    165 _P3	=	0x00b0
                    00D0    166 _PSW	=	0x00d0
                    00E0    167 _ACC	=	0x00e0
                    00F0    168 _B	=	0x00f0
                    0081    169 _SP	=	0x0081
                    0082    170 _DPL	=	0x0082
                    0083    171 _DPH	=	0x0083
                    0087    172 _PCON	=	0x0087
                    0088    173 _TCON	=	0x0088
                    0089    174 _TMOD	=	0x0089
                    008A    175 _TL0	=	0x008a
                    008B    176 _TL1	=	0x008b
                    008C    177 _TH0	=	0x008c
                    008D    178 _TH1	=	0x008d
                    00A8    179 _IEN0	=	0x00a8
                    00B8    180 _IP0	=	0x00b8
                    0098    181 _SCON	=	0x0098
                    0099    182 _SBUF	=	0x0099
                    00A2    183 _AUXR1	=	0x00a2
                    00A9    184 _SADDR	=	0x00a9
                    00B9    185 _SADEN	=	0x00b9
                    00BE    186 _BRGR0	=	0x00be
                    00BF    187 _BRGR1	=	0x00bf
                    00BD    188 _BRGCON	=	0x00bd
                    00AC    189 _CMP1	=	0x00ac
                    00AD    190 _CMP2	=	0x00ad
                    0095    191 _DIVM	=	0x0095
                    00E7    192 _FMADRH	=	0x00e7
                    00E6    193 _FMADRL	=	0x00e6
                    00E4    194 _FMCON	=	0x00e4
                    00E5    195 _FMDATA	=	0x00e5
                    00DB    196 _I2ADR	=	0x00db
                    00D8    197 _I2CON	=	0x00d8
                    00DA    198 _I2DAT	=	0x00da
                    00DD    199 _I2SCLH	=	0x00dd
                    00DC    200 _I2SCLL	=	0x00dc
                    00D9    201 _I2STAT	=	0x00d9
                    00F8    202 _IP1	=	0x00f8
                    00F7    203 _IP1H	=	0x00f7
                    0094    204 _KBCON	=	0x0094
                    0086    205 _KBMASK	=	0x0086
                    0093    206 _KBPATN	=	0x0093
                    0084    207 _P0M1	=	0x0084
                    0085    208 _P0M2	=	0x0085
                    0091    209 _P1M1	=	0x0091
                    0092    210 _P1M2	=	0x0092
                    00B1    211 _P3M1	=	0x00b1
                    00B2    212 _P3M2	=	0x00b2
                    00B5    213 _PCONA	=	0x00b5
                    00F6    214 _PT0AD	=	0x00f6
                    00DF    215 _RSTSRC	=	0x00df
                    00D1    216 _RTCCON	=	0x00d1
                    00D2    217 _RTCH	=	0x00d2
                    00D3    218 _RTCL	=	0x00d3
                    00BA    219 _SSTAT	=	0x00ba
                    008F    220 _TAMOD	=	0x008f
                    0096    221 _TRIM	=	0x0096
                    00A7    222 _WDCON	=	0x00a7
                    00C1    223 _WDL	=	0x00c1
                    00C2    224 _WFEED1	=	0x00c2
                    00C3    225 _WFEED2	=	0x00c3
                    00B7    226 _IP0H	=	0x00b7
                    00E8    227 _IEN1	=	0x00e8
                            228 ;--------------------------------------------------------
                            229 ; special function bits
                            230 ;--------------------------------------------------------
                            231 	.area RSEG    (ABS,DATA)
   0000                     232 	.org 0x0000
                    00D0    233 _PSW_0	=	0x00d0
                    00D1    234 _PSW_1	=	0x00d1
                    00D2    235 _PSW_2	=	0x00d2
                    00D3    236 _PSW_3	=	0x00d3
                    00D4    237 _PSW_4	=	0x00d4
                    00D5    238 _PSW_5	=	0x00d5
                    00D6    239 _PSW_6	=	0x00d6
                    00D7    240 _PSW_7	=	0x00d7
                    008F    241 _TCON_7	=	0x008f
                    008E    242 _TCON_6	=	0x008e
                    008D    243 _TCON_5	=	0x008d
                    008C    244 _TCON_4	=	0x008c
                    008B    245 _TCON_3	=	0x008b
                    008A    246 _TCON_2	=	0x008a
                    0089    247 _TCON_1	=	0x0089
                    0088    248 _TCON_0	=	0x0088
                    00AF    249 _IEN0_7	=	0x00af
                    00AE    250 _IEN0_6	=	0x00ae
                    00AD    251 _IEN0_5	=	0x00ad
                    00AC    252 _IEN0_4	=	0x00ac
                    00AB    253 _IEN0_3	=	0x00ab
                    00AA    254 _IEN0_2	=	0x00aa
                    00A9    255 _IEN0_1	=	0x00a9
                    00A8    256 _IEN0_0	=	0x00a8
                    00EA    257 _IEN1_2	=	0x00ea
                    00E9    258 _IEN1_1	=	0x00e9
                    00E8    259 _IEN1_0	=	0x00e8
                    00FE    260 _IP1_6	=	0x00fe
                    00FA    261 _IP1_2	=	0x00fa
                    00F9    262 _IP1_1	=	0x00f9
                    00F8    263 _IP1_0	=	0x00f8
                    00BE    264 _IP0_6	=	0x00be
                    00BD    265 _IP0_5	=	0x00bd
                    00BC    266 _IP0_4	=	0x00bc
                    00BB    267 _IP0_3	=	0x00bb
                    00BA    268 _IP0_2	=	0x00ba
                    00B9    269 _IP0_1	=	0x00b9
                    00B8    270 _IP0_0	=	0x00b8
                    0098    271 _SCON_0	=	0x0098
                    0099    272 _SCON_1	=	0x0099
                    009A    273 _SCON_2	=	0x009a
                    009B    274 _SCON_3	=	0x009b
                    009C    275 _SCON_4	=	0x009c
                    009D    276 _SCON_5	=	0x009d
                    009E    277 _SCON_6	=	0x009e
                    009F    278 _SCON_7	=	0x009f
                    00DE    279 _I2CON_6	=	0x00de
                    00DD    280 _I2CON_5	=	0x00dd
                    00DC    281 _I2CON_4	=	0x00dc
                    00DB    282 _I2CON_3	=	0x00db
                    00DA    283 _I2CON_2	=	0x00da
                    00D8    284 _I2CON_0	=	0x00d8
                    0080    285 _P0_0	=	0x0080
                    0081    286 _P0_1	=	0x0081
                    0082    287 _P0_2	=	0x0082
                    0083    288 _P0_3	=	0x0083
                    0084    289 _P0_4	=	0x0084
                    0085    290 _P0_5	=	0x0085
                    0086    291 _P0_6	=	0x0086
                    0087    292 _P0_7	=	0x0087
                    0090    293 _P1_0	=	0x0090
                    0091    294 _P1_1	=	0x0091
                    0092    295 _P1_2	=	0x0092
                    0093    296 _P1_3	=	0x0093
                    0094    297 _P1_4	=	0x0094
                    0095    298 _P1_5	=	0x0095
                    0096    299 _P1_6	=	0x0096
                    0097    300 _P1_7	=	0x0097
                    00B0    301 _P3_0	=	0x00b0
                    00B1    302 _P3_1	=	0x00b1
                            303 ;--------------------------------------------------------
                            304 ; overlayable register banks
                            305 ;--------------------------------------------------------
                            306 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     307 	.ds 8
                            308 ;--------------------------------------------------------
                            309 ; overlayable bit register bank
                            310 ;--------------------------------------------------------
                            311 	.area BIT_BANK	(REL,OVR,DATA)
   0023                     312 bits:
   0023                     313 	.ds 1
                    8000    314 	b0 = bits[0]
                    8100    315 	b1 = bits[1]
                    8200    316 	b2 = bits[2]
                    8300    317 	b3 = bits[3]
                    8400    318 	b4 = bits[4]
                    8500    319 	b5 = bits[5]
                    8600    320 	b6 = bits[6]
                    8700    321 	b7 = bits[7]
                            322 ;--------------------------------------------------------
                            323 ; internal ram data
                            324 ;--------------------------------------------------------
                            325 	.area DSEG    (DATA)
                            326 ;--------------------------------------------------------
                            327 ; overlayable items in internal ram 
                            328 ;--------------------------------------------------------
                            329 ;--------------------------------------------------------
                            330 ; Stack segment in internal ram 
                            331 ;--------------------------------------------------------
                            332 	.area	SSEG	(DATA)
   006E                     333 __start__stack:
   006E                     334 	.ds	1
                            335 
                            336 ;--------------------------------------------------------
                            337 ; indirectly addressable internal ram data
                            338 ;--------------------------------------------------------
                            339 	.area ISEG    (DATA)
                            340 ;--------------------------------------------------------
                            341 ; absolute internal ram data
                            342 ;--------------------------------------------------------
                            343 	.area IABS    (ABS,DATA)
                            344 	.area IABS    (ABS,DATA)
                            345 ;--------------------------------------------------------
                            346 ; bit data
                            347 ;--------------------------------------------------------
                            348 	.area BSEG    (BIT)
                            349 ;--------------------------------------------------------
                            350 ; paged external ram data
                            351 ;--------------------------------------------------------
                            352 	.area PSEG    (PAG,XDATA)
                            353 ;--------------------------------------------------------
                            354 ; external ram data
                            355 ;--------------------------------------------------------
                            356 	.area XSEG    (XDATA)
                            357 ;--------------------------------------------------------
                            358 ; absolute external ram data
                            359 ;--------------------------------------------------------
                            360 	.area XABS    (ABS,XDATA)
                            361 ;--------------------------------------------------------
                            362 ; external initialized ram data
                            363 ;--------------------------------------------------------
                            364 	.area XISEG   (XDATA)
                            365 	.area HOME    (CODE)
                            366 	.area GSINIT0 (CODE)
                            367 	.area GSINIT1 (CODE)
                            368 	.area GSINIT2 (CODE)
                            369 	.area GSINIT3 (CODE)
                            370 	.area GSINIT4 (CODE)
                            371 	.area GSINIT5 (CODE)
                            372 	.area GSINIT  (CODE)
                            373 	.area GSFINAL (CODE)
                            374 	.area CSEG    (CODE)
                            375 ;--------------------------------------------------------
                            376 ; interrupt vector 
                            377 ;--------------------------------------------------------
                            378 	.area HOME    (CODE)
   0000                     379 __interrupt_vect:
   0000 02 00 23            380 	ljmp	__sdcc_gsinit_startup
   0003 32                  381 	reti
   0004                     382 	.ds	7
   000B 32                  383 	reti
   000C                     384 	.ds	7
   0013 02 0F 94            385 	ljmp	_X1_int
   0016                     386 	.ds	5
   001B 02 0F C4            387 	ljmp	_T1_int
                            388 ;--------------------------------------------------------
                            389 ; global & static initialisations
                            390 ;--------------------------------------------------------
                            391 	.area HOME    (CODE)
                            392 	.area GSINIT  (CODE)
                            393 	.area GSFINAL (CODE)
                            394 	.area GSINIT  (CODE)
                            395 	.globl __sdcc_gsinit_startup
                            396 	.globl __sdcc_program_startup
                            397 	.globl __start__stack
                            398 	.globl __mcs51_genXINIT
                            399 	.globl __mcs51_genXRAMCLEAR
                            400 	.globl __mcs51_genRAMCLEAR
                            401 	.area GSFINAL (CODE)
   007C 02 00 1E            402 	ljmp	__sdcc_program_startup
                            403 ;--------------------------------------------------------
                            404 ; Home
                            405 ;--------------------------------------------------------
                            406 	.area HOME    (CODE)
                            407 	.area HOME    (CODE)
   001E                     408 __sdcc_program_startup:
   001E 12 0C B8            409 	lcall	_main
                            410 ;	return from main will lock up
   0021 80 FE               411 	sjmp .
                            412 ;--------------------------------------------------------
                            413 ; code
                            414 ;--------------------------------------------------------
                            415 	.area CSEG    (CODE)
                            416 ;------------------------------------------------------------
                            417 ;Allocation info for local variables in function 'main'
                            418 ;------------------------------------------------------------
                            419 ;n                         Allocated to registers r4 
                            420 ;cmd                       Allocated to registers r4 
                            421 ;tasterpegel               Allocated to registers r7 
                            422 ;cal                       Allocated to registers r5 
                            423 ;rm_count                  Allocated to registers r6 
                            424 ;wduf                      Allocated to registers b1 
                            425 ;tastergetoggelt           Allocated to registers b0 
                            426 ;------------------------------------------------------------
                            427 ;	../fb_out.c:123: void main(void)
                            428 ;	-----------------------------------------
                            429 ;	 function main
                            430 ;	-----------------------------------------
   0CB8                     431 _main:
                    0007    432 	ar7 = 0x07
                    0006    433 	ar6 = 0x06
                    0005    434 	ar5 = 0x05
                    0004    435 	ar4 = 0x04
                    0003    436 	ar3 = 0x03
                    0002    437 	ar2 = 0x02
                    0001    438 	ar1 = 0x01
                    0000    439 	ar0 = 0x00
                            440 ;	../fb_out.c:125: unsigned char n,cmd,tasterpegel=0;
   0CB8 7F 00               441 	mov	r7,#0x00
                            442 ;	../fb_out.c:131: unsigned char rm_count=0;
   0CBA 7E 00               443 	mov	r6,#0x00
                            444 ;	../fb_out.c:132: __bit wduf,tastergetoggelt=0;
   0CBC C2 18               445 	clr	b0
                            446 ;	../fb_out.c:133: wduf=WDCON&0x02;
   0CBE E5 A7               447 	mov	a,_WDCON
   0CC0 03                  448 	rr	a
   0CC1 54 01               449 	anl	a,#0x01
   0CC3 24 FF               450 	add	a,#0xff
   0CC5 92 19               451 	mov	b1,c
                            452 ;	../fb_out.c:134: restart_hw();							// Hardware zuruecksetzen
   0CC7 C0 07               453 	push	ar7
   0CC9 C0 06               454 	push	ar6
   0CCB C0 23               455 	push	bits
   0CCD 12 18 B5            456 	lcall	_restart_hw
   0CD0 D0 23               457 	pop	bits
   0CD2 D0 06               458 	pop	ar6
   0CD4 D0 07               459 	pop	ar7
                            460 ;	../fb_out.c:137: TASTER=1;
   0CD6 D2 97               461 	setb	_P1_7
                            462 ;	../fb_out.c:138: if(!TASTER && wduf)cal=0;
   0CD8 20 97 07            463 	jb	_P1_7,00102$
   0CDB 30 19 04            464 	jnb	b1,00102$
   0CDE 7D 00               465 	mov	r5,#0x00
   0CE0 80 07               466 	sjmp	00103$
   0CE2                     467 00102$:
                            468 ;	../fb_out.c:139: else cal=trimsave;
   0CE2 90 1B FF            469 	mov	dptr,#_main_trimsave_1_38
   0CE5 E4                  470 	clr	a
   0CE6 93                  471 	movc	a,@a+dptr
   0CE7 FC                  472 	mov	r4,a
   0CE8 FD                  473 	mov	r5,a
   0CE9                     474 00103$:
                            475 ;	../fb_out.c:140: TRIM = (TRIM+trimsave);
   0CE9 90 1B FF            476 	mov	dptr,#_main_trimsave_1_38
   0CEC E4                  477 	clr	a
   0CED 93                  478 	movc	a,@a+dptr
   0CEE AB 96               479 	mov	r3,_TRIM
   0CF0 2B                  480 	add	a,r3
   0CF1 FC                  481 	mov	r4,a
   0CF2 8C 96               482 	mov	_TRIM,r4
                            483 ;	../fb_out.c:141: TRIM &= 0x3F;//oberen 2 bits ausblenden
   0CF4 53 96 3F            484 	anl	_TRIM,#0x3F
                            485 ;	../fb_out.c:146: if (!wduf){// BUS return verz�gerung nur wenn nicht watchdog underflow
   0CF7 20 19 21            486 	jb	b1,00109$
                            487 ;	../fb_out.c:147: for (n=0;n<50;n++) {		// Warten bis Bus stabil
   0CFA 7C 00               488 	mov	r4,#0x00
   0CFC                     489 00181$:
   0CFC BC 32 00            490 	cjne	r4,#0x32,00277$
   0CFF                     491 00277$:
   0CFF 50 1A               492 	jnc	00109$
                            493 ;	../fb_out.c:148: TR0=0;					// Timer 0 anhalten
   0D01 C2 8C               494 	clr	_TCON_4
                            495 ;	../fb_out.c:149: TH0=eeprom[ADDRTAB+1];	// Timer 0 setzen mit phys. Adr. damit Ger�te unterschiedlich beginnen zu senden
   0D03 90 1D 17            496 	mov	dptr,#(_eeprom + 0x0017)
   0D06 E4                  497 	clr	a
   0D07 93                  498 	movc	a,@a+dptr
   0D08 F5 8C               499 	mov	_TH0,a
                            500 ;	../fb_out.c:150: TL0=eeprom[ADDRTAB+2];
   0D0A 90 1D 18            501 	mov	dptr,#(_eeprom + 0x0018)
   0D0D E4                  502 	clr	a
   0D0E 93                  503 	movc	a,@a+dptr
   0D0F F5 8A               504 	mov	_TL0,a
                            505 ;	../fb_out.c:151: TF0=0;					// �berlauf-Flag zur�cksetzen
   0D11 C2 8D               506 	clr	_TCON_5
                            507 ;	../fb_out.c:152: TR0=1;					// Timer 0 starten
   0D13 D2 8C               508 	setb	_TCON_4
                            509 ;	../fb_out.c:153: while(!TF0);
   0D15                     510 00105$:
   0D15 30 8D FD            511 	jnb	_TCON_5,00105$
                            512 ;	../fb_out.c:147: for (n=0;n<50;n++) {		// Warten bis Bus stabil
   0D18 0C                  513 	inc	r4
   0D19 80 E1               514 	sjmp	00181$
   0D1B                     515 00109$:
                            516 ;	../fb_out.c:156: watchdog_init();
   0D1B C0 07               517 	push	ar7
   0D1D C0 06               518 	push	ar6
   0D1F C0 05               519 	push	ar5
   0D21 C0 23               520 	push	bits
   0D23 12 0F 4C            521 	lcall	_watchdog_init
   0D26 D0 23               522 	pop	bits
                            523 ;	../fb_out.c:157: watchdog_start();
   0D28 C0 23               524 	push	bits
   0D2A 12 0F 68            525 	lcall	_watchdog_start
   0D2D D0 23               526 	pop	bits
                            527 ;	../fb_out.c:158: restart_app();							// Anwendungsspezifische Einstellungen zuruecksetzen
   0D2F C0 23               528 	push	bits
   0D31 12 0C 34            529 	lcall	_restart_app
   0D34 D0 23               530 	pop	bits
   0D36 D0 05               531 	pop	ar5
   0D38 D0 06               532 	pop	ar6
   0D3A D0 07               533 	pop	ar7
                            534 ;	../fb_out.c:159: if(!wduf)bus_return();							// Aktionen bei Busspannungswiederkehr
   0D3C 20 19 13            535 	jb	b1,00111$
   0D3F C0 07               536 	push	ar7
   0D41 C0 06               537 	push	ar6
   0D43 C0 05               538 	push	ar5
   0D45 C0 23               539 	push	bits
   0D47 12 0B 91            540 	lcall	_bus_return
   0D4A D0 23               541 	pop	bits
   0D4C D0 05               542 	pop	ar5
   0D4E D0 06               543 	pop	ar6
   0D50 D0 07               544 	pop	ar7
   0D52                     545 00111$:
                            546 ;	../fb_out.c:161: BRGCON&=0xFE;	// Baudrate Generator stoppen
   0D52 53 BD FE            547 	anl	_BRGCON,#0xFE
                            548 ;	../fb_out.c:162: P1M1&=0xFC;		// RX und TX auf bidirectional setzen
   0D55 53 91 FC            549 	anl	_P1M1,#0xFC
                            550 ;	../fb_out.c:163: P1M2&=0xFC;
   0D58 53 92 FC            551 	anl	_P1M2,#0xFC
                            552 ;	../fb_out.c:164: SCON=0x50;		// Mode 1, receive enable
   0D5B 75 98 50            553 	mov	_SCON,#0x50
                            554 ;	../fb_out.c:165: SSTAT|=0xE0;	// TI wird am Ende des Stopbits gesetzt und Interrupt nur bei RX und double TX buffer an
   0D5E 43 BA E0            555 	orl	_SSTAT,#0xE0
                            556 ;	../fb_out.c:166: BRGCON|=0x02;	// Baudrate Generator verwenden aber noch gestoppt
   0D61 43 BD 02            557 	orl	_BRGCON,#0x02
                            558 ;	../fb_out.c:167: BRGR1=0x2F;	// Baudrate = cclk/((BRGR1,BRGR0)+16)
   0D64 75 BF 2F            559 	mov	_BRGR1,#0x2F
                            560 ;	../fb_out.c:168: BRGR0=0xF0;	// f�r 115200 0030 nehmen, autocal: 600bd= 0x2FF0
   0D67 75 BE F0            561 	mov	_BRGR0,#0xF0
                            562 ;	../fb_out.c:169: BRGCON|=0x01;	// Baudrate Generator starten
   0D6A 43 BD 01            563 	orl	_BRGCON,#0x01
                            564 ;	../fb_out.c:170: SBUF=0x55;
   0D6D 75 99 55            565 	mov	_SBUF,#0x55
                            566 ;	../fb_out.c:171: do  {
   0D70                     567 00178$:
                            568 ;	../fb_out.c:172: watchdog_feed();
   0D70 C0 07               569 	push	ar7
   0D72 C0 06               570 	push	ar6
   0D74 C0 05               571 	push	ar5
   0D76 C0 23               572 	push	bits
   0D78 12 0F 5D            573 	lcall	_watchdog_feed
   0D7B D0 23               574 	pop	bits
   0D7D D0 05               575 	pop	ar5
   0D7F D0 06               576 	pop	ar6
   0D81 D0 07               577 	pop	ar7
                            578 ;	../fb_out.c:174: if(APPLICATION_RUN) {	// nur wenn run-mode gesetzt
   0D83 90 1D 0D            579 	mov	dptr,#(_eeprom + 0x000d)
   0D86 E4                  580 	clr	a
   0D87 93                  581 	movc	a,@a+dptr
   0D88 FC                  582 	mov	r4,a
   0D89 BC FF 02            583 	cjne	r4,#0xFF,00281$
   0D8C 80 03               584 	sjmp	00282$
   0D8E                     585 00281$:
   0D8E 02 0E 74            586 	ljmp	00133$
   0D91                     587 00282$:
   0D91 30 10 03            588 	jnb	_connected,00283$
   0D94 02 0E 74            589 	ljmp	00133$
   0D97                     590 00283$:
                            591 ;	../fb_out.c:176: if(RTCCON>=0x80) delay_timer();	// Realtime clock Ueberlauf
   0D97 74 80               592 	mov	a,#0x100 - 0x80
   0D99 25 D1               593 	add	a,_RTCCON
   0D9B 50 13               594 	jnc	00113$
   0D9D C0 07               595 	push	ar7
   0D9F C0 06               596 	push	ar6
   0DA1 C0 05               597 	push	ar5
   0DA3 C0 23               598 	push	bits
   0DA5 12 08 B5            599 	lcall	_delay_timer
   0DA8 D0 23               600 	pop	bits
   0DAA D0 05               601 	pop	ar5
   0DAC D0 06               602 	pop	ar6
   0DAE D0 07               603 	pop	ar7
   0DB0                     604 00113$:
                            605 ;	../fb_out.c:178: if(TF0 && (TMOD & 0x0F)==0x01) {	// Vollstrom f�r Relais ausschalten und wieder PWM ein
   0DB0 30 8D 1F            606 	jnb	_TCON_5,00115$
   0DB3 74 0F               607 	mov	a,#0x0F
   0DB5 55 89               608 	anl	a,_TMOD
   0DB7 FC                  609 	mov	r4,a
   0DB8 BC 01 17            610 	cjne	r4,#0x01,00115$
                            611 ;	../fb_out.c:180: TMOD=(TMOD & 0xF0) + 2;			// Timer 0 als PWM
   0DBB 74 F0               612 	mov	a,#0xF0
   0DBD 55 89               613 	anl	a,_TMOD
   0DBF 24 02               614 	add	a,#0x02
   0DC1 F5 89               615 	mov	_TMOD,a
                            616 ;	../fb_out.c:181: TAMOD=0x01;
   0DC3 75 8F 01            617 	mov	_TAMOD,#0x01
                            618 ;	../fb_out.c:182: TH0=DUTY;
   0DC6 75 8C 50            619 	mov	_TH0,#0x50
                            620 ;	../fb_out.c:184: TF0=0;
   0DC9 C2 8D               621 	clr	_TCON_5
                            622 ;	../fb_out.c:186: AUXR1|=0x10;	// PWM von Timer 0 auf Pin ausgeben
   0DCB 43 A2 10            623 	orl	_AUXR1,#0x10
                            624 ;	../fb_out.c:188: PWM=1;			// PWM Pin muss auf 1 gesetzt werden, damit PWM geht !!!
   0DCE D2 92               625 	setb	_P1_2
                            626 ;	../fb_out.c:190: TR0=1;
   0DD0 D2 8C               627 	setb	_TCON_4
   0DD2                     628 00115$:
                            629 ;	../fb_out.c:197: if (portchanged)port_schalten();	// Ausg�nge schalten
   0DD2 30 01 13            630 	jnb	_portchanged,00118$
   0DD5 C0 07               631 	push	ar7
   0DD7 C0 06               632 	push	ar6
   0DD9 C0 05               633 	push	ar5
   0DDB C0 23               634 	push	bits
   0DDD 12 0A 56            635 	lcall	_port_schalten
   0DE0 D0 23               636 	pop	bits
   0DE2 D0 05               637 	pop	ar5
   0DE4 D0 06               638 	pop	ar6
   0DE6 D0 07               639 	pop	ar7
   0DE8                     640 00118$:
                            641 ;	../fb_out.c:200: if(rm_send) {	// wenn nichts zu senden ist keine Zeit vertr�deln
   0DE8 E5 3E               642 	mov	a,_rm_send
   0DEA 60 5F               643 	jz	00125$
                            644 ;	../fb_out.c:201: if(rm_send & (1<<rm_count)) {
   0DEC C0 05               645 	push	ar5
   0DEE 8E F0               646 	mov	b,r6
   0DF0 05 F0               647 	inc	b
   0DF2 7B 01               648 	mov	r3,#0x01
   0DF4 7C 00               649 	mov	r4,#0x00
   0DF6 80 06               650 	sjmp	00291$
   0DF8                     651 00290$:
   0DF8 EB                  652 	mov	a,r3
   0DF9 2B                  653 	add	a,r3
   0DFA FB                  654 	mov	r3,a
   0DFB EC                  655 	mov	a,r4
   0DFC 33                  656 	rlc	a
   0DFD FC                  657 	mov	r4,a
   0DFE                     658 00291$:
   0DFE D5 F0 F7            659 	djnz	b,00290$
   0E01 AA 3E               660 	mov	r2,_rm_send
   0E03 7D 00               661 	mov	r5,#0x00
   0E05 EA                  662 	mov	a,r2
   0E06 52 03               663 	anl	ar3,a
   0E08 ED                  664 	mov	a,r5
   0E09 52 04               665 	anl	ar4,a
   0E0B D0 05               666 	pop	ar5
   0E0D EB                  667 	mov	a,r3
   0E0E 4C                  668 	orl	a,r4
   0E0F 60 34               669 	jz	00122$
                            670 ;	../fb_out.c:202: if(send_obj_value(rm_count + 12)) {	// falls erfolgreich, dann n�chste
   0E11 74 0C               671 	mov	a,#0x0C
   0E13 2E                  672 	add	a,r6
   0E14 F5 82               673 	mov	dpl,a
   0E16 C0 07               674 	push	ar7
   0E18 C0 06               675 	push	ar6
   0E1A C0 05               676 	push	ar5
   0E1C C0 23               677 	push	bits
   0E1E 12 15 CC            678 	lcall	_send_obj_value
   0E21 D0 23               679 	pop	bits
   0E23 D0 05               680 	pop	ar5
   0E25 D0 06               681 	pop	ar6
   0E27 D0 07               682 	pop	ar7
   0E29 50 22               683 	jnc	00126$
                            684 ;	../fb_out.c:203: rm_send&=(0xFF-(1<<rm_count));
   0E2B 8E F0               685 	mov	b,r6
   0E2D 05 F0               686 	inc	b
   0E2F 74 01               687 	mov	a,#0x01
   0E31 80 02               688 	sjmp	00296$
   0E33                     689 00294$:
   0E33 25 E0               690 	add	a,acc
   0E35                     691 00296$:
   0E35 D5 F0 FB            692 	djnz	b,00294$
   0E38 FC                  693 	mov	r4,a
   0E39 74 FF               694 	mov	a,#0xFF
   0E3B C3                  695 	clr	c
   0E3C 9C                  696 	subb	a,r4
   0E3D 52 3E               697 	anl	_rm_send,a
                            698 ;	../fb_out.c:204: rm_count++;
   0E3F 0E                  699 	inc	r6
                            700 ;	../fb_out.c:208: rm_count&=0x03;
   0E40 53 06 03            701 	anl	ar6,#0x03
   0E43 80 08               702 	sjmp	00126$
   0E45                     703 00122$:
                            704 ;	../fb_out.c:213: rm_count++;
   0E45 0E                  705 	inc	r6
                            706 ;	../fb_out.c:217: rm_count&=0x03;
   0E46 53 06 03            707 	anl	ar6,#0x03
   0E49 80 02               708 	sjmp	00126$
   0E4B                     709 00125$:
                            710 ;	../fb_out.c:221: else rm_count=0;	// Immer mal wieder auf Null setzen, damit Reihenfolge von 1 bis 8 geht
   0E4B 7E 00               711 	mov	r6,#0x00
   0E4D                     712 00126$:
                            713 ;	../fb_out.c:227: if (fb_state==0 && (TH1<0XC0) && (!wait_for_ack)&& portbuffer!=eeprom[PORTSAVE]) {
   0E4D E5 69               714 	mov	a,_fb_state
   0E4F 70 23               715 	jnz	00133$
   0E51 74 40               716 	mov	a,#0x100 - 0xC0
   0E53 25 8D               717 	add	a,_TH1
   0E55 40 1D               718 	jc	00133$
   0E57 20 0C 1A            719 	jb	_wait_for_ack,00133$
   0E5A 90 1D 99            720 	mov	dptr,#(_eeprom + 0x0099)
   0E5D E4                  721 	clr	a
   0E5E 93                  722 	movc	a,@a+dptr
   0E5F FC                  723 	mov	r4,a
   0E60 B5 3A 02            724 	cjne	a,_portbuffer,00300$
   0E63 80 0F               725 	sjmp	00133$
   0E65                     726 00300$:
                            727 ;	../fb_out.c:228: START_WRITECYCLE;
   0E65 75 E4 00            728 	mov	_FMCON,#0x00
                            729 ;	../fb_out.c:229: WRITE_BYTE(0x01,PORTSAVE,portbuffer);
   0E68 75 E7 1D            730 	mov	_FMADRH,#0x1D
   0E6B 75 E6 99            731 	mov	_FMADRL,#0x99
   0E6E 85 3A E5            732 	mov	_FMDATA,_portbuffer
                            733 ;	../fb_out.c:230: STOP_WRITECYCLE;
   0E71 75 E4 68            734 	mov	_FMCON,#0x68
   0E74                     735 00133$:
                            736 ;	../fb_out.c:236: if (tel_arrived || tel_sent) {
   0E74 20 08 03            737 	jb	_tel_arrived,00135$
   0E77 30 09 19            738 	jnb	_tel_sent,00136$
   0E7A                     739 00135$:
                            740 ;	../fb_out.c:237: tel_arrived=0;
   0E7A C2 08               741 	clr	_tel_arrived
                            742 ;	../fb_out.c:238: tel_sent=0;
   0E7C C2 09               743 	clr	_tel_sent
                            744 ;	../fb_out.c:239: process_tel();
   0E7E C0 07               745 	push	ar7
   0E80 C0 06               746 	push	ar6
   0E82 C0 05               747 	push	ar5
   0E84 C0 23               748 	push	bits
   0E86 12 15 FF            749 	lcall	_process_tel
   0E89 D0 23               750 	pop	bits
   0E8B D0 05               751 	pop	ar5
   0E8D D0 06               752 	pop	ar6
   0E8F D0 07               753 	pop	ar7
   0E91 80 0A               754 	sjmp	00137$
   0E93                     755 00136$:
                            756 ;	../fb_out.c:242: for(n=0;n<100;n++);	// falls Hauptroutine keine Zeit verbraucht, der PROG LED etwas Zeit geben, damit sie auch leuchten kann
   0E93 7C 64               757 	mov	r4,#0x64
   0E95                     758 00187$:
   0E95 8C 03               759 	mov	ar3,r4
   0E97 1B                  760 	dec	r3
   0E98 8B 04               761 	mov	ar4,r3
   0E9A EC                  762 	mov	a,r4
   0E9B 70 F8               763 	jnz	00187$
   0E9D                     764 00137$:
                            765 ;	../fb_out.c:247: if (RI){
                            766 ;	../fb_out.c:248: RI=0;
   0E9D 10 98 02            767 	jbc	_SCON_0,00304$
   0EA0 80 79               768 	sjmp	00166$
   0EA2                     769 00304$:
                            770 ;	../fb_out.c:249: cmd=SBUF;
   0EA2 AC 99               771 	mov	r4,_SBUF
                            772 ;	../fb_out.c:250: if(cmd=='c'){
   0EA4 BC 63 08            773 	cjne	r4,#0x63,00143$
                            774 ;	../fb_out.c:251: while(!TI);
   0EA7                     775 00139$:
                            776 ;	../fb_out.c:252: TI=0;
   0EA7 10 99 02            777 	jbc	_SCON_1,00307$
   0EAA 80 FB               778 	sjmp	00139$
   0EAC                     779 00307$:
                            780 ;	../fb_out.c:253: SBUF=0x55;
   0EAC 75 99 55            781 	mov	_SBUF,#0x55
   0EAF                     782 00143$:
                            783 ;	../fb_out.c:255: if(cmd=='+'){
   0EAF BC 2B 03            784 	cjne	r4,#0x2B,00145$
                            785 ;	../fb_out.c:256: TRIM--;
   0EB2 15 96               786 	dec	_TRIM
                            787 ;	../fb_out.c:257: cal--;
   0EB4 1D                  788 	dec	r5
   0EB5                     789 00145$:
                            790 ;	../fb_out.c:259: if(cmd=='-'){
   0EB5 BC 2D 03            791 	cjne	r4,#0x2D,00147$
                            792 ;	../fb_out.c:260: TRIM++;
   0EB8 05 96               793 	inc	_TRIM
                            794 ;	../fb_out.c:261: cal++;
   0EBA 0D                  795 	inc	r5
   0EBB                     796 00147$:
                            797 ;	../fb_out.c:263: if(cmd=='w'){
   0EBB BC 77 12            798 	cjne	r4,#0x77,00149$
                            799 ;	../fb_out.c:264: EA=0;
   0EBE C2 AF               800 	clr	_IEN0_7
                            801 ;	../fb_out.c:265: START_WRITECYCLE;	//cal an 0x1bff schreiben
   0EC0 75 E4 00            802 	mov	_FMCON,#0x00
                            803 ;	../fb_out.c:271: FMADRH= 0x1B;		
   0EC3 75 E7 1B            804 	mov	_FMADRH,#0x1B
                            805 ;	../fb_out.c:272: FMADRL= 0xFF; 
   0EC6 75 E6 FF            806 	mov	_FMADRL,#0xFF
                            807 ;	../fb_out.c:274: FMDATA=	cal;
   0EC9 8D E5               808 	mov	_FMDATA,r5
                            809 ;	../fb_out.c:275: STOP_WRITECYCLE;
   0ECB 75 E4 68            810 	mov	_FMCON,#0x68
                            811 ;	../fb_out.c:276: EA=1;				//int wieder freigeben
   0ECE D2 AF               812 	setb	_IEN0_7
   0ED0                     813 00149$:
                            814 ;	../fb_out.c:278: if(cmd=='p')status60^=0x81;	// Prog-Bit und Parity-Bit im system_state toggeln
   0ED0 BC 70 03            815 	cjne	r4,#0x70,00151$
   0ED3 63 6D 81            816 	xrl	_status60,#0x81
   0ED6                     817 00151$:
                            818 ;	../fb_out.c:295: if(cmd=='v'){
   0ED6 BC 76 08            819 	cjne	r4,#0x76,00156$
                            820 ;	../fb_out.c:296: while(!TI);
   0ED9                     821 00152$:
                            822 ;	../fb_out.c:297: TI=0;
   0ED9 10 99 02            823 	jbc	_SCON_1,00318$
   0EDC 80 FB               824 	sjmp	00152$
   0EDE                     825 00318$:
                            826 ;	../fb_out.c:298: SBUF=VERSION;
   0EDE 75 99 23            827 	mov	_SBUF,#0x23
   0EE1                     828 00156$:
                            829 ;	../fb_out.c:300: if(cmd=='t'){
   0EE1 BC 74 08            830 	cjne	r4,#0x74,00161$
                            831 ;	../fb_out.c:301: while(!TI);
   0EE4                     832 00157$:
                            833 ;	../fb_out.c:302: TI=0;
   0EE4 10 99 02            834 	jbc	_SCON_1,00321$
   0EE7 80 FB               835 	sjmp	00157$
   0EE9                     836 00321$:
                            837 ;	../fb_out.c:303: SBUF=TYPE;
   0EE9 75 99 05            838 	mov	_SBUF,#0x05
   0EEC                     839 00161$:
                            840 ;	../fb_out.c:311: if(cmd >=49 && cmd <= 52){
   0EEC BC 31 00            841 	cjne	r4,#0x31,00322$
   0EEF                     842 00322$:
   0EEF 40 2A               843 	jc	00166$
   0EF1 EC                  844 	mov	a,r4
   0EF2 24 CB               845 	add	a,#0xff - 0x34
   0EF4 40 25               846 	jc	00166$
                            847 ;	../fb_out.c:312: portbuffer = portbuffer ^ (0x01<< (cmd-49));
   0EF6 EC                  848 	mov	a,r4
   0EF7 24 CF               849 	add	a,#0xCF
   0EF9 F5 F0               850 	mov	b,a
   0EFB 05 F0               851 	inc	b
   0EFD 74 01               852 	mov	a,#0x01
   0EFF 80 02               853 	sjmp	00327$
   0F01                     854 00325$:
   0F01 25 E0               855 	add	a,acc
   0F03                     856 00327$:
   0F03 D5 F0 FB            857 	djnz	b,00325$
   0F06 62 3A               858 	xrl	_portbuffer,a
                            859 ;	../fb_out.c:313: port_schalten();
   0F08 C0 07               860 	push	ar7
   0F0A C0 06               861 	push	ar6
   0F0C C0 05               862 	push	ar5
   0F0E C0 23               863 	push	bits
   0F10 12 0A 56            864 	lcall	_port_schalten
   0F13 D0 23               865 	pop	bits
   0F15 D0 05               866 	pop	ar5
   0F17 D0 06               867 	pop	ar6
   0F19 D0 07               868 	pop	ar7
   0F1B                     869 00166$:
                            870 ;	../fb_out.c:319: TASTER=1;				// Pin als Eingang schalten um Taster abzufragen
   0F1B D2 97               871 	setb	_P1_7
                            872 ;	../fb_out.c:320: if(!TASTER){ // Taster gedr�ckt
   0F1D 20 97 12            873 	jb	_P1_7,00176$
                            874 ;	../fb_out.c:321: if(tasterpegel<255)	tasterpegel++;
   0F20 BF FF 00            875 	cjne	r7,#0xFF,00329$
   0F23                     876 00329$:
   0F23 50 03               877 	jnc	00170$
   0F25 0F                  878 	inc	r7
   0F26 80 12               879 	sjmp	00177$
   0F28                     880 00170$:
                            881 ;	../fb_out.c:323: if(!tastergetoggelt)status60^=0x81;	// Prog-Bit und Parity-Bit im system_state toggeln
   0F28 20 18 03            882 	jb	b0,00168$
   0F2B 63 6D 81            883 	xrl	_status60,#0x81
   0F2E                     884 00168$:
                            885 ;	../fb_out.c:324: tastergetoggelt=1;
   0F2E D2 18               886 	setb	b0
   0F30 80 08               887 	sjmp	00177$
   0F32                     888 00176$:
                            889 ;	../fb_out.c:328: if(tasterpegel>0) tasterpegel--;
   0F32 EF                  890 	mov	a,r7
   0F33 60 03               891 	jz	00173$
   0F35 1F                  892 	dec	r7
   0F36 80 02               893 	sjmp	00177$
   0F38                     894 00173$:
                            895 ;	../fb_out.c:329: else tastergetoggelt=0;
   0F38 C2 18               896 	clr	b0
   0F3A                     897 00177$:
                            898 ;	../fb_out.c:331: TASTER=!(status60 & 0x01);	// LED entsprechend Prog-Bit schalten (low=LED an)
   0F3A E5 6D               899 	mov	a,_status60
   0F3C 54 01               900 	anl	a,#0x01
   0F3E FC                  901 	mov	r4,a
   0F3F B4 01 00            902 	cjne	a,#0x01,00333$
   0F42                     903 00333$:
   0F42 E4                  904 	clr	a
   0F43 33                  905 	rlc	a
   0F44 FC                  906 	mov	r4,a
   0F45 24 FF               907 	add	a,#0xff
   0F47 92 97               908 	mov	_P1_7,c
                            909 ;	../fb_out.c:333: } while(1);
   0F49 02 0D 70            910 	ljmp	00178$
                            911 	.area CSEG    (CODE)
                            912 	.area CONST   (CODE)
                    1BFF    913 _main_trimsave_1_38	=	0x1bff
                            914 	.area XINIT   (CODE)
                            915 	.area CABS    (ABS,CODE)
