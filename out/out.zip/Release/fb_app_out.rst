                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : free open source ANSI-C Compiler
                              3 ; Version 3.1.4 #7479 (Mar 23 2012) (MINGW32)
                              4 ; This file was generated Mon Apr 16 21:21:44 2012
                              5 ;--------------------------------------------------------
                              6 	.module fb_app_out
                              7 	.optsdcc -mmcs51 --model-small
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _find_first_objno
                             13 	.globl _read_objflags
                             14 	.globl _send_obj_value
                             15 	.globl _gapos_in_gat
                             16 	.globl _P3_1
                             17 	.globl _P3_0
                             18 	.globl _P1_7
                             19 	.globl _P1_6
                             20 	.globl _P1_5
                             21 	.globl _P1_4
                             22 	.globl _P1_3
                             23 	.globl _P1_2
                             24 	.globl _P1_1
                             25 	.globl _P1_0
                             26 	.globl _P0_7
                             27 	.globl _P0_6
                             28 	.globl _P0_5
                             29 	.globl _P0_4
                             30 	.globl _P0_3
                             31 	.globl _P0_2
                             32 	.globl _P0_1
                             33 	.globl _P0_0
                             34 	.globl _I2CON_0
                             35 	.globl _I2CON_2
                             36 	.globl _I2CON_3
                             37 	.globl _I2CON_4
                             38 	.globl _I2CON_5
                             39 	.globl _I2CON_6
                             40 	.globl _SCON_7
                             41 	.globl _SCON_6
                             42 	.globl _SCON_5
                             43 	.globl _SCON_4
                             44 	.globl _SCON_3
                             45 	.globl _SCON_2
                             46 	.globl _SCON_1
                             47 	.globl _SCON_0
                             48 	.globl _IP0_0
                             49 	.globl _IP0_1
                             50 	.globl _IP0_2
                             51 	.globl _IP0_3
                             52 	.globl _IP0_4
                             53 	.globl _IP0_5
                             54 	.globl _IP0_6
                             55 	.globl _IP1_0
                             56 	.globl _IP1_1
                             57 	.globl _IP1_2
                             58 	.globl _IP1_6
                             59 	.globl _IEN1_0
                             60 	.globl _IEN1_1
                             61 	.globl _IEN1_2
                             62 	.globl _IEN0_0
                             63 	.globl _IEN0_1
                             64 	.globl _IEN0_2
                             65 	.globl _IEN0_3
                             66 	.globl _IEN0_4
                             67 	.globl _IEN0_5
                             68 	.globl _IEN0_6
                             69 	.globl _IEN0_7
                             70 	.globl _TCON_0
                             71 	.globl _TCON_1
                             72 	.globl _TCON_2
                             73 	.globl _TCON_3
                             74 	.globl _TCON_4
                             75 	.globl _TCON_5
                             76 	.globl _TCON_6
                             77 	.globl _TCON_7
                             78 	.globl _PSW_7
                             79 	.globl _PSW_6
                             80 	.globl _PSW_5
                             81 	.globl _PSW_4
                             82 	.globl _PSW_3
                             83 	.globl _PSW_2
                             84 	.globl _PSW_1
                             85 	.globl _PSW_0
                             86 	.globl _IEN1
                             87 	.globl _IP0H
                             88 	.globl _WFEED2
                             89 	.globl _WFEED1
                             90 	.globl _WDL
                             91 	.globl _WDCON
                             92 	.globl _TRIM
                             93 	.globl _TAMOD
                             94 	.globl _SSTAT
                             95 	.globl _RTCL
                             96 	.globl _RTCH
                             97 	.globl _RTCCON
                             98 	.globl _RSTSRC
                             99 	.globl _PT0AD
                            100 	.globl _PCONA
                            101 	.globl _P3M2
                            102 	.globl _P3M1
                            103 	.globl _P1M2
                            104 	.globl _P1M1
                            105 	.globl _P0M2
                            106 	.globl _P0M1
                            107 	.globl _KBPATN
                            108 	.globl _KBMASK
                            109 	.globl _KBCON
                            110 	.globl _IP1H
                            111 	.globl _IP1
                            112 	.globl _I2STAT
                            113 	.globl _I2SCLL
                            114 	.globl _I2SCLH
                            115 	.globl _I2DAT
                            116 	.globl _I2CON
                            117 	.globl _I2ADR
                            118 	.globl _FMDATA
                            119 	.globl _FMCON
                            120 	.globl _FMADRL
                            121 	.globl _FMADRH
                            122 	.globl _DIVM
                            123 	.globl _CMP2
                            124 	.globl _CMP1
                            125 	.globl _BRGCON
                            126 	.globl _BRGR1
                            127 	.globl _BRGR0
                            128 	.globl _SADEN
                            129 	.globl _SADDR
                            130 	.globl _AUXR1
                            131 	.globl _SBUF
                            132 	.globl _SCON
                            133 	.globl _IP0
                            134 	.globl _IEN0
                            135 	.globl _TH1
                            136 	.globl _TH0
                            137 	.globl _TL1
                            138 	.globl _TL0
                            139 	.globl _TMOD
                            140 	.globl _TCON
                            141 	.globl _PCON
                            142 	.globl _DPH
                            143 	.globl _DPL
                            144 	.globl _SP
                            145 	.globl _B
                            146 	.globl _ACC
                            147 	.globl _PSW
                            148 	.globl _P3
                            149 	.globl _P1
                            150 	.globl _P0
                            151 	.globl _portchanged
                            152 	.globl _delay_toggle
                            153 	.globl _rm_send
                            154 	.globl _logicstate
                            155 	.globl _blocked
                            156 	.globl _oldportbuffer
                            157 	.globl _portbuffer
                            158 	.globl _zf_state
                            159 	.globl _rm_state
                            160 	.globl _out_state
                            161 	.globl _Tval
                            162 	.globl _timer
                            163 	.globl _timercnt
                            164 	.globl _timerbase
                            165 	.globl _write_value_req
                            166 	.globl _read_value_req
                            167 	.globl _read_obj_value
                            168 	.globl _write_obj_value
                            169 	.globl _object_schalten
                            170 	.globl _delay_timer
                            171 	.globl _port_schalten
                            172 	.globl _sort_output
                            173 	.globl _spi_2_out
                            174 	.globl _bus_return
                            175 	.globl _restart_app
                            176 ;--------------------------------------------------------
                            177 ; special function registers
                            178 ;--------------------------------------------------------
                            179 	.area RSEG    (ABS,DATA)
   0000                     180 	.org 0x0000
                    0080    181 _P0	=	0x0080
                    0090    182 _P1	=	0x0090
                    00B0    183 _P3	=	0x00b0
                    00D0    184 _PSW	=	0x00d0
                    00E0    185 _ACC	=	0x00e0
                    00F0    186 _B	=	0x00f0
                    0081    187 _SP	=	0x0081
                    0082    188 _DPL	=	0x0082
                    0083    189 _DPH	=	0x0083
                    0087    190 _PCON	=	0x0087
                    0088    191 _TCON	=	0x0088
                    0089    192 _TMOD	=	0x0089
                    008A    193 _TL0	=	0x008a
                    008B    194 _TL1	=	0x008b
                    008C    195 _TH0	=	0x008c
                    008D    196 _TH1	=	0x008d
                    00A8    197 _IEN0	=	0x00a8
                    00B8    198 _IP0	=	0x00b8
                    0098    199 _SCON	=	0x0098
                    0099    200 _SBUF	=	0x0099
                    00A2    201 _AUXR1	=	0x00a2
                    00A9    202 _SADDR	=	0x00a9
                    00B9    203 _SADEN	=	0x00b9
                    00BE    204 _BRGR0	=	0x00be
                    00BF    205 _BRGR1	=	0x00bf
                    00BD    206 _BRGCON	=	0x00bd
                    00AC    207 _CMP1	=	0x00ac
                    00AD    208 _CMP2	=	0x00ad
                    0095    209 _DIVM	=	0x0095
                    00E7    210 _FMADRH	=	0x00e7
                    00E6    211 _FMADRL	=	0x00e6
                    00E4    212 _FMCON	=	0x00e4
                    00E5    213 _FMDATA	=	0x00e5
                    00DB    214 _I2ADR	=	0x00db
                    00D8    215 _I2CON	=	0x00d8
                    00DA    216 _I2DAT	=	0x00da
                    00DD    217 _I2SCLH	=	0x00dd
                    00DC    218 _I2SCLL	=	0x00dc
                    00D9    219 _I2STAT	=	0x00d9
                    00F8    220 _IP1	=	0x00f8
                    00F7    221 _IP1H	=	0x00f7
                    0094    222 _KBCON	=	0x0094
                    0086    223 _KBMASK	=	0x0086
                    0093    224 _KBPATN	=	0x0093
                    0084    225 _P0M1	=	0x0084
                    0085    226 _P0M2	=	0x0085
                    0091    227 _P1M1	=	0x0091
                    0092    228 _P1M2	=	0x0092
                    00B1    229 _P3M1	=	0x00b1
                    00B2    230 _P3M2	=	0x00b2
                    00B5    231 _PCONA	=	0x00b5
                    00F6    232 _PT0AD	=	0x00f6
                    00DF    233 _RSTSRC	=	0x00df
                    00D1    234 _RTCCON	=	0x00d1
                    00D2    235 _RTCH	=	0x00d2
                    00D3    236 _RTCL	=	0x00d3
                    00BA    237 _SSTAT	=	0x00ba
                    008F    238 _TAMOD	=	0x008f
                    0096    239 _TRIM	=	0x0096
                    00A7    240 _WDCON	=	0x00a7
                    00C1    241 _WDL	=	0x00c1
                    00C2    242 _WFEED1	=	0x00c2
                    00C3    243 _WFEED2	=	0x00c3
                    00B7    244 _IP0H	=	0x00b7
                    00E8    245 _IEN1	=	0x00e8
                            246 ;--------------------------------------------------------
                            247 ; special function bits
                            248 ;--------------------------------------------------------
                            249 	.area RSEG    (ABS,DATA)
   0000                     250 	.org 0x0000
                    00D0    251 _PSW_0	=	0x00d0
                    00D1    252 _PSW_1	=	0x00d1
                    00D2    253 _PSW_2	=	0x00d2
                    00D3    254 _PSW_3	=	0x00d3
                    00D4    255 _PSW_4	=	0x00d4
                    00D5    256 _PSW_5	=	0x00d5
                    00D6    257 _PSW_6	=	0x00d6
                    00D7    258 _PSW_7	=	0x00d7
                    008F    259 _TCON_7	=	0x008f
                    008E    260 _TCON_6	=	0x008e
                    008D    261 _TCON_5	=	0x008d
                    008C    262 _TCON_4	=	0x008c
                    008B    263 _TCON_3	=	0x008b
                    008A    264 _TCON_2	=	0x008a
                    0089    265 _TCON_1	=	0x0089
                    0088    266 _TCON_0	=	0x0088
                    00AF    267 _IEN0_7	=	0x00af
                    00AE    268 _IEN0_6	=	0x00ae
                    00AD    269 _IEN0_5	=	0x00ad
                    00AC    270 _IEN0_4	=	0x00ac
                    00AB    271 _IEN0_3	=	0x00ab
                    00AA    272 _IEN0_2	=	0x00aa
                    00A9    273 _IEN0_1	=	0x00a9
                    00A8    274 _IEN0_0	=	0x00a8
                    00EA    275 _IEN1_2	=	0x00ea
                    00E9    276 _IEN1_1	=	0x00e9
                    00E8    277 _IEN1_0	=	0x00e8
                    00FE    278 _IP1_6	=	0x00fe
                    00FA    279 _IP1_2	=	0x00fa
                    00F9    280 _IP1_1	=	0x00f9
                    00F8    281 _IP1_0	=	0x00f8
                    00BE    282 _IP0_6	=	0x00be
                    00BD    283 _IP0_5	=	0x00bd
                    00BC    284 _IP0_4	=	0x00bc
                    00BB    285 _IP0_3	=	0x00bb
                    00BA    286 _IP0_2	=	0x00ba
                    00B9    287 _IP0_1	=	0x00b9
                    00B8    288 _IP0_0	=	0x00b8
                    0098    289 _SCON_0	=	0x0098
                    0099    290 _SCON_1	=	0x0099
                    009A    291 _SCON_2	=	0x009a
                    009B    292 _SCON_3	=	0x009b
                    009C    293 _SCON_4	=	0x009c
                    009D    294 _SCON_5	=	0x009d
                    009E    295 _SCON_6	=	0x009e
                    009F    296 _SCON_7	=	0x009f
                    00DE    297 _I2CON_6	=	0x00de
                    00DD    298 _I2CON_5	=	0x00dd
                    00DC    299 _I2CON_4	=	0x00dc
                    00DB    300 _I2CON_3	=	0x00db
                    00DA    301 _I2CON_2	=	0x00da
                    00D8    302 _I2CON_0	=	0x00d8
                    0080    303 _P0_0	=	0x0080
                    0081    304 _P0_1	=	0x0081
                    0082    305 _P0_2	=	0x0082
                    0083    306 _P0_3	=	0x0083
                    0084    307 _P0_4	=	0x0084
                    0085    308 _P0_5	=	0x0085
                    0086    309 _P0_6	=	0x0086
                    0087    310 _P0_7	=	0x0087
                    0090    311 _P1_0	=	0x0090
                    0091    312 _P1_1	=	0x0091
                    0092    313 _P1_2	=	0x0092
                    0093    314 _P1_3	=	0x0093
                    0094    315 _P1_4	=	0x0094
                    0095    316 _P1_5	=	0x0095
                    0096    317 _P1_6	=	0x0096
                    0097    318 _P1_7	=	0x0097
                    00B0    319 _P3_0	=	0x00b0
                    00B1    320 _P3_1	=	0x00b1
                            321 ;--------------------------------------------------------
                            322 ; overlayable register banks
                            323 ;--------------------------------------------------------
                            324 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     325 	.ds 8
                            326 ;--------------------------------------------------------
                            327 ; overlayable bit register bank
                            328 ;--------------------------------------------------------
                            329 	.area BIT_BANK	(REL,OVR,DATA)
   0023                     330 bits:
   0023                     331 	.ds 1
                    8000    332 	b0 = bits[0]
                    8100    333 	b1 = bits[1]
                    8200    334 	b2 = bits[2]
                    8300    335 	b3 = bits[3]
                    8400    336 	b4 = bits[4]
                    8500    337 	b5 = bits[5]
                    8600    338 	b6 = bits[6]
                    8700    339 	b7 = bits[7]
                            340 ;--------------------------------------------------------
                            341 ; internal ram data
                            342 ;--------------------------------------------------------
                            343 	.area DSEG    (DATA)
   0024                     344 _timerbase::
   0024                     345 	.ds 8
   002C                     346 _timercnt::
   002C                     347 	.ds 8
   0034                     348 _timer::
   0034                     349 	.ds 2
   0036                     350 _Tval::
   0036                     351 	.ds 1
   0037                     352 _out_state::
   0037                     353 	.ds 1
   0038                     354 _rm_state::
   0038                     355 	.ds 1
   0039                     356 _zf_state::
   0039                     357 	.ds 1
   003A                     358 _portbuffer::
   003A                     359 	.ds 1
   003B                     360 _oldportbuffer::
   003B                     361 	.ds 1
   003C                     362 _blocked::
   003C                     363 	.ds 1
   003D                     364 _logicstate::
   003D                     365 	.ds 1
   003E                     366 _rm_send::
   003E                     367 	.ds 1
                            368 ;--------------------------------------------------------
                            369 ; overlayable items in internal ram 
                            370 ;--------------------------------------------------------
                            371 ;--------------------------------------------------------
                            372 ; indirectly addressable internal ram data
                            373 ;--------------------------------------------------------
                            374 	.area ISEG    (DATA)
                            375 ;--------------------------------------------------------
                            376 ; absolute internal ram data
                            377 ;--------------------------------------------------------
                            378 	.area IABS    (ABS,DATA)
                            379 	.area IABS    (ABS,DATA)
                            380 ;--------------------------------------------------------
                            381 ; bit data
                            382 ;--------------------------------------------------------
                            383 	.area BSEG    (BIT)
   0000                     384 _delay_toggle::
   0000                     385 	.ds 1
   0001                     386 _portchanged::
   0001                     387 	.ds 1
                            388 ;--------------------------------------------------------
                            389 ; paged external ram data
                            390 ;--------------------------------------------------------
                            391 	.area PSEG    (PAG,XDATA)
                            392 ;--------------------------------------------------------
                            393 ; external ram data
                            394 ;--------------------------------------------------------
                            395 	.area XSEG    (XDATA)
                            396 ;--------------------------------------------------------
                            397 ; absolute external ram data
                            398 ;--------------------------------------------------------
                            399 	.area XABS    (ABS,XDATA)
                            400 ;--------------------------------------------------------
                            401 ; external initialized ram data
                            402 ;--------------------------------------------------------
                            403 	.area XISEG   (XDATA)
                            404 	.area HOME    (CODE)
                            405 	.area GSINIT0 (CODE)
                            406 	.area GSINIT1 (CODE)
                            407 	.area GSINIT2 (CODE)
                            408 	.area GSINIT3 (CODE)
                            409 	.area GSINIT4 (CODE)
                            410 	.area GSINIT5 (CODE)
                            411 	.area GSINIT  (CODE)
                            412 	.area GSFINAL (CODE)
                            413 	.area CSEG    (CODE)
                            414 ;--------------------------------------------------------
                            415 ; global & static initialisations
                            416 ;--------------------------------------------------------
                            417 	.area HOME    (CODE)
                            418 	.area GSINIT  (CODE)
                            419 	.area GSFINAL (CODE)
                            420 	.area GSINIT  (CODE)
                            421 ;--------------------------------------------------------
                            422 ; Home
                            423 ;--------------------------------------------------------
                            424 	.area HOME    (CODE)
                            425 	.area HOME    (CODE)
                            426 ;--------------------------------------------------------
                            427 ; code
                            428 ;--------------------------------------------------------
                            429 	.area CSEG    (CODE)
                            430 ;------------------------------------------------------------
                            431 ;Allocation info for local variables in function 'write_value_req'
                            432 ;------------------------------------------------------------
                            433 ;objno                     Allocated to registers r4 
                            434 ;objflags                  Allocated to registers 
                            435 ;assno                     Allocated to registers r6 
                            436 ;n                         Allocated to stack - _bp +1
                            437 ;gaposh                    Allocated to registers r4 
                            438 ;zfout                     Allocated to stack - _bp +2
                            439 ;zftyp                     Allocated to registers r7 
                            440 ;gapos                     Allocated to stack - _bp +3
                            441 ;blockstart                Allocated to stack - _bp +4
                            442 ;blockend                  Allocated to stack - _bp +5
                            443 ;block_polarity            Allocated to registers r7 
                            444 ;obj_bitpattern            Allocated to registers r3 
                            445 ;zf_bitpattern             Allocated to registers r2 
                            446 ;sloc0                     Allocated to stack - _bp +14
                            447 ;sloc1                     Allocated to stack - _bp +16
                            448 ;------------------------------------------------------------
                            449 ;	../fb_app_out.c:75: void write_value_req(void) 				// Ausg�nge schalten gem�� EIS 1 Protokoll (an/aus)
                            450 ;	-----------------------------------------
                            451 ;	 function write_value_req
                            452 ;	-----------------------------------------
   007F                     453 _write_value_req:
                    0007    454 	ar7 = 0x07
                    0006    455 	ar6 = 0x06
                    0005    456 	ar5 = 0x05
                    0004    457 	ar4 = 0x04
                    0003    458 	ar3 = 0x03
                    0002    459 	ar2 = 0x02
                    0001    460 	ar1 = 0x01
                    0000    461 	ar0 = 0x00
   007F C0 08               462 	push	_bp
   0081 E5 81               463 	mov	a,sp
   0083 F5 08               464 	mov	_bp,a
   0085 24 05               465 	add	a,#0x05
   0087 F5 81               466 	mov	sp,a
                            467 ;	../fb_app_out.c:83: gapos=gapos_in_gat(telegramm[3],telegramm[4]);	// Position der Gruppenadresse in der Adresstabelle
   0089 85 49 82            468 	mov	dpl,(_telegramm + 0x0003)
   008C C0 4A               469 	push	(_telegramm + 0x0004)
   008E 12 13 7F            470 	lcall	_gapos_in_gat
   0091 AF 82               471 	mov	r7,dpl
   0093 15 81               472 	dec	sp
   0095 E5 08               473 	mov	a,_bp
   0097 24 03               474 	add	a,#0x03
   0099 F8                  475 	mov	r0,a
   009A A6 07               476 	mov	@r0,ar7
                            477 ;	../fb_app_out.c:84: if (gapos!=0xFF)					// =0xFF falls nicht vorhanden
   009C E5 08               478 	mov	a,_bp
   009E 24 03               479 	add	a,#0x03
   00A0 F8                  480 	mov	r0,a
   00A1 B6 FF 03            481 	cjne	@r0,#0xFF,00204$
   00A4 02 03 A2            482 	ljmp	00149$
   00A7                     483 00204$:
                            484 ;	../fb_app_out.c:87: assno=eeprom[eeprom[ASSOCTABPTR]];				// Erster Eintrag = Anzahl Eintr�ge
   00A7 90 1D 11            485 	mov	dptr,#(_eeprom + 0x0011)
   00AA E4                  486 	clr	a
   00AB 93                  487 	movc	a,@a+dptr
   00AC F5 82               488 	mov	dpl,a
   00AE 75 83 1D            489 	mov	dph,#(_eeprom >> 8)
   00B1 E4                  490 	clr	a
   00B2 93                  491 	movc	a,@a+dptr
   00B3 FE                  492 	mov	r6,a
                            493 ;	../fb_app_out.c:89: for(n=0;n<assno;n++)				// Schleife �ber alle Eintr�ge in der Ass-Table, denn es k�nnten mehrere Objekte (Pins) der gleichen Gruppenadresse zugeordnet sein
   00B4 A8 08               494 	mov	r0,_bp
   00B6 08                  495 	inc	r0
   00B7 76 00               496 	mov	@r0,#0x00
   00B9                     497 00145$:
   00B9 A8 08               498 	mov	r0,_bp
   00BB 08                  499 	inc	r0
   00BC C3                  500 	clr	c
   00BD E6                  501 	mov	a,@r0
   00BE 9E                  502 	subb	a,r6
   00BF 40 03               503 	jc	00205$
   00C1 02 03 99            504 	ljmp	00148$
   00C4                     505 00205$:
                            506 ;	../fb_app_out.c:91: gaposh=eeprom[eeprom[ASSOCTABPTR]+1+(n*2)];
   00C4 90 1D 11            507 	mov	dptr,#(_eeprom + 0x0011)
   00C7 E4                  508 	clr	a
   00C8 93                  509 	movc	a,@a+dptr
   00C9 FC                  510 	mov	r4,a
   00CA 0C                  511 	inc	r4
   00CB A8 08               512 	mov	r0,_bp
   00CD 08                  513 	inc	r0
   00CE E6                  514 	mov	a,@r0
   00CF 25 E0               515 	add	a,acc
   00D1 FB                  516 	mov	r3,a
   00D2 2C                  517 	add	a,r4
   00D3 90 1D 00            518 	mov	dptr,#_eeprom
   00D6 93                  519 	movc	a,@a+dptr
   00D7 FC                  520 	mov	r4,a
                            521 ;	../fb_app_out.c:92: if(gapos==gaposh)					// Wenn Positionsnummer �bereinstimmt
   00D8 E5 08               522 	mov	a,_bp
   00DA 24 03               523 	add	a,#0x03
   00DC F8                  524 	mov	r0,a
   00DD E6                  525 	mov	a,@r0
   00DE B5 04 02            526 	cjne	a,ar4,00206$
   00E1 80 03               527 	sjmp	00207$
   00E3                     528 00206$:
   00E3 02 03 92            529 	ljmp	00147$
   00E6                     530 00207$:
                            531 ;	../fb_app_out.c:94: objno=eeprom[eeprom[ASSOCTABPTR]+2+(n*2)];				// Objektnummer
   00E6 90 1D 11            532 	mov	dptr,#(_eeprom + 0x0011)
   00E9 E4                  533 	clr	a
   00EA 93                  534 	movc	a,@a+dptr
   00EB 24 02               535 	add	a,#0x02
   00ED 2B                  536 	add	a,r3
   00EE 90 1D 00            537 	mov	dptr,#_eeprom
   00F1 93                  538 	movc	a,@a+dptr
                            539 ;	../fb_app_out.c:95: objflags=read_objflags(objno);			// Objekt Flags lesen
   00F2 FC                  540 	mov	r4,a
   00F3 F5 82               541 	mov	dpl,a
   00F5 C0 06               542 	push	ar6
   00F7 C0 04               543 	push	ar4
   00F9 12 17 F8            544 	lcall	_read_objflags
   00FC D0 04               545 	pop	ar4
   00FE D0 06               546 	pop	ar6
                            547 ;	../fb_app_out.c:97: obj_bitpattern=0x01<<(objno-8);
   0100 EC                  548 	mov	a,r4
   0101 24 F8               549 	add	a,#0xF8
   0103 FB                  550 	mov	r3,a
   0104 8B F0               551 	mov	b,r3
   0106 05 F0               552 	inc	b
   0108 74 01               553 	mov	a,#0x01
   010A 80 02               554 	sjmp	00210$
   010C                     555 00208$:
   010C 25 E0               556 	add	a,acc
   010E                     557 00210$:
   010E D5 F0 FB            558 	djnz	b,00208$
   0111 FB                  559 	mov	r3,a
                            560 ;	../fb_app_out.c:99: if (objno<8) object_schalten(objno,telegramm[7]&0x01);	// Objektnummer 0-7 entspricht den Ausg�ngen 1-8
   0112 BC 08 00            561 	cjne	r4,#0x08,00211$
   0115                     562 00211$:
   0115 50 1E               563 	jnc	00102$
   0117 E5 4D               564 	mov	a,(_telegramm + 0x0007)
   0119 54 01               565 	anl	a,#0x01
   011B 24 FF               566 	add	a,#0xff
   011D 92 18               567 	mov  b0,c
   011F 92 F0               568 	mov	b[0],c
   0121 C0 06               569 	push	ar6
   0123 C0 04               570 	push	ar4
   0125 C0 03               571 	push	ar3
   0127 85 F0 23            572 	mov	bits,b
   012A 8C 82               573 	mov	dpl,r4
   012C 12 05 3E            574 	lcall	_object_schalten
   012F D0 03               575 	pop	ar3
   0131 D0 04               576 	pop	ar4
   0133 D0 06               577 	pop	ar6
   0135                     578 00102$:
                            579 ;	../fb_app_out.c:101: if (objno>7 && objno<12)	// Objektnummer 8-11 entspricht den Zusatzfunktionen 1-4
   0135 EC                  580 	mov	a,r4
   0136 24 F8               581 	add	a,#0xff - 0x07
   0138 40 03               582 	jc	00213$
   013A 02 03 92            583 	ljmp	00147$
   013D                     584 00213$:
   013D BC 0C 00            585 	cjne	r4,#0x0C,00214$
   0140                     586 00214$:
   0140 40 03               587 	jc	00215$
   0142 02 03 92            588 	ljmp	00147$
   0145                     589 00215$:
                            590 ;	../fb_app_out.c:103: write_obj_value(objno, telegramm[7]&0x01);
   0145 C0 03               591 	push	ar3
   0147 74 01               592 	mov	a,#0x01
   0149 55 4D               593 	anl	a,(_telegramm + 0x0007)
   014B FA                  594 	mov	r2,a
   014C 7B 00               595 	mov	r3,#0x00
   014E C0 06               596 	push	ar6
   0150 C0 04               597 	push	ar4
   0152 C0 03               598 	push	ar3
   0154 C0 02               599 	push	ar2
   0156 C0 03               600 	push	ar3
   0158 8C 82               601 	mov	dpl,r4
   015A 12 04 83            602 	lcall	_write_obj_value
   015D 15 81               603 	dec	sp
   015F 15 81               604 	dec	sp
   0161 D0 03               605 	pop	ar3
   0163 D0 04               606 	pop	ar4
   0165 D0 06               607 	pop	ar6
                            608 ;	../fb_app_out.c:104: zfout=0;
   0167 A8 08               609 	mov	r0,_bp
   0169 08                  610 	inc	r0
   016A 08                  611 	inc	r0
   016B 76 00               612 	mov	@r0,#0x00
                            613 ;	../fb_app_out.c:105: blockstart=0;
   016D E5 08               614 	mov	a,_bp
   016F 24 04               615 	add	a,#0x04
   0171 F8                  616 	mov	r0,a
   0172 76 00               617 	mov	@r0,#0x00
                            618 ;	../fb_app_out.c:106: blockend=0;
   0174 E5 08               619 	mov	a,_bp
   0176 24 05               620 	add	a,#0x05
   0178 F8                  621 	mov	r0,a
   0179 76 00               622 	mov	@r0,#0x00
                            623 ;	../fb_app_out.c:107: switch (objno-8)			// Zugeordneten Ausgang zu Zusatzfunktionsnr. in zfout speichern (1-8)
   017B 8C 07               624 	mov	ar7,r4
   017D 7D 00               625 	mov	r5,#0x00
   017F EF                  626 	mov	a,r7
   0180 24 F8               627 	add	a,#0xF8
   0182 FC                  628 	mov	r4,a
   0183 ED                  629 	mov	a,r5
   0184 34 FF               630 	addc	a,#0xFF
   0186 FA                  631 	mov	r2,a
   0187 BC 00 07            632 	cjne	r4,#0x00,00216$
   018A BA 00 04            633 	cjne	r2,#0x00,00216$
   018D D0 03               634 	pop	ar3
   018F 80 1E               635 	sjmp	00103$
   0191                     636 00216$:
   0191 D0 03               637 	pop	ar3
   0193 BC 01 05            638 	cjne	r4,#0x01,00217$
   0196 BA 00 02            639 	cjne	r2,#0x00,00217$
   0199 80 47               640 	sjmp	00104$
   019B                     641 00217$:
   019B BC 02 05            642 	cjne	r4,#0x02,00218$
   019E BA 00 02            643 	cjne	r2,#0x00,00218$
   01A1 80 78               644 	sjmp	00105$
   01A3                     645 00218$:
   01A3 BC 03 06            646 	cjne	r4,#0x03,00219$
   01A6 BA 00 03            647 	cjne	r2,#0x00,00219$
   01A9 02 02 4D            648 	ljmp	00106$
   01AC                     649 00219$:
   01AC 02 02 84            650 	ljmp	00107$
                            651 ;	../fb_app_out.c:109: case 0x00:		
   01AF                     652 00103$:
                            653 ;	../fb_app_out.c:110: zfout=eeprom[FUNCASS]&0x0F;
   01AF 90 1D D8            654 	mov	dptr,#(_eeprom + 0x00d8)
   01B2 E4                  655 	clr	a
   01B3 93                  656 	movc	a,@a+dptr
   01B4 FC                  657 	mov	r4,a
   01B5 A8 08               658 	mov	r0,_bp
   01B7 08                  659 	inc	r0
   01B8 08                  660 	inc	r0
   01B9 74 0F               661 	mov	a,#0x0F
   01BB 5C                  662 	anl	a,r4
   01BC F6                  663 	mov	@r0,a
                            664 ;	../fb_app_out.c:111: blockstart=eeprom[BLOCKACT]&0x03;		// Verhalten bei Beginn der Sperrung
   01BD 90 1D EF            665 	mov	dptr,#(_eeprom + 0x00ef)
   01C0 E4                  666 	clr	a
   01C1 93                  667 	movc	a,@a+dptr
   01C2 FC                  668 	mov	r4,a
   01C3 E5 08               669 	mov	a,_bp
   01C5 24 04               670 	add	a,#0x04
   01C7 F8                  671 	mov	r0,a
   01C8 74 03               672 	mov	a,#0x03
   01CA 5C                  673 	anl	a,r4
   01CB F6                  674 	mov	@r0,a
                            675 ;	../fb_app_out.c:112: blockend=(eeprom[BLOCKACT]>>2)&0x03;	// Verhalten bei Ende der Sperrung
   01CC 90 1D EF            676 	mov	dptr,#(_eeprom + 0x00ef)
   01CF E4                  677 	clr	a
   01D0 93                  678 	movc	a,@a+dptr
   01D1 03                  679 	rr	a
   01D2 03                  680 	rr	a
   01D3 54 3F               681 	anl	a,#0x3F
   01D5 FC                  682 	mov	r4,a
   01D6 E5 08               683 	mov	a,_bp
   01D8 24 05               684 	add	a,#0x05
   01DA F8                  685 	mov	r0,a
   01DB 74 03               686 	mov	a,#0x03
   01DD 5C                  687 	anl	a,r4
   01DE F6                  688 	mov	@r0,a
                            689 ;	../fb_app_out.c:113: break;
   01DF 02 02 84            690 	ljmp	00107$
                            691 ;	../fb_app_out.c:114: case 0x01:
   01E2                     692 00104$:
                            693 ;	../fb_app_out.c:115: zfout=(eeprom[FUNCASS]&0xF0)>>4;
   01E2 90 1D D8            694 	mov	dptr,#(_eeprom + 0x00d8)
   01E5 E4                  695 	clr	a
   01E6 93                  696 	movc	a,@a+dptr
   01E7 FC                  697 	mov	r4,a
   01E8 53 04 F0            698 	anl	ar4,#0xF0
   01EB A8 08               699 	mov	r0,_bp
   01ED 08                  700 	inc	r0
   01EE 08                  701 	inc	r0
   01EF EC                  702 	mov	a,r4
   01F0 C4                  703 	swap	a
   01F1 54 0F               704 	anl	a,#0x0F
   01F3 F6                  705 	mov	@r0,a
                            706 ;	../fb_app_out.c:116: blockstart=(eeprom[BLOCKACT]>>4)&0x03;	// Verhalten bei Beginn der Sperrung
   01F4 90 1D EF            707 	mov	dptr,#(_eeprom + 0x00ef)
   01F7 E4                  708 	clr	a
   01F8 93                  709 	movc	a,@a+dptr
   01F9 C4                  710 	swap	a
   01FA 54 0F               711 	anl	a,#0x0F
   01FC FC                  712 	mov	r4,a
   01FD E5 08               713 	mov	a,_bp
   01FF 24 04               714 	add	a,#0x04
   0201 F8                  715 	mov	r0,a
   0202 74 03               716 	mov	a,#0x03
   0204 5C                  717 	anl	a,r4
   0205 F6                  718 	mov	@r0,a
                            719 ;	../fb_app_out.c:117: blockend=(eeprom[BLOCKACT]>>6)&0x03;	// Verhalten bei Ende der Sperrung
   0206 90 1D EF            720 	mov	dptr,#(_eeprom + 0x00ef)
   0209 E4                  721 	clr	a
   020A 93                  722 	movc	a,@a+dptr
   020B 23                  723 	rl	a
   020C 23                  724 	rl	a
   020D 54 03               725 	anl	a,#0x03
   020F FC                  726 	mov	r4,a
   0210 E5 08               727 	mov	a,_bp
   0212 24 05               728 	add	a,#0x05
   0214 F8                  729 	mov	r0,a
   0215 74 03               730 	mov	a,#0x03
   0217 5C                  731 	anl	a,r4
   0218 F6                  732 	mov	@r0,a
                            733 ;	../fb_app_out.c:118: break;
                            734 ;	../fb_app_out.c:119: case 0x02:
   0219 80 69               735 	sjmp	00107$
   021B                     736 00105$:
                            737 ;	../fb_app_out.c:120: zfout=eeprom[FUNCASS+1]&0x0F;
   021B 90 1D D9            738 	mov	dptr,#(_eeprom + 0x00d9)
   021E E4                  739 	clr	a
   021F 93                  740 	movc	a,@a+dptr
   0220 FC                  741 	mov	r4,a
   0221 A8 08               742 	mov	r0,_bp
   0223 08                  743 	inc	r0
   0224 08                  744 	inc	r0
   0225 74 0F               745 	mov	a,#0x0F
   0227 5C                  746 	anl	a,r4
   0228 F6                  747 	mov	@r0,a
                            748 ;	../fb_app_out.c:121: blockstart=eeprom[BLOCKACT+1]&0x03;		// Verhalten bei Beginn der Sperrung
   0229 90 1D F0            749 	mov	dptr,#(_eeprom + 0x00f0)
   022C E4                  750 	clr	a
   022D 93                  751 	movc	a,@a+dptr
   022E FC                  752 	mov	r4,a
   022F E5 08               753 	mov	a,_bp
   0231 24 04               754 	add	a,#0x04
   0233 F8                  755 	mov	r0,a
   0234 74 03               756 	mov	a,#0x03
   0236 5C                  757 	anl	a,r4
   0237 F6                  758 	mov	@r0,a
                            759 ;	../fb_app_out.c:122: blockend=(eeprom[BLOCKACT+1]>>2)&0x03;	// Verhalten bei Ende der Sperrung
   0238 90 1D F0            760 	mov	dptr,#(_eeprom + 0x00f0)
   023B E4                  761 	clr	a
   023C 93                  762 	movc	a,@a+dptr
   023D 03                  763 	rr	a
   023E 03                  764 	rr	a
   023F 54 3F               765 	anl	a,#0x3F
   0241 FC                  766 	mov	r4,a
   0242 E5 08               767 	mov	a,_bp
   0244 24 05               768 	add	a,#0x05
   0246 F8                  769 	mov	r0,a
   0247 74 03               770 	mov	a,#0x03
   0249 5C                  771 	anl	a,r4
   024A F6                  772 	mov	@r0,a
                            773 ;	../fb_app_out.c:123: break;
                            774 ;	../fb_app_out.c:124: case 0x03:
   024B 80 37               775 	sjmp	00107$
   024D                     776 00106$:
                            777 ;	../fb_app_out.c:125: zfout=(eeprom[FUNCASS+1]&0xF0)>>4;
   024D 90 1D D9            778 	mov	dptr,#(_eeprom + 0x00d9)
   0250 E4                  779 	clr	a
   0251 93                  780 	movc	a,@a+dptr
   0252 FC                  781 	mov	r4,a
   0253 53 04 F0            782 	anl	ar4,#0xF0
   0256 A8 08               783 	mov	r0,_bp
   0258 08                  784 	inc	r0
   0259 08                  785 	inc	r0
   025A EC                  786 	mov	a,r4
   025B C4                  787 	swap	a
   025C 54 0F               788 	anl	a,#0x0F
   025E F6                  789 	mov	@r0,a
                            790 ;	../fb_app_out.c:126: blockstart=(eeprom[BLOCKACT+1]>>4)&0x03;	// Verhalten bei Beginn der Sperrung
   025F 90 1D F0            791 	mov	dptr,#(_eeprom + 0x00f0)
   0262 E4                  792 	clr	a
   0263 93                  793 	movc	a,@a+dptr
   0264 C4                  794 	swap	a
   0265 54 0F               795 	anl	a,#0x0F
   0267 FC                  796 	mov	r4,a
   0268 E5 08               797 	mov	a,_bp
   026A 24 04               798 	add	a,#0x04
   026C F8                  799 	mov	r0,a
   026D 74 03               800 	mov	a,#0x03
   026F 5C                  801 	anl	a,r4
   0270 F6                  802 	mov	@r0,a
                            803 ;	../fb_app_out.c:127: blockend=(eeprom[BLOCKACT+1]>>6)&0x03;		// Verhalten bei Ende der Sperrung
   0271 90 1D F0            804 	mov	dptr,#(_eeprom + 0x00f0)
   0274 E4                  805 	clr	a
   0275 93                  806 	movc	a,@a+dptr
   0276 23                  807 	rl	a
   0277 23                  808 	rl	a
   0278 54 03               809 	anl	a,#0x03
   027A FC                  810 	mov	r4,a
   027B E5 08               811 	mov	a,_bp
   027D 24 05               812 	add	a,#0x05
   027F F8                  813 	mov	r0,a
   0280 74 03               814 	mov	a,#0x03
   0282 5C                  815 	anl	a,r4
   0283 F6                  816 	mov	@r0,a
                            817 ;	../fb_app_out.c:128: }
   0284                     818 00107$:
                            819 ;	../fb_app_out.c:129: zftyp=((eeprom[FUNCTYP])>>((objno-8)*2)) & 0x03;	// Typ der Zusatzfunktion
   0284 C0 03               820 	push	ar3
   0286 90 1D ED            821 	mov	dptr,#(_eeprom + 0x00ed)
   0289 E4                  822 	clr	a
   028A 93                  823 	movc	a,@a+dptr
   028B FC                  824 	mov	r4,a
   028C EF                  825 	mov	a,r7
   028D 24 F8               826 	add	a,#0xF8
   028F FA                  827 	mov	r2,a
   0290 ED                  828 	mov	a,r5
   0291 34 FF               829 	addc	a,#0xFF
   0293 CA                  830 	xch	a,r2
   0294 25 E0               831 	add	a,acc
   0296 CA                  832 	xch	a,r2
   0297 33                  833 	rlc	a
   0298 FB                  834 	mov	r3,a
   0299 8A F0               835 	mov	b,r2
   029B 05 F0               836 	inc	b
   029D EC                  837 	mov	a,r4
   029E 80 02               838 	sjmp	00221$
   02A0                     839 00220$:
   02A0 C3                  840 	clr	c
   02A1 13                  841 	rrc	a
   02A2                     842 00221$:
   02A2 D5 F0 FB            843 	djnz	b,00220$
   02A5 FC                  844 	mov	r4,a
   02A6 74 03               845 	mov	a,#0x03
   02A8 5C                  846 	anl	a,r4
   02A9 FF                  847 	mov	r7,a
                            848 ;	../fb_app_out.c:130: zf_bitpattern=0x01<<(zfout-1);
   02AA A8 08               849 	mov	r0,_bp
   02AC 08                  850 	inc	r0
   02AD 08                  851 	inc	r0
   02AE E6                  852 	mov	a,@r0
   02AF 14                  853 	dec	a
   02B0 FC                  854 	mov	r4,a
   02B1 8C F0               855 	mov	b,r4
   02B3 05 F0               856 	inc	b
   02B5 74 01               857 	mov	a,#0x01
   02B7 80 02               858 	sjmp	00224$
   02B9                     859 00222$:
   02B9 25 E0               860 	add	a,acc
   02BB                     861 00224$:
   02BB D5 F0 FB            862 	djnz	b,00222$
   02BE FA                  863 	mov	r2,a
                            864 ;	../fb_app_out.c:132: switch (zftyp)
   02BF BF 00 04            865 	cjne	r7,#0x00,00225$
   02C2 D0 03               866 	pop	ar3
   02C4 80 0A               867 	sjmp	00108$
   02C6                     868 00225$:
   02C6 D0 03               869 	pop	ar3
   02C8 BF 01 02            870 	cjne	r7,#0x01,00226$
   02CB 80 4D               871 	sjmp	00112$
   02CD                     872 00226$:
   02CD 02 03 92            873 	ljmp	00147$
                            874 ;	../fb_app_out.c:134: case 0x00:			// Verkn�pfung
   02D0                     875 00108$:
                            876 ;	../fb_app_out.c:135: switch (telegramm[7])
   02D0 AC 4D               877 	mov	r4,(_telegramm + 0x0007)
   02D2 BC 80 02            878 	cjne	r4,#0x80,00227$
   02D5 80 05               879 	sjmp	00109$
   02D7                     880 00227$:
                            881 ;	../fb_app_out.c:137: case 0x80:
   02D7 BC 81 0D            882 	cjne	r4,#0x81,00111$
   02DA 80 08               883 	sjmp	00110$
   02DC                     884 00109$:
                            885 ;	../fb_app_out.c:138: logicstate=logicstate&(0xFF-zf_bitpattern);
   02DC 74 FF               886 	mov	a,#0xFF
   02DE C3                  887 	clr	c
   02DF 9A                  888 	subb	a,r2
   02E0 52 3D               889 	anl	_logicstate,a
                            890 ;	../fb_app_out.c:139: break;
                            891 ;	../fb_app_out.c:140: case 0x81:
   02E2 80 03               892 	sjmp	00111$
   02E4                     893 00110$:
                            894 ;	../fb_app_out.c:141: logicstate=logicstate|zf_bitpattern;
   02E4 EA                  895 	mov	a,r2
   02E5 42 3D               896 	orl	_logicstate,a
                            897 ;	../fb_app_out.c:142: }
   02E7                     898 00111$:
                            899 ;	../fb_app_out.c:143: object_schalten(zfout-1, read_obj_value(zfout-1));	//telegramm[7]&0x01);
   02E7 C0 06               900 	push	ar6
   02E9 A8 08               901 	mov	r0,_bp
   02EB 08                  902 	inc	r0
   02EC 08                  903 	inc	r0
   02ED E6                  904 	mov	a,@r0
   02EE 14                  905 	dec	a
   02EF FC                  906 	mov	r4,a
   02F0 F5 82               907 	mov	dpl,a
   02F2 C0 04               908 	push	ar4
   02F4 12 03 DB            909 	lcall	_read_obj_value
   02F7 AA 82               910 	mov	r2,dpl
   02F9 AD 83               911 	mov	r5,dph
   02FB AE F0               912 	mov	r6,b
   02FD FF                  913 	mov	r7,a
   02FE D0 04               914 	pop	ar4
   0300 EA                  915 	mov	a,r2
   0301 4D                  916 	orl	a,r5
   0302 4E                  917 	orl	a,r6
   0303 4F                  918 	orl	a,r7
   0304 24 FF               919 	add	a,#0xff
   0306 92 18               920 	mov  b0,c
   0308 92 F0               921 	mov	b[0],c
   030A C0 06               922 	push	ar6
   030C 85 F0 23            923 	mov	bits,b
   030F 8C 82               924 	mov	dpl,r4
   0311 12 05 3E            925 	lcall	_object_schalten
   0314 D0 06               926 	pop	ar6
                            927 ;	../fb_app_out.c:144: break;
   0316 D0 06               928 	pop	ar6
                            929 ;	../fb_app_out.c:145: case 0x01:			// Sperren
   0318 80 78               930 	sjmp	00147$
   031A                     931 00112$:
                            932 ;	../fb_app_out.c:146: block_polarity=eeprom[BLOCKPOL] & obj_bitpattern;
   031A 90 1D F1            933 	mov	dptr,#(_eeprom + 0x00f1)
   031D E4                  934 	clr	a
   031E 93                  935 	movc	a,@a+dptr
   031F 52 03               936 	anl	ar3,a
   0321 8B 07               937 	mov	ar7,r3
                            938 ;	../fb_app_out.c:147: if (((telegramm[7]==0x80) && (block_polarity==0)) ||
   0323 AD 4D               939 	mov	r5,(_telegramm + 0x0007)
   0325 E4                  940 	clr	a
   0326 BD 80 01            941 	cjne	r5,#0x80,00229$
   0329 04                  942 	inc	a
   032A                     943 00229$:
   032A FC                  944 	mov	r4,a
   032B 60 03               945 	jz	00123$
   032D EF                  946 	mov	a,r7
   032E 60 06               947 	jz	00119$
   0330                     948 00123$:
                            949 ;	../fb_app_out.c:148: ((telegramm[7]==0x81) && (block_polarity!=0)))
   0330 BD 81 27            950 	cjne	r5,#0x81,00120$
   0333 EF                  951 	mov	a,r7
   0334 60 24               952 	jz	00120$
   0336                     953 00119$:
                            954 ;	../fb_app_out.c:150: if((blocked & zf_bitpattern)!=0) {	// nur wenn Sperre aktiv war
   0336 EA                  955 	mov	a,r2
   0337 55 3C               956 	anl	a,_blocked
   0339 60 1F               957 	jz	00120$
                            958 ;	../fb_app_out.c:151: blocked=blocked&(0xFF-zf_bitpattern);
   033B 74 FF               959 	mov	a,#0xFF
   033D C3                  960 	clr	c
   033E 9A                  961 	subb	a,r2
   033F 52 3C               962 	anl	_blocked,a
                            963 ;	../fb_app_out.c:152: if (blockend==0x01) portbuffer=portbuffer&(0xFF-zf_bitpattern);	// Bei Ende der Sperrung ausschalten
   0341 E5 08               964 	mov	a,_bp
   0343 24 05               965 	add	a,#0x05
   0345 F8                  966 	mov	r0,a
   0346 B6 01 06            967 	cjne	@r0,#0x01,00114$
   0349 74 FF               968 	mov	a,#0xFF
   034B C3                  969 	clr	c
   034C 9A                  970 	subb	a,r2
   034D 52 3A               971 	anl	_portbuffer,a
   034F                     972 00114$:
                            973 ;	../fb_app_out.c:153: if (blockend==0x02) portbuffer=portbuffer|zf_bitpattern;		// Bei Ende der Sperrung einschalten
   034F E5 08               974 	mov	a,_bp
   0351 24 05               975 	add	a,#0x05
   0353 F8                  976 	mov	r0,a
   0354 B6 02 03            977 	cjne	@r0,#0x02,00120$
   0357 EA                  978 	mov	a,r2
   0358 42 3A               979 	orl	_portbuffer,a
   035A                     980 00120$:
                            981 ;	../fb_app_out.c:157: if (((telegramm[7]==0x81) && (block_polarity==0)) ||
   035A BD 81 03            982 	cjne	r5,#0x81,00134$
   035D EF                  983 	mov	a,r7
   035E 60 06               984 	jz	00130$
   0360                     985 00134$:
                            986 ;	../fb_app_out.c:158: ((telegramm[7]==0x80) && (block_polarity!=0)))
   0360 EC                  987 	mov	a,r4
   0361 60 2F               988 	jz	00147$
   0363 EF                  989 	mov	a,r7
   0364 60 2C               990 	jz	00147$
   0366                     991 00130$:
                            992 ;	../fb_app_out.c:160: if((blocked & zf_bitpattern)==0) {	// nur wenn Sperre inaktiv war
   0366 EA                  993 	mov	a,r2
   0367 55 3C               994 	anl	a,_blocked
   0369 70 27               995 	jnz	00147$
                            996 ;	../fb_app_out.c:161: blocked=blocked|zf_bitpattern;
   036B EA                  997 	mov	a,r2
   036C 42 3C               998 	orl	_blocked,a
                            999 ;	../fb_app_out.c:162: if (blockstart==0x01) portbuffer=portbuffer&(0xFF-zf_bitpattern);	// Bei Beginn der Sperrung ausschalten
   036E E5 08              1000 	mov	a,_bp
   0370 24 04              1001 	add	a,#0x04
   0372 F8                 1002 	mov	r0,a
   0373 B6 01 06           1003 	cjne	@r0,#0x01,00125$
   0376 74 FF              1004 	mov	a,#0xFF
   0378 C3                 1005 	clr	c
   0379 9A                 1006 	subb	a,r2
   037A 52 3A              1007 	anl	_portbuffer,a
   037C                    1008 00125$:
                           1009 ;	../fb_app_out.c:163: if (blockstart==0x02) portbuffer=portbuffer|zf_bitpattern;		// Bei Beginn der Sperrung einschalten
   037C E5 08              1010 	mov	a,_bp
   037E 24 04              1011 	add	a,#0x04
   0380 F8                 1012 	mov	r0,a
   0381 B6 02 03           1013 	cjne	@r0,#0x02,00127$
   0384 EA                 1014 	mov	a,r2
   0385 42 3A              1015 	orl	_portbuffer,a
   0387                    1016 00127$:
                           1017 ;	../fb_app_out.c:164: timercnt[zfout-1]=0;//delrec[(zfout-1)*4]=0;	// ggf. Eintrag f�r Schaltverz�gerung l�schen
   0387 A8 08              1018 	mov	r0,_bp
   0389 08                 1019 	inc	r0
   038A 08                 1020 	inc	r0
   038B E6                 1021 	mov	a,@r0
   038C 14                 1022 	dec	a
   038D 24 2C              1023 	add	a,#_timercnt
   038F F8                 1024 	mov	r0,a
   0390 76 00              1025 	mov	@r0,#0x00
                           1026 ;	../fb_app_out.c:170: }
   0392                    1027 00147$:
                           1028 ;	../fb_app_out.c:89: for(n=0;n<assno;n++)				// Schleife �ber alle Eintr�ge in der Ass-Table, denn es k�nnten mehrere Objekte (Pins) der gleichen Gruppenadresse zugeordnet sein
   0392 A8 08              1029 	mov	r0,_bp
   0394 08                 1030 	inc	r0
   0395 06                 1031 	inc	@r0
   0396 02 00 B9           1032 	ljmp	00145$
   0399                    1033 00148$:
                           1034 ;	../fb_app_out.c:174: if (portbuffer != oldportbuffer) portchanged=1;//post f�r port_schalten hinterlegen
   0399 E5 3B              1035 	mov	a,_oldportbuffer
   039B B5 3A 02           1036 	cjne	a,_portbuffer,00251$
   039E 80 02              1037 	sjmp	00149$
   03A0                    1038 00251$:
   03A0 D2 01              1039 	setb	_portchanged
   03A2                    1040 00149$:
   03A2 85 08 81           1041 	mov	sp,_bp
   03A5 D0 08              1042 	pop	_bp
   03A7 22                 1043 	ret
                           1044 ;------------------------------------------------------------
                           1045 ;Allocation info for local variables in function 'read_value_req'
                           1046 ;------------------------------------------------------------
                           1047 ;objno                     Allocated to registers r7 
                           1048 ;objflags                  Allocated to registers r6 
                           1049 ;objvalue                  Allocated to registers 
                           1050 ;------------------------------------------------------------
                           1051 ;	../fb_app_out.c:189: void read_value_req(void)
                           1052 ;	-----------------------------------------
                           1053 ;	 function read_value_req
                           1054 ;	-----------------------------------------
   03A8                    1055 _read_value_req:
                           1056 ;	../fb_app_out.c:194: objno=find_first_objno(telegramm[3],telegramm[4]);	// erste Objektnummer zu empfangener GA finden
   03A8 85 49 82           1057 	mov	dpl,(_telegramm + 0x0003)
   03AB C0 4A              1058 	push	(_telegramm + 0x0004)
   03AD 12 18 10           1059 	lcall	_find_first_objno
   03B0 AF 82              1060 	mov	r7,dpl
   03B2 15 81              1061 	dec	sp
                           1062 ;	../fb_app_out.c:195: if(objno!=0xFF) {	// falls Gruppenadresse nicht gefunden
   03B4 BF FF 01           1063 	cjne	r7,#0xFF,00111$
   03B7 22                 1064 	ret
   03B8                    1065 00111$:
                           1066 ;	../fb_app_out.c:197: objvalue=read_obj_value(objno);		// Objektwert aus USER-RAM lesen (Standard Einstellung)
   03B8 8F 82              1067 	mov	dpl,r7
   03BA C0 07              1068 	push	ar7
   03BC 12 03 DB           1069 	lcall	_read_obj_value
   03BF D0 07              1070 	pop	ar7
                           1071 ;	../fb_app_out.c:199: objflags=read_objflags(objno);		// Objekt Flags lesen
   03C1 8F 82              1072 	mov	dpl,r7
   03C3 C0 07              1073 	push	ar7
   03C5 12 17 F8           1074 	lcall	_read_objflags
   03C8 AE 82              1075 	mov	r6,dpl
   03CA D0 07              1076 	pop	ar7
                           1077 ;	../fb_app_out.c:201: if((objflags&0x0C)==0x0C) send_obj_value(objno+64); //send_value(0,objno,objvalue);
   03CC 53 06 0C           1078 	anl	ar6,#0x0C
   03CF BE 0C 08           1079 	cjne	r6,#0x0C,00105$
   03D2 74 40              1080 	mov	a,#0x40
   03D4 2F                 1081 	add	a,r7
   03D5 F5 82              1082 	mov	dpl,a
   03D7 02 15 CC           1083 	ljmp	_send_obj_value
   03DA                    1084 00105$:
   03DA 22                 1085 	ret
                           1086 ;------------------------------------------------------------
                           1087 ;Allocation info for local variables in function 'read_obj_value'
                           1088 ;------------------------------------------------------------
                           1089 ;objno                     Allocated to registers r7 
                           1090 ;ret_val                   Allocated to registers r6 
                           1091 ;------------------------------------------------------------
                           1092 ;	../fb_app_out.c:206: unsigned long read_obj_value(unsigned char objno) 	// gibt den Wert eines Objektes zurueck
                           1093 ;	-----------------------------------------
                           1094 ;	 function read_obj_value
                           1095 ;	-----------------------------------------
   03DB                    1096 _read_obj_value:
   03DB AF 82              1097 	mov	r7,dpl
                           1098 ;	../fb_app_out.c:208: unsigned char ret_val=0;
   03DD 7E 00              1099 	mov	r6,#0x00
                           1100 ;	../fb_app_out.c:210: if(objno<8) {
   03DF BF 08 00           1101 	cjne	r7,#0x08,00130$
   03E2                    1102 00130$:
   03E2 E4                 1103 	clr	a
   03E3 33                 1104 	rlc	a
   03E4 FD                 1105 	mov	r5,a
   03E5 60 27              1106 	jz	00104$
                           1107 ;	../fb_app_out.c:211: if(out_state&(1<<objno)) ret_val=1;
   03E7 C0 06              1108 	push	ar6
   03E9 8F F0              1109 	mov	b,r7
   03EB 05 F0              1110 	inc	b
   03ED 7B 01              1111 	mov	r3,#0x01
   03EF 7C 00              1112 	mov	r4,#0x00
   03F1 80 06              1113 	sjmp	00133$
   03F3                    1114 00132$:
   03F3 EB                 1115 	mov	a,r3
   03F4 2B                 1116 	add	a,r3
   03F5 FB                 1117 	mov	r3,a
   03F6 EC                 1118 	mov	a,r4
   03F7 33                 1119 	rlc	a
   03F8 FC                 1120 	mov	r4,a
   03F9                    1121 00133$:
   03F9 D5 F0 F7           1122 	djnz	b,00132$
   03FC AA 37              1123 	mov	r2,_out_state
   03FE 7E 00              1124 	mov	r6,#0x00
   0400 EA                 1125 	mov	a,r2
   0401 52 03              1126 	anl	ar3,a
   0403 EE                 1127 	mov	a,r6
   0404 52 04              1128 	anl	ar4,a
   0406 D0 06              1129 	pop	ar6
   0408 EB                 1130 	mov	a,r3
   0409 4C                 1131 	orl	a,r4
   040A 60 02              1132 	jz	00104$
   040C 7E 01              1133 	mov	r6,#0x01
   040E                    1134 00104$:
                           1135 ;	../fb_app_out.c:213: if(objno>=8 && objno<12) {
   040E ED                 1136 	mov	a,r5
   040F 70 33              1137 	jnz	00108$
   0411 BF 0C 00           1138 	cjne	r7,#0x0C,00136$
   0414                    1139 00136$:
   0414 50 2E              1140 	jnc	00108$
                           1141 ;	../fb_app_out.c:214: if(zf_state&(1<<(objno-8))) ret_val=1;
   0416 8F 04              1142 	mov	ar4,r7
   0418 7D 00              1143 	mov	r5,#0x00
   041A EC                 1144 	mov	a,r4
   041B 24 F8              1145 	add	a,#0xF8
   041D FC                 1146 	mov	r4,a
   041E ED                 1147 	mov	a,r5
   041F 34 FF              1148 	addc	a,#0xFF
   0421 8C F0              1149 	mov	b,r4
   0423 05 F0              1150 	inc	b
   0425 7C 01              1151 	mov	r4,#0x01
   0427 7D 00              1152 	mov	r5,#0x00
   0429 80 06              1153 	sjmp	00139$
   042B                    1154 00138$:
   042B EC                 1155 	mov	a,r4
   042C 2C                 1156 	add	a,r4
   042D FC                 1157 	mov	r4,a
   042E ED                 1158 	mov	a,r5
   042F 33                 1159 	rlc	a
   0430 FD                 1160 	mov	r5,a
   0431                    1161 00139$:
   0431 D5 F0 F7           1162 	djnz	b,00138$
   0434 AA 39              1163 	mov	r2,_zf_state
   0436 7B 00              1164 	mov	r3,#0x00
   0438 EA                 1165 	mov	a,r2
   0439 52 04              1166 	anl	ar4,a
   043B EB                 1167 	mov	a,r3
   043C 52 05              1168 	anl	ar5,a
   043E EC                 1169 	mov	a,r4
   043F 4D                 1170 	orl	a,r5
   0440 60 02              1171 	jz	00108$
   0442 7E 01              1172 	mov	r6,#0x01
   0444                    1173 00108$:
                           1174 ;	../fb_app_out.c:216: if(objno>=12) {
   0444 BF 0C 00           1175 	cjne	r7,#0x0C,00141$
   0447                    1176 00141$:
   0447 40 2C              1177 	jc	00113$
                           1178 ;	../fb_app_out.c:217: if(rm_state&(1<<(objno-12))) ret_val=1;
   0449 7D 00              1179 	mov	r5,#0x00
   044B EF                 1180 	mov	a,r7
   044C 24 F4              1181 	add	a,#0xF4
   044E FF                 1182 	mov	r7,a
   044F ED                 1183 	mov	a,r5
   0450 34 FF              1184 	addc	a,#0xFF
   0452 8F F0              1185 	mov	b,r7
   0454 05 F0              1186 	inc	b
   0456 7F 01              1187 	mov	r7,#0x01
   0458 7D 00              1188 	mov	r5,#0x00
   045A 80 06              1189 	sjmp	00144$
   045C                    1190 00143$:
   045C EF                 1191 	mov	a,r7
   045D 2F                 1192 	add	a,r7
   045E FF                 1193 	mov	r7,a
   045F ED                 1194 	mov	a,r5
   0460 33                 1195 	rlc	a
   0461 FD                 1196 	mov	r5,a
   0462                    1197 00144$:
   0462 D5 F0 F7           1198 	djnz	b,00143$
   0465 AB 38              1199 	mov	r3,_rm_state
   0467 7C 00              1200 	mov	r4,#0x00
   0469 EB                 1201 	mov	a,r3
   046A 52 07              1202 	anl	ar7,a
   046C EC                 1203 	mov	a,r4
   046D 52 05              1204 	anl	ar5,a
   046F EF                 1205 	mov	a,r7
   0470 4D                 1206 	orl	a,r5
   0471 60 02              1207 	jz	00113$
   0473 7E 01              1208 	mov	r6,#0x01
   0475                    1209 00113$:
                           1210 ;	../fb_app_out.c:219: return(ret_val);
   0475 7F 00              1211 	mov	r7,#0x00
   0477 7D 00              1212 	mov	r5,#0x00
   0479 7C 00              1213 	mov	r4,#0x00
   047B 8E 82              1214 	mov	dpl,r6
   047D 8F 83              1215 	mov	dph,r7
   047F 8D F0              1216 	mov	b,r5
   0481 EC                 1217 	mov	a,r4
   0482 22                 1218 	ret
                           1219 ;------------------------------------------------------------
                           1220 ;Allocation info for local variables in function 'write_obj_value'
                           1221 ;------------------------------------------------------------
                           1222 ;objvalue                  Allocated to stack - _bp -4
                           1223 ;objno                     Allocated to registers r7 
                           1224 ;------------------------------------------------------------
                           1225 ;	../fb_app_out.c:223: void write_obj_value(unsigned char objno,unsigned int objvalue)	// schreibt den aktuellen Wert eines Objektes ins 'USERRAM'
                           1226 ;	-----------------------------------------
                           1227 ;	 function write_obj_value
                           1228 ;	-----------------------------------------
   0483                    1229 _write_obj_value:
   0483 C0 08              1230 	push	_bp
   0485 85 81 08           1231 	mov	_bp,sp
   0488 AF 82              1232 	mov	r7,dpl
                           1233 ;	../fb_app_out.c:225: if(objno<8) {
   048A BF 08 00           1234 	cjne	r7,#0x08,00133$
   048D                    1235 00133$:
   048D E4                 1236 	clr	a
   048E 33                 1237 	rlc	a
   048F FE                 1238 	mov	r6,a
   0490 60 30              1239 	jz	00105$
                           1240 ;	../fb_app_out.c:226: if(objvalue==0) out_state&=0xFF-(1<<objno);
   0492 E5 08              1241 	mov	a,_bp
   0494 24 FC              1242 	add	a,#0xfc
   0496 F8                 1243 	mov	r0,a
   0497 E6                 1244 	mov	a,@r0
   0498 08                 1245 	inc	r0
   0499 46                 1246 	orl	a,@r0
   049A 70 16              1247 	jnz	00102$
   049C 8F F0              1248 	mov	b,r7
   049E 05 F0              1249 	inc	b
   04A0 74 01              1250 	mov	a,#0x01
   04A2 80 02              1251 	sjmp	00138$
   04A4                    1252 00136$:
   04A4 25 E0              1253 	add	a,acc
   04A6                    1254 00138$:
   04A6 D5 F0 FB           1255 	djnz	b,00136$
   04A9 FD                 1256 	mov	r5,a
   04AA 74 FF              1257 	mov	a,#0xFF
   04AC C3                 1258 	clr	c
   04AD 9D                 1259 	subb	a,r5
   04AE 52 37              1260 	anl	_out_state,a
   04B0 80 10              1261 	sjmp	00105$
   04B2                    1262 00102$:
                           1263 ;	../fb_app_out.c:227: else out_state|=1<<objno;
   04B2 8F F0              1264 	mov	b,r7
   04B4 05 F0              1265 	inc	b
   04B6 74 01              1266 	mov	a,#0x01
   04B8 80 02              1267 	sjmp	00141$
   04BA                    1268 00139$:
   04BA 25 E0              1269 	add	a,acc
   04BC                    1270 00141$:
   04BC D5 F0 FB           1271 	djnz	b,00139$
   04BF FD                 1272 	mov	r5,a
   04C0 42 37              1273 	orl	_out_state,a
   04C2                    1274 00105$:
                           1275 ;	../fb_app_out.c:229: if(objno>=8 && objno<12) {
   04C2 EE                 1276 	mov	a,r6
   04C3 70 3B              1277 	jnz	00110$
   04C5 BF 0C 00           1278 	cjne	r7,#0x0C,00143$
   04C8                    1279 00143$:
   04C8 50 36              1280 	jnc	00110$
                           1281 ;	../fb_app_out.c:230: if(objvalue==0) zf_state&=0x0F-(1<<(objno-8));
   04CA E5 08              1282 	mov	a,_bp
   04CC 24 FC              1283 	add	a,#0xfc
   04CE F8                 1284 	mov	r0,a
   04CF E6                 1285 	mov	a,@r0
   04D0 08                 1286 	inc	r0
   04D1 46                 1287 	orl	a,@r0
   04D2 70 19              1288 	jnz	00107$
   04D4 EF                 1289 	mov	a,r7
   04D5 24 F8              1290 	add	a,#0xF8
   04D7 F5 F0              1291 	mov	b,a
   04D9 05 F0              1292 	inc	b
   04DB 74 01              1293 	mov	a,#0x01
   04DD 80 02              1294 	sjmp	00148$
   04DF                    1295 00146$:
   04DF 25 E0              1296 	add	a,acc
   04E1                    1297 00148$:
   04E1 D5 F0 FB           1298 	djnz	b,00146$
   04E4 FE                 1299 	mov	r6,a
   04E5 74 0F              1300 	mov	a,#0x0F
   04E7 C3                 1301 	clr	c
   04E8 9E                 1302 	subb	a,r6
   04E9 52 39              1303 	anl	_zf_state,a
   04EB 80 13              1304 	sjmp	00110$
   04ED                    1305 00107$:
                           1306 ;	../fb_app_out.c:231: else zf_state|=1<<(objno-8);
   04ED EF                 1307 	mov	a,r7
   04EE 24 F8              1308 	add	a,#0xF8
   04F0 F5 F0              1309 	mov	b,a
   04F2 05 F0              1310 	inc	b
   04F4 74 01              1311 	mov	a,#0x01
   04F6 80 02              1312 	sjmp	00151$
   04F8                    1313 00149$:
   04F8 25 E0              1314 	add	a,acc
   04FA                    1315 00151$:
   04FA D5 F0 FB           1316 	djnz	b,00149$
   04FD FE                 1317 	mov	r6,a
   04FE 42 39              1318 	orl	_zf_state,a
   0500                    1319 00110$:
                           1320 ;	../fb_app_out.c:233: if(objno>=12) {
   0500 BF 0C 00           1321 	cjne	r7,#0x0C,00152$
   0503                    1322 00152$:
   0503 40 36              1323 	jc	00117$
                           1324 ;	../fb_app_out.c:234: if(objvalue==0) rm_state&=0xFF-(1<<(objno-12));
   0505 E5 08              1325 	mov	a,_bp
   0507 24 FC              1326 	add	a,#0xfc
   0509 F8                 1327 	mov	r0,a
   050A E6                 1328 	mov	a,@r0
   050B 08                 1329 	inc	r0
   050C 46                 1330 	orl	a,@r0
   050D 70 19              1331 	jnz	00113$
   050F EF                 1332 	mov	a,r7
   0510 24 F4              1333 	add	a,#0xF4
   0512 F5 F0              1334 	mov	b,a
   0514 05 F0              1335 	inc	b
   0516 74 01              1336 	mov	a,#0x01
   0518 80 02              1337 	sjmp	00157$
   051A                    1338 00155$:
   051A 25 E0              1339 	add	a,acc
   051C                    1340 00157$:
   051C D5 F0 FB           1341 	djnz	b,00155$
   051F FE                 1342 	mov	r6,a
   0520 74 FF              1343 	mov	a,#0xFF
   0522 C3                 1344 	clr	c
   0523 9E                 1345 	subb	a,r6
   0524 52 38              1346 	anl	_rm_state,a
   0526 80 13              1347 	sjmp	00117$
   0528                    1348 00113$:
                           1349 ;	../fb_app_out.c:235: else rm_state|=1<<(objno-12);
   0528 EF                 1350 	mov	a,r7
   0529 24 F4              1351 	add	a,#0xF4
   052B F5 F0              1352 	mov	b,a
   052D 05 F0              1353 	inc	b
   052F 74 01              1354 	mov	a,#0x01
   0531 80 02              1355 	sjmp	00160$
   0533                    1356 00158$:
   0533 25 E0              1357 	add	a,acc
   0535                    1358 00160$:
   0535 D5 F0 FB           1359 	djnz	b,00158$
   0538 FF                 1360 	mov	r7,a
   0539 42 38              1361 	orl	_rm_state,a
   053B                    1362 00117$:
   053B D0 08              1363 	pop	_bp
   053D 22                 1364 	ret
                           1365 ;------------------------------------------------------------
                           1366 ;Allocation info for local variables in function 'object_schalten'
                           1367 ;------------------------------------------------------------
                           1368 ;objstate                  Allocated to registers b0 
                           1369 ;objno                     Allocated to registers r7 
                           1370 ;delay_base                Allocated to registers r6 
                           1371 ;delay_state               Allocated to registers r4 
                           1372 ;logicfunc                 Allocated to stack - _bp +1
                           1373 ;zfno                      Allocated to stack - _bp +2
                           1374 ;delay_onoff               Allocated to registers r5 
                           1375 ;off_disable               Allocated to registers b1 
                           1376 ;------------------------------------------------------------
                           1377 ;	../fb_app_out.c:244: void object_schalten(unsigned char objno, __bit objstate)	// Schaltet einen Ausgang gem�� objstate und den zug�rigen Parametern
                           1378 ;	-----------------------------------------
                           1379 ;	 function object_schalten
                           1380 ;	-----------------------------------------
   053E                    1381 _object_schalten:
   053E C0 08              1382 	push	_bp
   0540 85 81 08           1383 	mov	_bp,sp
   0543 05 81              1384 	inc	sp
   0545 05 81              1385 	inc	sp
   0547 AF 82              1386 	mov	r7,dpl
                           1387 ;	../fb_app_out.c:253: off_disable=((eeprom[OFFDISABLE]>>objno)&0x01);	// nur ausschalten wenn AUS-Tete nicht ignoriert werden soll
   0549 90 1D EB           1388 	mov	dptr,#(_eeprom + 0x00eb)
   054C E4                 1389 	clr	a
   054D 93                 1390 	movc	a,@a+dptr
   054E FE                 1391 	mov	r6,a
   054F 8F F0              1392 	mov	b,r7
   0551 05 F0              1393 	inc	b
   0553 EE                 1394 	mov	a,r6
   0554 80 02              1395 	sjmp	00216$
   0556                    1396 00215$:
   0556 C3                 1397 	clr	c
   0557 13                 1398 	rrc	a
   0558                    1399 00216$:
   0558 D5 F0 FB           1400 	djnz	b,00215$
   055B 54 01              1401 	anl	a,#0x01
   055D FE                 1402 	mov	r6,a
   055E 24 FF              1403 	add	a,#0xff
   0560 92 19              1404 	mov	b1,c
                           1405 ;	../fb_app_out.c:254: if ((!objstate && !off_disable) || objstate) {
   0562 20 18 03           1406 	jb	b0,00158$
   0565 30 19 06           1407 	jnb	b1,00155$
   0568                    1408 00158$:
   0568 20 18 03           1409 	jb	b0,00219$
   056B 02 08 AF           1410 	ljmp	00159$
   056E                    1411 00219$:
   056E                    1412 00155$:
                           1413 ;	../fb_app_out.c:255: write_obj_value(objno,objstate);		// Objektwert speichern
   056E A2 18              1414 	mov	c,b0
   0570 E4                 1415 	clr	a
   0571 33                 1416 	rlc	a
   0572 FD                 1417 	mov	r5,a
   0573 7E 00              1418 	mov	r6,#0x00
   0575 C0 07              1419 	push	ar7
   0577 C0 23              1420 	push	bits
   0579 C0 05              1421 	push	ar5
   057B C0 06              1422 	push	ar6
   057D 8F 82              1423 	mov	dpl,r7
   057F 12 04 83           1424 	lcall	_write_obj_value
   0582 15 81              1425 	dec	sp
   0584 15 81              1426 	dec	sp
   0586 D0 23              1427 	pop	bits
   0588 D0 07              1428 	pop	ar7
                           1429 ;	../fb_app_out.c:258: zfno=0;
   058A A8 08              1430 	mov	r0,_bp
   058C 08                 1431 	inc	r0
   058D 08                 1432 	inc	r0
   058E 76 00              1433 	mov	@r0,#0x00
                           1434 ;	../fb_app_out.c:259: logicfunc=0;
   0590 A8 08              1435 	mov	r0,_bp
   0592 08                 1436 	inc	r0
   0593 76 00              1437 	mov	@r0,#0x00
                           1438 ;	../fb_app_out.c:260: if((eeprom[FUNCASS]&0x0F)==(objno+1)) zfno=1;
   0595 90 1D D8           1439 	mov	dptr,#(_eeprom + 0x00d8)
   0598 E4                 1440 	clr	a
   0599 93                 1441 	movc	a,@a+dptr
   059A FC                 1442 	mov	r4,a
   059B 53 04 0F           1443 	anl	ar4,#0x0F
   059E 8F 02              1444 	mov	ar2,r7
   05A0 7B 00              1445 	mov	r3,#0x00
   05A2 C0 07              1446 	push	ar7
   05A4 74 01              1447 	mov	a,#0x01
   05A6 2A                 1448 	add	a,r2
   05A7 FE                 1449 	mov	r6,a
   05A8 E4                 1450 	clr	a
   05A9 3B                 1451 	addc	a,r3
   05AA FF                 1452 	mov	r7,a
   05AB 7D 00              1453 	mov	r5,#0x00
   05AD EC                 1454 	mov	a,r4
   05AE B5 06 06           1455 	cjne	a,ar6,00220$
   05B1 ED                 1456 	mov	a,r5
   05B2 B5 07 02           1457 	cjne	a,ar7,00220$
   05B5 80 04              1458 	sjmp	00221$
   05B7                    1459 00220$:
   05B7 D0 07              1460 	pop	ar7
   05B9 80 08              1461 	sjmp	00102$
   05BB                    1462 00221$:
   05BB D0 07              1463 	pop	ar7
   05BD A8 08              1464 	mov	r0,_bp
   05BF 08                 1465 	inc	r0
   05C0 08                 1466 	inc	r0
   05C1 76 01              1467 	mov	@r0,#0x01
   05C3                    1468 00102$:
                           1469 ;	../fb_app_out.c:261: if(((eeprom[FUNCASS]&0xF0)>>4)==(objno+1)) zfno=2;
   05C3 C0 07              1470 	push	ar7
   05C5 90 1D D8           1471 	mov	dptr,#(_eeprom + 0x00d8)
   05C8 E4                 1472 	clr	a
   05C9 93                 1473 	movc	a,@a+dptr
   05CA 54 F0              1474 	anl	a,#0xF0
   05CC C4                 1475 	swap	a
   05CD 54 0F              1476 	anl	a,#0x0F
   05CF FE                 1477 	mov	r6,a
   05D0 74 01              1478 	mov	a,#0x01
   05D2 2A                 1479 	add	a,r2
   05D3 FC                 1480 	mov	r4,a
   05D4 E4                 1481 	clr	a
   05D5 3B                 1482 	addc	a,r3
   05D6 FD                 1483 	mov	r5,a
   05D7 7F 00              1484 	mov	r7,#0x00
   05D9 EE                 1485 	mov	a,r6
   05DA B5 04 06           1486 	cjne	a,ar4,00222$
   05DD EF                 1487 	mov	a,r7
   05DE B5 05 02           1488 	cjne	a,ar5,00222$
   05E1 80 04              1489 	sjmp	00223$
   05E3                    1490 00222$:
   05E3 D0 07              1491 	pop	ar7
   05E5 80 08              1492 	sjmp	00104$
   05E7                    1493 00223$:
   05E7 D0 07              1494 	pop	ar7
   05E9 A8 08              1495 	mov	r0,_bp
   05EB 08                 1496 	inc	r0
   05EC 08                 1497 	inc	r0
   05ED 76 02              1498 	mov	@r0,#0x02
   05EF                    1499 00104$:
                           1500 ;	../fb_app_out.c:262: if((eeprom[FUNCASS+1]&0x0F)==(objno+1)) zfno=3;
   05EF C0 07              1501 	push	ar7
   05F1 90 1D D9           1502 	mov	dptr,#(_eeprom + 0x00d9)
   05F4 E4                 1503 	clr	a
   05F5 93                 1504 	movc	a,@a+dptr
   05F6 FE                 1505 	mov	r6,a
   05F7 53 06 0F           1506 	anl	ar6,#0x0F
   05FA 74 01              1507 	mov	a,#0x01
   05FC 2A                 1508 	add	a,r2
   05FD FC                 1509 	mov	r4,a
   05FE E4                 1510 	clr	a
   05FF 3B                 1511 	addc	a,r3
   0600 FD                 1512 	mov	r5,a
   0601 7F 00              1513 	mov	r7,#0x00
   0603 EE                 1514 	mov	a,r6
   0604 B5 04 06           1515 	cjne	a,ar4,00224$
   0607 EF                 1516 	mov	a,r7
   0608 B5 05 02           1517 	cjne	a,ar5,00224$
   060B 80 04              1518 	sjmp	00225$
   060D                    1519 00224$:
   060D D0 07              1520 	pop	ar7
   060F 80 08              1521 	sjmp	00106$
   0611                    1522 00225$:
   0611 D0 07              1523 	pop	ar7
   0613 A8 08              1524 	mov	r0,_bp
   0615 08                 1525 	inc	r0
   0616 08                 1526 	inc	r0
   0617 76 03              1527 	mov	@r0,#0x03
   0619                    1528 00106$:
                           1529 ;	../fb_app_out.c:263: if(((eeprom[FUNCASS+1]&0xF0)>>4)==(objno+1)) zfno=4;
   0619 C0 07              1530 	push	ar7
   061B 90 1D D9           1531 	mov	dptr,#(_eeprom + 0x00d9)
   061E E4                 1532 	clr	a
   061F 93                 1533 	movc	a,@a+dptr
   0620 54 F0              1534 	anl	a,#0xF0
   0622 C4                 1535 	swap	a
   0623 54 0F              1536 	anl	a,#0x0F
   0625 FE                 1537 	mov	r6,a
   0626 74 01              1538 	mov	a,#0x01
   0628 2A                 1539 	add	a,r2
   0629 FC                 1540 	mov	r4,a
   062A E4                 1541 	clr	a
   062B 3B                 1542 	addc	a,r3
   062C FD                 1543 	mov	r5,a
   062D 7F 00              1544 	mov	r7,#0x00
   062F EE                 1545 	mov	a,r6
   0630 B5 04 06           1546 	cjne	a,ar4,00226$
   0633 EF                 1547 	mov	a,r7
   0634 B5 05 02           1548 	cjne	a,ar5,00226$
   0637 80 04              1549 	sjmp	00227$
   0639                    1550 00226$:
   0639 D0 07              1551 	pop	ar7
   063B 80 08              1552 	sjmp	00108$
   063D                    1553 00227$:
   063D D0 07              1554 	pop	ar7
   063F A8 08              1555 	mov	r0,_bp
   0641 08                 1556 	inc	r0
   0642 08                 1557 	inc	r0
   0643 76 04              1558 	mov	@r0,#0x04
   0645                    1559 00108$:
                           1560 ;	../fb_app_out.c:264: if(zfno) {
   0645 A8 08              1561 	mov	r0,_bp
   0647 08                 1562 	inc	r0
   0648 08                 1563 	inc	r0
   0649 E6                 1564 	mov	a,@r0
   064A 60 5F              1565 	jz	00112$
                           1566 ;	../fb_app_out.c:265: if(((eeprom[FUNCTYP]>>((zfno-1)*2))&0x03)==0x00) logicfunc=((eeprom[LOGICTYP]>>((zfno-1)*2))&0x03);
   064C C0 02              1567 	push	ar2
   064E C0 03              1568 	push	ar3
   0650 90 1D ED           1569 	mov	dptr,#(_eeprom + 0x00ed)
   0653 E4                 1570 	clr	a
   0654 93                 1571 	movc	a,@a+dptr
   0655 FE                 1572 	mov	r6,a
   0656 A8 08              1573 	mov	r0,_bp
   0658 08                 1574 	inc	r0
   0659 08                 1575 	inc	r0
   065A 86 04              1576 	mov	ar4,@r0
   065C 7D 00              1577 	mov	r5,#0x00
   065E EC                 1578 	mov	a,r4
   065F 24 FF              1579 	add	a,#0xFF
   0661 FA                 1580 	mov	r2,a
   0662 ED                 1581 	mov	a,r5
   0663 34 FF              1582 	addc	a,#0xFF
   0665 CA                 1583 	xch	a,r2
   0666 25 E0              1584 	add	a,acc
   0668 CA                 1585 	xch	a,r2
   0669 33                 1586 	rlc	a
   066A FB                 1587 	mov	r3,a
   066B 8A F0              1588 	mov	b,r2
   066D 05 F0              1589 	inc	b
   066F EE                 1590 	mov	a,r6
   0670 80 02              1591 	sjmp	00230$
   0672                    1592 00229$:
   0672 C3                 1593 	clr	c
   0673 13                 1594 	rrc	a
   0674                    1595 00230$:
   0674 D5 F0 FB           1596 	djnz	b,00229$
   0677 54 03              1597 	anl	a,#0x03
   0679 60 06              1598 	jz	00232$
   067B D0 03              1599 	pop	ar3
   067D D0 02              1600 	pop	ar2
   067F 80 2A              1601 	sjmp	00112$
   0681                    1602 00232$:
   0681 D0 03              1603 	pop	ar3
   0683 D0 02              1604 	pop	ar2
   0685 90 1D EE           1605 	mov	dptr,#(_eeprom + 0x00ee)
   0688 E4                 1606 	clr	a
   0689 93                 1607 	movc	a,@a+dptr
   068A FE                 1608 	mov	r6,a
   068B 1C                 1609 	dec	r4
   068C BC FF 01           1610 	cjne	r4,#0xFF,00233$
   068F 1D                 1611 	dec	r5
   0690                    1612 00233$:
   0690 ED                 1613 	mov	a,r5
   0691 CC                 1614 	xch	a,r4
   0692 25 E0              1615 	add	a,acc
   0694 CC                 1616 	xch	a,r4
   0695 33                 1617 	rlc	a
   0696 FD                 1618 	mov	r5,a
   0697 8C F0              1619 	mov	b,r4
   0699 05 F0              1620 	inc	b
   069B EE                 1621 	mov	a,r6
   069C 80 02              1622 	sjmp	00235$
   069E                    1623 00234$:
   069E C3                 1624 	clr	c
   069F 13                 1625 	rrc	a
   06A0                    1626 00235$:
   06A0 D5 F0 FB           1627 	djnz	b,00234$
   06A3 FE                 1628 	mov	r6,a
   06A4 A8 08              1629 	mov	r0,_bp
   06A6 08                 1630 	inc	r0
   06A7 74 03              1631 	mov	a,#0x03
   06A9 5E                 1632 	anl	a,r6
   06AA F6                 1633 	mov	@r0,a
   06AB                    1634 00112$:
                           1635 ;	../fb_app_out.c:268: if(((0x01<<objno) & blocked)==0 && (read_objflags(objno)&0x14)==0x14) {	// Objekt ist nicht gesperrt und Kommunikation zul�ssig (Bit 2 = communication enable) und Schreiben zul�ssig (Bit 4 = write enable)
   06AB C0 02              1636 	push	ar2
   06AD C0 03              1637 	push	ar3
   06AF 8F F0              1638 	mov	b,r7
   06B1 05 F0              1639 	inc	b
   06B3 7D 01              1640 	mov	r5,#0x01
   06B5 7E 00              1641 	mov	r6,#0x00
   06B7 80 06              1642 	sjmp	00237$
   06B9                    1643 00236$:
   06B9 ED                 1644 	mov	a,r5
   06BA 2D                 1645 	add	a,r5
   06BB FD                 1646 	mov	r5,a
   06BC EE                 1647 	mov	a,r6
   06BD 33                 1648 	rlc	a
   06BE FE                 1649 	mov	r6,a
   06BF                    1650 00237$:
   06BF D5 F0 F7           1651 	djnz	b,00236$
   06C2 AB 3C              1652 	mov	r3,_blocked
   06C4 7C 00              1653 	mov	r4,#0x00
   06C6 EB                 1654 	mov	a,r3
   06C7 52 05              1655 	anl	ar5,a
   06C9 EC                 1656 	mov	a,r4
   06CA 52 06              1657 	anl	ar6,a
   06CC D0 03              1658 	pop	ar3
   06CE D0 02              1659 	pop	ar2
   06D0 ED                 1660 	mov	a,r5
   06D1 4E                 1661 	orl	a,r6
   06D2 60 03              1662 	jz	00238$
   06D4 02 08 AF           1663 	ljmp	00159$
   06D7                    1664 00238$:
   06D7 8F 82              1665 	mov	dpl,r7
   06D9 C0 07              1666 	push	ar7
   06DB C0 03              1667 	push	ar3
   06DD C0 02              1668 	push	ar2
   06DF C0 23              1669 	push	bits
   06E1 12 17 F8           1670 	lcall	_read_objflags
   06E4 E5 82              1671 	mov	a,dpl
   06E6 D0 23              1672 	pop	bits
   06E8 D0 02              1673 	pop	ar2
   06EA D0 03              1674 	pop	ar3
   06EC D0 07              1675 	pop	ar7
   06EE 54 14              1676 	anl	a,#0x14
   06F0 FE                 1677 	mov	r6,a
   06F1 BE 14 02           1678 	cjne	r6,#0x14,00239$
   06F4 80 03              1679 	sjmp	00240$
   06F6                    1680 00239$:
   06F6 02 08 AF           1681 	ljmp	00159$
   06F9                    1682 00240$:
                           1683 ;	../fb_app_out.c:269: delay_base=eeprom[(((objno+1)>>1)+DELAYTAB)];   
   06F9 0A                 1684 	inc	r2
   06FA BA 00 01           1685 	cjne	r2,#0x00,00241$
   06FD 0B                 1686 	inc	r3
   06FE                    1687 00241$:
   06FE EB                 1688 	mov	a,r3
   06FF A2 E7              1689 	mov	c,acc.7
   0701 13                 1690 	rrc	a
   0702 CA                 1691 	xch	a,r2
   0703 13                 1692 	rrc	a
   0704 CA                 1693 	xch	a,r2
   0705 FB                 1694 	mov	r3,a
   0706 74 F9              1695 	mov	a,#0xF9
   0708 2A                 1696 	add	a,r2
   0709 90 1D 00           1697 	mov	dptr,#_eeprom
   070C 93                 1698 	movc	a,@a+dptr
   070D FE                 1699 	mov	r6,a
                           1700 ;	../fb_app_out.c:270: if((objno&0x01)==0x01) delay_base&=0x0F;
   070E 74 01              1701 	mov	a,#0x01
   0710 5F                 1702 	anl	a,r7
   0711 FD                 1703 	mov	r5,a
   0712 BD 01 05           1704 	cjne	r5,#0x01,00114$
   0715 53 06 0F           1705 	anl	ar6,#0x0F
   0718 80 08              1706 	sjmp	00115$
   071A                    1707 00114$:
                           1708 ;	../fb_app_out.c:271: else delay_base=(delay_base&0xF0)>>4;
   071A 74 F0              1709 	mov	a,#0xF0
   071C 5E                 1710 	anl	a,r6
   071D FD                 1711 	mov	r5,a
   071E C4                 1712 	swap	a
   071F 54 0F              1713 	anl	a,#0x0F
   0721 FE                 1714 	mov	r6,a
   0722                    1715 00115$:
                           1716 ;	../fb_app_out.c:273: delay_onoff=0;
   0722 7D 00              1717 	mov	r5,#0x00
                           1718 ;	../fb_app_out.c:274: delay_state=0;
   0724 7C 00              1719 	mov	r4,#0x00
                           1720 ;	../fb_app_out.c:278: if ( (objstate==0 && (logicfunc==0 || (logicfunc==1 && ((logicstate>>objno)&0x01)==0x00) || logicfunc>=2))
   0726 20 18 24           1721 	jb	b0,00131$
   0729 A8 08              1722 	mov	r0,_bp
   072B 08                 1723 	inc	r0
   072C E6                 1724 	mov	a,@r0
   072D 60 43              1725 	jz	00123$
   072F A8 08              1726 	mov	r0,_bp
   0731 08                 1727 	inc	r0
   0732 B6 01 10           1728 	cjne	@r0,#0x01,00127$
   0735 8F F0              1729 	mov	b,r7
   0737 05 F0              1730 	inc	b
   0739 E5 3D              1731 	mov	a,_logicstate
   073B 80 02              1732 	sjmp	00249$
   073D                    1733 00248$:
   073D C3                 1734 	clr	c
   073E 13                 1735 	rrc	a
   073F                    1736 00249$:
   073F D5 F0 FB           1737 	djnz	b,00248$
   0742 30 E0 2D           1738 	jnb	acc.0,00123$
   0745                    1739 00127$:
   0745 A8 08              1740 	mov	r0,_bp
   0747 08                 1741 	inc	r0
   0748 B6 02 00           1742 	cjne	@r0,#0x02,00251$
   074B                    1743 00251$:
   074B 50 25              1744 	jnc	00123$
   074D                    1745 00131$:
                           1746 ;	../fb_app_out.c:279: || (objstate==1 && (logicfunc>=2 && ((logicstate>>objno)&0x01)==0x00)) )
   074D A2 18              1747 	mov	c,b0
   074F E4                 1748 	clr	a
   0750 33                 1749 	rlc	a
   0751 FB                 1750 	mov	r3,a
   0752 BB 01 02           1751 	cjne	r3,#0x01,00253$
   0755 80 03              1752 	sjmp	00254$
   0757                    1753 00253$:
   0757 02 07 D1           1754 	ljmp	00124$
   075A                    1755 00254$:
   075A A8 08              1756 	mov	r0,_bp
   075C 08                 1757 	inc	r0
   075D B6 02 00           1758 	cjne	@r0,#0x02,00255$
   0760                    1759 00255$:
   0760 40 6F              1760 	jc	00124$
   0762 8F F0              1761 	mov	b,r7
   0764 05 F0              1762 	inc	b
   0766 E5 3D              1763 	mov	a,_logicstate
   0768 80 02              1764 	sjmp	00258$
   076A                    1765 00257$:
   076A C3                 1766 	clr	c
   076B 13                 1767 	rrc	a
   076C                    1768 00258$:
   076C D5 F0 FB           1769 	djnz	b,00257$
   076F 20 E0 5F           1770 	jb	acc.0,00124$
   0772                    1771 00123$:
                           1772 ;	../fb_app_out.c:281: delay_onoff=eeprom[objno+0xE2];
   0772 74 E2              1773 	mov	a,#0xE2
   0774 2F                 1774 	add	a,r7
   0775 90 1D 00           1775 	mov	dptr,#_eeprom
   0778 93                 1776 	movc	a,@a+dptr
   0779 FB                 1777 	mov	r3,a
                           1778 ;	../fb_app_out.c:282: if(delay_onoff==0x00 || ((eeprom[0xEA]>>objno)&0x01)==0x01) {		// sofort ausschalten
   077A FD                 1779 	mov	r5,a
   077B 60 18              1780 	jz	00119$
   077D 90 1D EA           1781 	mov	dptr,#(_eeprom + 0x00ea)
   0780 E4                 1782 	clr	a
   0781 93                 1783 	movc	a,@a+dptr
   0782 FB                 1784 	mov	r3,a
   0783 8F F0              1785 	mov	b,r7
   0785 05 F0              1786 	inc	b
   0787 EB                 1787 	mov	a,r3
   0788 80 02              1788 	sjmp	00262$
   078A                    1789 00261$:
   078A C3                 1790 	clr	c
   078B 13                 1791 	rrc	a
   078C                    1792 00262$:
   078C D5 F0 FB           1793 	djnz	b,00261$
   078F 54 01              1794 	anl	a,#0x01
   0791 FB                 1795 	mov	r3,a
   0792 BB 01 3A           1796 	cjne	r3,#0x01,00120$
   0795                    1797 00119$:
                           1798 ;	../fb_app_out.c:283: if (((eeprom[RELMODE]>>objno)&0x01)==0x00) portbuffer=portbuffer&~(0x01<<objno);	// Schliesserbetrieb
   0795 90 1D F2           1799 	mov	dptr,#(_eeprom + 0x00f2)
   0798 E4                 1800 	clr	a
   0799 93                 1801 	movc	a,@a+dptr
   079A FB                 1802 	mov	r3,a
   079B 8F F0              1803 	mov	b,r7
   079D 05 F0              1804 	inc	b
   079F EB                 1805 	mov	a,r3
   07A0 80 02              1806 	sjmp	00266$
   07A2                    1807 00265$:
   07A2 C3                 1808 	clr	c
   07A3 13                 1809 	rrc	a
   07A4                    1810 00266$:
   07A4 D5 F0 FB           1811 	djnz	b,00265$
   07A7 20 E0 13           1812 	jb	acc.0,00117$
   07AA 8F F0              1813 	mov	b,r7
   07AC 05 F0              1814 	inc	b
   07AE 74 01              1815 	mov	a,#0x01
   07B0 80 02              1816 	sjmp	00270$
   07B2                    1817 00268$:
   07B2 25 E0              1818 	add	a,acc
   07B4                    1819 00270$:
   07B4 D5 F0 FB           1820 	djnz	b,00268$
   07B7 F4                 1821 	cpl	a
   07B8 FB                 1822 	mov	r3,a
   07B9 52 3A              1823 	anl	_portbuffer,a
   07BB 80 14              1824 	sjmp	00124$
   07BD                    1825 00117$:
                           1826 ;	../fb_app_out.c:284: else portbuffer=portbuffer|(0x01<<objno);						// �ffnerbetrieb
   07BD 8F F0              1827 	mov	b,r7
   07BF 05 F0              1828 	inc	b
   07C1 74 01              1829 	mov	a,#0x01
   07C3 80 02              1830 	sjmp	00273$
   07C5                    1831 00271$:
   07C5 25 E0              1832 	add	a,acc
   07C7                    1833 00273$:
   07C7 D5 F0 FB           1834 	djnz	b,00271$
   07CA FB                 1835 	mov	r3,a
   07CB 42 3A              1836 	orl	_portbuffer,a
   07CD 80 02              1837 	sjmp	00124$
   07CF                    1838 00120$:
                           1839 ;	../fb_app_out.c:286: else delay_state=0x01;				// verz�gert ausschalten
   07CF 7C 01              1840 	mov	r4,#0x01
   07D1                    1841 00124$:
                           1842 ;	../fb_app_out.c:290: if ( (objstate==1 && (logicfunc==0 || logicfunc==1 || (logicfunc>=2 && ((logicstate>>objno)&0x01)==0x01))) 
   07D1 A2 18              1843 	mov	c,b0
   07D3 E4                 1844 	clr	a
   07D4 33                 1845 	rlc	a
   07D5 FB                 1846 	mov	r3,a
   07D6 BB 01 2B           1847 	cjne	r3,#0x01,00148$
   07D9 A8 08              1848 	mov	r0,_bp
   07DB 08                 1849 	inc	r0
   07DC E6                 1850 	mov	a,@r0
   07DD 60 49              1851 	jz	00140$
   07DF A8 08              1852 	mov	r0,_bp
   07E1 08                 1853 	inc	r0
   07E2 B6 01 02           1854 	cjne	@r0,#0x01,00277$
   07E5 80 41              1855 	sjmp	00140$
   07E7                    1856 00277$:
   07E7 A8 08              1857 	mov	r0,_bp
   07E9 08                 1858 	inc	r0
   07EA B6 02 00           1859 	cjne	@r0,#0x02,00278$
   07ED                    1860 00278$:
   07ED 40 15              1861 	jc	00148$
   07EF 8F F0              1862 	mov	b,r7
   07F1 05 F0              1863 	inc	b
   07F3 E5 3D              1864 	mov	a,_logicstate
   07F5 80 02              1865 	sjmp	00281$
   07F7                    1866 00280$:
   07F7 C3                 1867 	clr	c
   07F8 13                 1868 	rrc	a
   07F9                    1869 00281$:
   07F9 D5 F0 FB           1870 	djnz	b,00280$
   07FC 54 01              1871 	anl	a,#0x01
   07FE FB                 1872 	mov	r3,a
   07FF BB 01 02           1873 	cjne	r3,#0x01,00282$
   0802 80 24              1874 	sjmp	00140$
   0804                    1875 00282$:
   0804                    1876 00148$:
                           1877 ;	../fb_app_out.c:291: || (objstate==0 && (logicfunc==1 && ((logicstate>>objno)&0x01)==0x01)) )
   0804 30 18 03           1878 	jnb	b0,00283$
   0807 02 08 92           1879 	ljmp	00141$
   080A                    1880 00283$:
   080A A8 08              1881 	mov	r0,_bp
   080C 08                 1882 	inc	r0
   080D B6 01 02           1883 	cjne	@r0,#0x01,00284$
   0810 80 03              1884 	sjmp	00285$
   0812                    1885 00284$:
   0812 02 08 92           1886 	ljmp	00141$
   0815                    1887 00285$:
   0815 8F F0              1888 	mov	b,r7
   0817 05 F0              1889 	inc	b
   0819 E5 3D              1890 	mov	a,_logicstate
   081B 80 02              1891 	sjmp	00287$
   081D                    1892 00286$:
   081D C3                 1893 	clr	c
   081E 13                 1894 	rrc	a
   081F                    1895 00287$:
   081F D5 F0 FB           1896 	djnz	b,00286$
   0822 54 01              1897 	anl	a,#0x01
   0824 FB                 1898 	mov	r3,a
   0825 BB 01 6A           1899 	cjne	r3,#0x01,00141$
   0828                    1900 00140$:
                           1901 ;	../fb_app_out.c:293: delay_onoff=eeprom[objno+0xDA];
   0828 74 DA              1902 	mov	a,#0xDA
   082A 2F                 1903 	add	a,r7
   082B 90 1D 00           1904 	mov	dptr,#_eeprom
   082E 93                 1905 	movc	a,@a+dptr
   082F FB                 1906 	mov	r3,a
                           1907 ;	../fb_app_out.c:294: if(delay_onoff==0x00) {
   0830 FD                 1908 	mov	r5,a
   0831 70 5D              1909 	jnz	00138$
                           1910 ;	../fb_app_out.c:297: if(((eeprom[0xEA]>>objno)&0x01)==0x01) { 			// Zeitschaltfunktion
   0833 90 1D EA           1911 	mov	dptr,#(_eeprom + 0x00ea)
   0836 E4                 1912 	clr	a
   0837 93                 1913 	movc	a,@a+dptr
   0838 FB                 1914 	mov	r3,a
   0839 8F F0              1915 	mov	b,r7
   083B 05 F0              1916 	inc	b
   083D EB                 1917 	mov	a,r3
   083E 80 02              1918 	sjmp	00292$
   0840                    1919 00291$:
   0840 C3                 1920 	clr	c
   0841 13                 1921 	rrc	a
   0842                    1922 00292$:
   0842 D5 F0 FB           1923 	djnz	b,00291$
   0845 54 01              1924 	anl	a,#0x01
   0847 FB                 1925 	mov	r3,a
   0848 BB 01 0B           1926 	cjne	r3,#0x01,00133$
                           1927 ;	../fb_app_out.c:298: delay_state=0x80;
   084B 7C 80              1928 	mov	r4,#0x80
                           1929 ;	../fb_app_out.c:299: delay_onoff=eeprom[objno+0xE2];
   084D 74 E2              1930 	mov	a,#0xE2
   084F 2F                 1931 	add	a,r7
   0850 90 1D 00           1932 	mov	dptr,#_eeprom
   0853 93                 1933 	movc	a,@a+dptr
   0854 FB                 1934 	mov	r3,a
   0855 FD                 1935 	mov	r5,a
   0856                    1936 00133$:
                           1937 ;	../fb_app_out.c:301: if (((eeprom[RELMODE]>>objno)&0x01)==0x00) portbuffer=portbuffer|(0x01<<objno);	// sofort einschalten (Schliesserbetrieb)
   0856 90 1D F2           1938 	mov	dptr,#(_eeprom + 0x00f2)
   0859 E4                 1939 	clr	a
   085A 93                 1940 	movc	a,@a+dptr
   085B FB                 1941 	mov	r3,a
   085C 8F F0              1942 	mov	b,r7
   085E 05 F0              1943 	inc	b
   0860 EB                 1944 	mov	a,r3
   0861 80 02              1945 	sjmp	00296$
   0863                    1946 00295$:
   0863 C3                 1947 	clr	c
   0864 13                 1948 	rrc	a
   0865                    1949 00296$:
   0865 D5 F0 FB           1950 	djnz	b,00295$
   0868 20 E0 12           1951 	jb	acc.0,00135$
   086B 8F F0              1952 	mov	b,r7
   086D 05 F0              1953 	inc	b
   086F 74 01              1954 	mov	a,#0x01
   0871 80 02              1955 	sjmp	00300$
   0873                    1956 00298$:
   0873 25 E0              1957 	add	a,acc
   0875                    1958 00300$:
   0875 D5 F0 FB           1959 	djnz	b,00298$
   0878 FB                 1960 	mov	r3,a
   0879 42 3A              1961 	orl	_portbuffer,a
   087B 80 15              1962 	sjmp	00141$
   087D                    1963 00135$:
                           1964 ;	../fb_app_out.c:302: else portbuffer=portbuffer&~(0x01<<objno);					// sofort einschalten (�ffnerbetrieb)
   087D 8F F0              1965 	mov	b,r7
   087F 05 F0              1966 	inc	b
   0881 74 01              1967 	mov	a,#0x01
   0883 80 02              1968 	sjmp	00303$
   0885                    1969 00301$:
   0885 25 E0              1970 	add	a,acc
   0887                    1971 00303$:
   0887 D5 F0 FB           1972 	djnz	b,00301$
   088A F4                 1973 	cpl	a
   088B FB                 1974 	mov	r3,a
   088C 52 3A              1975 	anl	_portbuffer,a
   088E 80 02              1976 	sjmp	00141$
   0890                    1977 00138$:
                           1978 ;	../fb_app_out.c:304: else delay_state=0x11;				// verz�gert einschalten
   0890 7C 11              1979 	mov	r4,#0x11
   0892                    1980 00141$:
                           1981 ;	../fb_app_out.c:307: if(delay_state!=0) {				// wenn Verz�gerung, dann timer-Wert ins Flash schreiben  
   0892 EC                 1982 	mov	a,r4
   0893 60 14              1983 	jz	00150$
                           1984 ;	../fb_app_out.c:308: timercnt[objno]=delay_onoff|0x80;//delay_target=(delay_onoff<<delay_base)+timer;
   0895 EF                 1985 	mov	a,r7
   0896 24 2C              1986 	add	a,#_timercnt
   0898 F9                 1987 	mov	r1,a
   0899 74 80              1988 	mov	a,#0x80
   089B 4D                 1989 	orl	a,r5
   089C F7                 1990 	mov	@r1,a
                           1991 ;	../fb_app_out.c:309: timerbase[objno]=delay_base|(delay_state & 0xF0);//write_delay_record(objno,delay_state,delay_target);
   089D EF                 1992 	mov	a,r7
   089E 24 24              1993 	add	a,#_timerbase
   08A0 F9                 1994 	mov	r1,a
   08A1 53 04 F0           1995 	anl	ar4,#0xF0
   08A4 EC                 1996 	mov	a,r4
   08A5 4E                 1997 	orl	a,r6
   08A6 F7                 1998 	mov	@r1,a
   08A7 80 06              1999 	sjmp	00159$
   08A9                    2000 00150$:
                           2001 ;	../fb_app_out.c:311: else timercnt[objno]= 0;//clear_delay_record(objno);    
   08A9 EF                 2002 	mov	a,r7
   08AA 24 2C              2003 	add	a,#_timercnt
   08AC F8                 2004 	mov	r0,a
   08AD 76 00              2005 	mov	@r0,#0x00
   08AF                    2006 00159$:
   08AF 85 08 81           2007 	mov	sp,_bp
   08B2 D0 08              2008 	pop	_bp
   08B4 22                 2009 	ret
                           2010 ;------------------------------------------------------------
                           2011 ;Allocation info for local variables in function 'delay_timer'
                           2012 ;------------------------------------------------------------
                           2013 ;objno                     Allocated to registers r7 
                           2014 ;port_pattern              Allocated to registers r6 
                           2015 ;delay_zeit                Allocated to registers r5 
                           2016 ;delay_onoff               Allocated to registers r3 
                           2017 ;delay_base                Allocated to registers r4 
                           2018 ;n                         Allocated to registers r5 
                           2019 ;m                         Allocated to registers r4 
                           2020 ;timerflags                Allocated to registers r6 r7 
                           2021 ;ledport                   Allocated to registers r6 
                           2022 ;Tasten                    Allocated to registers r7 
                           2023 ;------------------------------------------------------------
                           2024 ;	../fb_app_out.c:318: void delay_timer(void)	// z�hlt alle 65ms die Variable Timer hoch und pr�ft Queue
                           2025 ;	-----------------------------------------
                           2026 ;	 function delay_timer
                           2027 ;	-----------------------------------------
   08B5                    2028 _delay_timer:
                           2029 ;	../fb_app_out.c:329: RTCCON=0x60;		// RTC anhalten und Flag l�schen
   08B5 75 D1 60           2030 	mov	_RTCCON,#0x60
                           2031 ;	../fb_app_out.c:330: RTCH=0x0E;			// reload Real Time Clock
   08B8 75 D2 0E           2032 	mov	_RTCH,#0x0E
                           2033 ;	../fb_app_out.c:331: RTCL=0xA0;
   08BB 75 D3 A0           2034 	mov	_RTCL,#0xA0
                           2035 ;	../fb_app_out.c:334: timer++;
   08BE 05 34              2036 	inc	_timer
   08C0 E4                 2037 	clr	a
   08C1 B5 34 02           2038 	cjne	a,_timer,00212$
   08C4 05 35              2039 	inc	(_timer + 1)
   08C6                    2040 00212$:
                           2041 ;	../fb_app_out.c:335: timerflags = timer&(~(timer-1));
   08C6 E5 34              2042 	mov	a,_timer
   08C8 24 FF              2043 	add	a,#0xFF
   08CA FE                 2044 	mov	r6,a
   08CB E5 35              2045 	mov	a,(_timer + 1)
   08CD 34 FF              2046 	addc	a,#0xFF
   08CF FF                 2047 	mov	r7,a
   08D0 EE                 2048 	mov	a,r6
   08D1 F4                 2049 	cpl	a
   08D2 FE                 2050 	mov	r6,a
   08D3 EF                 2051 	mov	a,r7
   08D4 F4                 2052 	cpl	a
   08D5 FF                 2053 	mov	r7,a
   08D6 E5 34              2054 	mov	a,_timer
   08D8 52 06              2055 	anl	ar6,a
   08DA E5 35              2056 	mov	a,(_timer + 1)
   08DC 52 07              2057 	anl	ar7,a
                           2058 ;	../fb_app_out.c:336: for(n=0;n<16;n++){
   08DE 7D 00              2059 	mov	r5,#0x00
   08E0                    2060 00143$:
   08E0 BD 10 00           2061 	cjne	r5,#0x10,00213$
   08E3                    2062 00213$:
   08E3 50 32              2063 	jnc	00146$
                           2064 ;	../fb_app_out.c:337: if(timerflags & 0x0001){// positive flags erzeugen und schieben
   08E5 EE                 2065 	mov	a,r6
   08E6 30 E0 24           2066 	jnb	acc.0,00106$
                           2067 ;	../fb_app_out.c:338: for(m=0;m<TIMERANZ;m++){// die timer der reihe nach checken und dec wenn laufen
   08E9 7C 00              2068 	mov	r4,#0x00
   08EB                    2069 00139$:
   08EB BC 08 00           2070 	cjne	r4,#0x08,00216$
   08EE                    2071 00216$:
   08EE 50 1D              2072 	jnc	00106$
                           2073 ;	../fb_app_out.c:339: if ((timerbase[m]& 0x0F)==n){// wenn die base mit der gespeicherten base �bereinstimmt
   08F0 EC                 2074 	mov	a,r4
   08F1 24 24              2075 	add	a,#_timerbase
   08F3 F9                 2076 	mov	r1,a
   08F4 87 03              2077 	mov	ar3,@r1
   08F6 53 03 0F           2078 	anl	ar3,#0x0F
   08F9 EB                 2079 	mov	a,r3
   08FA B5 05 0D           2080 	cjne	a,ar5,00141$
                           2081 ;	../fb_app_out.c:340: if (timercnt[m]>0x80){// wenn der counter l�uft...
   08FD EC                 2082 	mov	a,r4
   08FE 24 2C              2083 	add	a,#_timercnt
   0900 F9                 2084 	mov	r1,a
   0901 E7                 2085 	mov	a,@r1
   0902 FB                 2086 	mov	r3,a
   0903 24 7F              2087 	add	a,#0xff - 0x80
   0905 50 03              2088 	jnc	00141$
                           2089 ;	../fb_app_out.c:341: timercnt[m]=timercnt[m]-1;// den timer [m]decrementieren
   0907 EB                 2090 	mov	a,r3
   0908 14                 2091 	dec	a
   0909 F7                 2092 	mov	@r1,a
   090A                    2093 00141$:
                           2094 ;	../fb_app_out.c:338: for(m=0;m<TIMERANZ;m++){// die timer der reihe nach checken und dec wenn laufen
   090A 0C                 2095 	inc	r4
   090B 80 DE              2096 	sjmp	00139$
   090D                    2097 00106$:
                           2098 ;	../fb_app_out.c:346: timerflags = timerflags>>1;
   090D EF                 2099 	mov	a,r7
   090E C3                 2100 	clr	c
   090F 13                 2101 	rrc	a
   0910 CE                 2102 	xch	a,r6
   0911 13                 2103 	rrc	a
   0912 CE                 2104 	xch	a,r6
   0913 FF                 2105 	mov	r7,a
                           2106 ;	../fb_app_out.c:336: for(n=0;n<16;n++){
   0914 0D                 2107 	inc	r5
   0915 80 C9              2108 	sjmp	00143$
   0917                    2109 00146$:
                           2110 ;	../fb_app_out.c:351: for(objno=0;objno<=7;objno++) {
   0917 7F 00              2111 	mov	r7,#0x00
   0919                    2112 00147$:
   0919 EF                 2113 	mov	a,r7
   091A 24 F8              2114 	add	a,#0xff - 0x07
   091C 50 03              2115 	jnc	00221$
   091E 02 09 F4           2116 	ljmp	00150$
   0921                    2117 00221$:
                           2118 ;	../fb_app_out.c:357: if(timercnt[objno]==0x80) {			// 0x00 = delay Eintrag ist leer   
   0921 EF                 2119 	mov	a,r7
   0922 24 2C              2120 	add	a,#_timercnt
   0924 F9                 2121 	mov	r1,a
   0925 87 06              2122 	mov	ar6,@r1
   0927 BE 80 02           2123 	cjne	r6,#0x80,00222$
   092A 80 03              2124 	sjmp	00223$
   092C                    2125 00222$:
   092C 02 09 F0           2126 	ljmp	00149$
   092F                    2127 00223$:
                           2128 ;	../fb_app_out.c:359: portchanged=1;
   092F D2 01              2129 	setb	_portchanged
                           2130 ;	../fb_app_out.c:360: port_pattern=0x01<<objno;
   0931 8F F0              2131 	mov	b,r7
   0933 05 F0              2132 	inc	b
   0935 74 01              2133 	mov	a,#0x01
   0937 80 02              2134 	sjmp	00226$
   0939                    2135 00224$:
   0939 25 E0              2136 	add	a,acc
   093B                    2137 00226$:
   093B D5 F0 FB           2138 	djnz	b,00224$
   093E FE                 2139 	mov	r6,a
                           2140 ;	../fb_app_out.c:361: if(timerbase[objno]&0x10) { //if(delay_state==0x81) {	// einschalten
   093F EF                 2141 	mov	a,r7
   0940 24 24              2142 	add	a,#_timerbase
   0942 F9                 2143 	mov	r1,a
   0943 E7                 2144 	mov	a,@r1
   0944 FD                 2145 	mov	r5,a
   0945 20 E4 03           2146 	jb	acc.4,00227$
   0948 02 09 CB           2147 	ljmp	00122$
   094B                    2148 00227$:
                           2149 ;	../fb_app_out.c:362: if (((eeprom[RELMODE]>>objno)&0x01)==0x00) {				
   094B 90 1D F2           2150 	mov	dptr,#(_eeprom + 0x00f2)
   094E E4                 2151 	clr	a
   094F 93                 2152 	movc	a,@a+dptr
   0950 FD                 2153 	mov	r5,a
   0951 8F F0              2154 	mov	b,r7
   0953 05 F0              2155 	inc	b
   0955 ED                 2156 	mov	a,r5
   0956 80 02              2157 	sjmp	00229$
   0958                    2158 00228$:
   0958 C3                 2159 	clr	c
   0959 13                 2160 	rrc	a
   095A                    2161 00229$:
   095A D5 F0 FB           2162 	djnz	b,00228$
   095D 20 E0 05           2163 	jb	acc.0,00108$
                           2164 ;	../fb_app_out.c:363: portbuffer=portbuffer|port_pattern;		// Einschalten (Schliesserbetrieb)
   0960 EE                 2165 	mov	a,r6
   0961 42 3A              2166 	orl	_portbuffer,a
   0963 80 05              2167 	sjmp	00109$
   0965                    2168 00108$:
                           2169 ;	../fb_app_out.c:366: portbuffer=portbuffer&~port_pattern;	// Einschalten (�ffnerbetrieb)
   0965 EE                 2170 	mov	a,r6
   0966 F4                 2171 	cpl	a
   0967 FD                 2172 	mov	r5,a
   0968 52 3A              2173 	anl	_portbuffer,a
   096A                    2174 00109$:
                           2175 ;	../fb_app_out.c:368: timercnt[objno]=0;//delrec[objno*4]=0;
   096A EF                 2176 	mov	a,r7
   096B 24 2C              2177 	add	a,#_timercnt
   096D F8                 2178 	mov	r0,a
   096E 76 00              2179 	mov	@r0,#0x00
                           2180 ;	../fb_app_out.c:370: delay_zeit=eeprom[0xEA];
   0970 90 1D EA           2181 	mov	dptr,#(_eeprom + 0x00ea)
   0973 E4                 2182 	clr	a
   0974 93                 2183 	movc	a,@a+dptr
   0975 FD                 2184 	mov	r5,a
                           2185 ;	../fb_app_out.c:371: delay_zeit=((delay_zeit>>objno)&0x01);
   0976 8F F0              2186 	mov	b,r7
   0978 05 F0              2187 	inc	b
   097A ED                 2188 	mov	a,r5
   097B 80 02              2189 	sjmp	00232$
   097D                    2190 00231$:
   097D C3                 2191 	clr	c
   097E 13                 2192 	rrc	a
   097F                    2193 00232$:
   097F D5 F0 FB           2194 	djnz	b,00231$
   0982 FC                 2195 	mov	r4,a
   0983 74 01              2196 	mov	a,#0x01
   0985 5C                 2197 	anl	a,r4
   0986 FD                 2198 	mov	r5,a
                           2199 ;	../fb_app_out.c:372: if(delay_zeit==0x01) {
   0987 BD 01 66           2200 	cjne	r5,#0x01,00149$
                           2201 ;	../fb_app_out.c:373: delay_base=eeprom[(((objno+1)>>1)+0xF9)];   
   098A 8F 03              2202 	mov	ar3,r7
   098C 7C 00              2203 	mov	r4,#0x00
   098E 0B                 2204 	inc	r3
   098F BB 00 01           2205 	cjne	r3,#0x00,00235$
   0992 0C                 2206 	inc	r4
   0993                    2207 00235$:
   0993 EC                 2208 	mov	a,r4
   0994 A2 E7              2209 	mov	c,acc.7
   0996 13                 2210 	rrc	a
   0997 CB                 2211 	xch	a,r3
   0998 13                 2212 	rrc	a
   0999 CB                 2213 	xch	a,r3
   099A 74 F9              2214 	mov	a,#0xF9
   099C 2B                 2215 	add	a,r3
   099D 90 1D 00           2216 	mov	dptr,#_eeprom
   09A0 93                 2217 	movc	a,@a+dptr
   09A1 FC                 2218 	mov	r4,a
                           2219 ;	../fb_app_out.c:374: if((objno&0x01)==0x01) delay_base&=0x0F;
   09A2 74 01              2220 	mov	a,#0x01
   09A4 5F                 2221 	anl	a,r7
   09A5 FB                 2222 	mov	r3,a
   09A6 BB 01 05           2223 	cjne	r3,#0x01,00111$
   09A9 53 04 0F           2224 	anl	ar4,#0x0F
   09AC 80 08              2225 	sjmp	00112$
   09AE                    2226 00111$:
                           2227 ;	../fb_app_out.c:375: else delay_base=(delay_base&0xF0)>>4;
   09AE 74 F0              2228 	mov	a,#0xF0
   09B0 5C                 2229 	anl	a,r4
   09B1 FB                 2230 	mov	r3,a
   09B2 C4                 2231 	swap	a
   09B3 54 0F              2232 	anl	a,#0x0F
   09B5 FC                 2233 	mov	r4,a
   09B6                    2234 00112$:
                           2235 ;	../fb_app_out.c:376: delay_onoff=eeprom[objno+0xE2];
   09B6 74 E2              2236 	mov	a,#0xE2
   09B8 2F                 2237 	add	a,r7
   09B9 90 1D 00           2238 	mov	dptr,#_eeprom
   09BC 93                 2239 	movc	a,@a+dptr
                           2240 ;	../fb_app_out.c:377: if (delay_onoff!=0x00 && delay_zeit!=0x00) {  
   09BD FB                 2241 	mov	r3,a
   09BE 60 30              2242 	jz	00149$
   09C0 ED                 2243 	mov	a,r5
   09C1 60 2D              2244 	jz	00149$
                           2245 ;	../fb_app_out.c:378: timercnt[objno]=delay_onoff|0x80;//delay_target=(delay_onoff<<delay_base)+timer;
   09C3 74 80              2246 	mov	a,#0x80
   09C5 4B                 2247 	orl	a,r3
   09C6 F6                 2248 	mov	@r0,a
                           2249 ;	../fb_app_out.c:379: timerbase[objno]=delay_base;//write_delay_record(objno,0x80,delay_target);		// Schaltverz�gerung in Flash schreiben
   09C7 A7 04              2250 	mov	@r1,ar4
   09C9 80 25              2251 	sjmp	00149$
   09CB                    2252 00122$:
                           2253 ;	../fb_app_out.c:386: if (((eeprom[RELMODE]>>objno)&0x01)==0x00) {
   09CB 90 1D F2           2254 	mov	dptr,#(_eeprom + 0x00f2)
   09CE E4                 2255 	clr	a
   09CF 93                 2256 	movc	a,@a+dptr
   09D0 FD                 2257 	mov	r5,a
   09D1 8F F0              2258 	mov	b,r7
   09D3 05 F0              2259 	inc	b
   09D5 ED                 2260 	mov	a,r5
   09D6 80 02              2261 	sjmp	00241$
   09D8                    2262 00240$:
   09D8 C3                 2263 	clr	c
   09D9 13                 2264 	rrc	a
   09DA                    2265 00241$:
   09DA D5 F0 FB           2266 	djnz	b,00240$
   09DD 20 E0 07           2267 	jb	acc.0,00119$
                           2268 ;	../fb_app_out.c:387: portbuffer=portbuffer&~port_pattern;		// Ausschalten (Schliesserbetrieb)
   09E0 EE                 2269 	mov	a,r6
   09E1 F4                 2270 	cpl	a
   09E2 FD                 2271 	mov	r5,a
   09E3 52 3A              2272 	anl	_portbuffer,a
   09E5 80 03              2273 	sjmp	00120$
   09E7                    2274 00119$:
                           2275 ;	../fb_app_out.c:390: portbuffer=portbuffer|port_pattern;			// Ausschalten (�ffnerbetrieb)
   09E7 EE                 2276 	mov	a,r6
   09E8 42 3A              2277 	orl	_portbuffer,a
   09EA                    2278 00120$:
                           2279 ;	../fb_app_out.c:392: timercnt[objno]=0;//delrec[objno*4]=0;
   09EA EF                 2280 	mov	a,r7
   09EB 24 2C              2281 	add	a,#_timercnt
   09ED F8                 2282 	mov	r0,a
   09EE 76 00              2283 	mov	@r0,#0x00
   09F0                    2284 00149$:
                           2285 ;	../fb_app_out.c:351: for(objno=0;objno<=7;objno++) {
   09F0 0F                 2286 	inc	r7
   09F1 02 09 19           2287 	ljmp	00147$
   09F4                    2288 00150$:
                           2289 ;	../fb_app_out.c:401: if((TMOD&0x0F)==0x02 && fb_state==0) {
   09F4 74 0F              2290 	mov	a,#0x0F
   09F6 55 89              2291 	anl	a,_TMOD
   09F8 FF                 2292 	mov	r7,a
   09F9 BF 02 56           2293 	cjne	r7,#0x02,00137$
   09FC E5 69              2294 	mov	a,_fb_state
   09FE 70 52              2295 	jnz	00137$
                           2296 ;	../fb_app_out.c:402: ET1=0;
   0A00 C2 AB              2297 	clr	_IEN0_3
                           2298 ;	../fb_app_out.c:410: while( (TMOD&0x0F)==0x02 && ( TL0>0x72));// PWM scannen um "Hand"-Tasten abzufragen
   0A02                    2299 00127$:
   0A02 74 0F              2300 	mov	a,#0x0F
   0A04 55 89              2301 	anl	a,_TMOD
   0A06 FF                 2302 	mov	r7,a
   0A07 BF 02 06           2303 	cjne	r7,#0x02,00129$
   0A0A E5 8A              2304 	mov	a,_TL0
   0A0C 24 8D              2305 	add	a,#0xff - 0x72
   0A0E 40 F2              2306 	jc	00127$
   0A10                    2307 00129$:
                           2308 ;	../fb_app_out.c:413: interrupted=0;	  
   0A10 C2 03              2309 	clr	_interrupted
                           2310 ;	../fb_app_out.c:414: Tasten=0;				
   0A12 7F 00              2311 	mov	r7,#0x00
                           2312 ;	../fb_app_out.c:431: ledport=0x01;
   0A14 7E 01              2313 	mov	r6,#0x01
                           2314 ;	../fb_app_out.c:432: for (n=0;n<4;n++) {  						
   0A16 7D 00              2315 	mov	r5,#0x00
   0A18                    2316 00151$:
   0A18 BD 04 00           2317 	cjne	r5,#0x04,00249$
   0A1B                    2318 00249$:
   0A1B 50 14              2319 	jnc	00154$
                           2320 ;	../fb_app_out.c:433: P0=~ledport;
   0A1D EE                 2321 	mov	a,r6
   0A1E F4                 2322 	cpl	a
   0A1F F5 80              2323 	mov	_P0,a
                           2324 ;	../fb_app_out.c:434: P0_5=1;			//P0.5 auf 1, wird �ber Dioden und taster auf low IO gezogen.
   0A21 D2 85              2325 	setb	_P0_5
                           2326 ;	../fb_app_out.c:435: if (!P0_5){
   0A23 20 85 05           2327 	jb	_P0_5,00131$
                           2328 ;	../fb_app_out.c:436: Tasten=Tasten|ledport;
   0A26 EE                 2329 	mov	a,r6
   0A27 42 07              2330 	orl	ar7,a
                           2331 ;	../fb_app_out.c:438: n=3;
   0A29 7D 03              2332 	mov	r5,#0x03
   0A2B                    2333 00131$:
                           2334 ;	../fb_app_out.c:440: ledport=ledport<<1;
   0A2B EE                 2335 	mov	a,r6
   0A2C 2E                 2336 	add	a,r6
   0A2D FE                 2337 	mov	r6,a
                           2338 ;	../fb_app_out.c:432: for (n=0;n<4;n++) {  						
   0A2E 0D                 2339 	inc	r5
   0A2F 80 E7              2340 	sjmp	00151$
   0A31                    2341 00154$:
                           2342 ;	../fb_app_out.c:445: REFRESH;
   0A31 85 3B 80           2343 	mov	_P0,_oldportbuffer
                           2344 ;	../fb_app_out.c:447: if (Tasten != Tval)  {
   0A34 EF                 2345 	mov	a,r7
   0A35 B5 36 02           2346 	cjne	a,_Tval,00252$
   0A38 80 16              2347 	sjmp	00135$
   0A3A                    2348 00252$:
                           2349 ;	../fb_app_out.c:448: portbuffer=oldportbuffer;
   0A3A 85 3B 3A           2350 	mov	_portbuffer,_oldportbuffer
                           2351 ;	../fb_app_out.c:449: ledport=Tasten&~Tval; // ledport ist hier die Hilfsvariable f�r steigende Flanke
   0A3D E5 36              2352 	mov	a,_Tval
   0A3F F4                 2353 	cpl	a
   0A40 FD                 2354 	mov	r5,a
   0A41 EF                 2355 	mov	a,r7
   0A42 52 05              2356 	anl	ar5,a
   0A44 8D 06              2357 	mov	ar6,r5
                           2358 ;	../fb_app_out.c:450: if (ledport){
   0A46 EE                 2359 	mov	a,r6
   0A47 60 05              2360 	jz	00133$
                           2361 ;	../fb_app_out.c:451: portbuffer^=ledport; // bei gedr�ckter Taste toggeln
   0A49 EE                 2362 	mov	a,r6
   0A4A 62 3A              2363 	xrl	_portbuffer,a
                           2364 ;	../fb_app_out.c:452: portchanged=1;
   0A4C D2 01              2365 	setb	_portchanged
   0A4E                    2366 00133$:
                           2367 ;	../fb_app_out.c:454: Tval=Tasten;			//neue Tasten sichern
   0A4E 8F 36              2368 	mov	_Tval,r7
   0A50                    2369 00135$:
                           2370 ;	../fb_app_out.c:456: ET1=1;
   0A50 D2 AB              2371 	setb	_IEN0_3
   0A52                    2372 00137$:
                           2373 ;	../fb_app_out.c:460: RTCCON=0x61;		// RTC starten
   0A52 75 D1 61           2374 	mov	_RTCCON,#0x61
   0A55 22                 2375 	ret
                           2376 ;------------------------------------------------------------
                           2377 ;Allocation info for local variables in function 'port_schalten'
                           2378 ;------------------------------------------------------------
                           2379 ;n                         Allocated to registers r7 
                           2380 ;pattern                   Allocated to registers r6 
                           2381 ;------------------------------------------------------------
                           2382 ;	../fb_app_out.c:524: void port_schalten(void)		// Schaltet die Ports mit PWM, DUTY ist Pulsverh�ltnis
                           2383 ;	-----------------------------------------
                           2384 ;	 function port_schalten
                           2385 ;	-----------------------------------------
   0A56                    2386 _port_schalten:
                           2387 ;	../fb_app_out.c:590: if(portbuffer & ~oldportbuffer) {	// Vollstrom nur wenn ein relais eingeschaltet wird
   0A56 AE 3B              2388 	mov	r6,_oldportbuffer
   0A58 7F 00              2389 	mov	r7,#0x00
   0A5A EE                 2390 	mov	a,r6
   0A5B F4                 2391 	cpl	a
   0A5C FE                 2392 	mov	r6,a
   0A5D EF                 2393 	mov	a,r7
   0A5E F4                 2394 	cpl	a
   0A5F FF                 2395 	mov	r7,a
   0A60 AC 3A              2396 	mov	r4,_portbuffer
   0A62 7D 00              2397 	mov	r5,#0x00
   0A64 EC                 2398 	mov	a,r4
   0A65 52 06              2399 	anl	ar6,a
   0A67 ED                 2400 	mov	a,r5
   0A68 52 07              2401 	anl	ar7,a
   0A6A EE                 2402 	mov	a,r6
   0A6B 4F                 2403 	orl	a,r7
   0A6C 60 1F              2404 	jz	00102$
                           2405 ;	../fb_app_out.c:591: TR0=0;
   0A6E C2 8C              2406 	clr	_TCON_4
                           2407 ;	../fb_app_out.c:592: AUXR1&=0xE9;	// PWM von Timer 0 nicht mehr auf Pin ausgeben
   0A70 53 A2 E9           2408 	anl	_AUXR1,#0xE9
                           2409 ;	../fb_app_out.c:595: PWM=0;			// Vollstrom an
   0A73 C2 92              2410 	clr	_P1_2
                           2411 ;	../fb_app_out.c:597: P0=portbuffer;		// Ports schalten
   0A75 85 3A 80           2412 	mov	_P0,_portbuffer
                           2413 ;	../fb_app_out.c:598: TF0=0;			// Timer 0 f�r Haltezeit Vollstrom verwenden
   0A78 C2 8D              2414 	clr	_TCON_5
                           2415 ;	../fb_app_out.c:599: TH0=0x00;		// 16ms (10ms=6fff)
                           2416 ;	../fb_app_out.c:600: TL0=0x00;
                           2417 ;	../fb_app_out.c:601: TMOD=(TMOD & 0xF0) +1;		// Timer 0 als 16-Bit Timer
   0A7A E4                 2418 	clr	a
   0A7B F5 8C              2419 	mov	_TH0,a
   0A7D F5 8A              2420 	mov	_TL0,a
   0A7F 74 F0              2421 	mov	a,#0xF0
   0A81 55 89              2422 	anl	a,_TMOD
   0A83 04                 2423 	inc	a
   0A84 F5 89              2424 	mov	_TMOD,a
                           2425 ;	../fb_app_out.c:602: TAMOD=0x00;
   0A86 75 8F 00           2426 	mov	_TAMOD,#0x00
                           2427 ;	../fb_app_out.c:603: TR0=1;
   0A89 D2 8C              2428 	setb	_TCON_4
   0A8B 80 03              2429 	sjmp	00103$
   0A8D                    2430 00102$:
                           2431 ;	../fb_app_out.c:605: else P0=portbuffer;
   0A8D 85 3A 80           2432 	mov	_P0,_portbuffer
   0A90                    2433 00103$:
                           2434 ;	../fb_app_out.c:607: rm_state=portbuffer ^ eeprom[RMINV];	// R�ckmeldeobjekte setzen
   0A90 90 1D F3           2435 	mov	dptr,#(_eeprom + 0x00f3)
   0A93 E4                 2436 	clr	a
   0A94 93                 2437 	movc	a,@a+dptr
   0A95 65 3A              2438 	xrl	a,_portbuffer
   0A97 F5 38              2439 	mov	_rm_state,a
                           2440 ;	../fb_app_out.c:614: for (n=0;n<4;n++) {	// R�ckmeldung wenn ein Ausgag sich ge�ndert hat
   0A99 7F 00              2441 	mov	r7,#0x00
   0A9B                    2442 00106$:
   0A9B BF 04 00           2443 	cjne	r7,#0x04,00122$
   0A9E                    2444 00122$:
   0A9E 50 21              2445 	jnc	00109$
                           2446 ;	../fb_app_out.c:615: pattern=1<<n;
   0AA0 8F F0              2447 	mov	b,r7
   0AA2 05 F0              2448 	inc	b
   0AA4 74 01              2449 	mov	a,#0x01
   0AA6 80 02              2450 	sjmp	00126$
   0AA8                    2451 00124$:
   0AA8 25 E0              2452 	add	a,acc
   0AAA                    2453 00126$:
   0AAA D5 F0 FB           2454 	djnz	b,00124$
                           2455 ;	../fb_app_out.c:616: if((portbuffer&pattern)!=(oldportbuffer&pattern)) rm_send|=pattern;		//send_obj_value(n+12);
   0AAD FE                 2456 	mov	r6,a
   0AAE 55 3A              2457 	anl	a,_portbuffer
   0AB0 FD                 2458 	mov	r5,a
   0AB1 EE                 2459 	mov	a,r6
   0AB2 55 3B              2460 	anl	a,_oldportbuffer
   0AB4 FC                 2461 	mov	r4,a
   0AB5 ED                 2462 	mov	a,r5
   0AB6 B5 04 02           2463 	cjne	a,ar4,00127$
   0AB9 80 03              2464 	sjmp	00108$
   0ABB                    2465 00127$:
   0ABB EE                 2466 	mov	a,r6
   0ABC 42 3E              2467 	orl	_rm_send,a
   0ABE                    2468 00108$:
                           2469 ;	../fb_app_out.c:614: for (n=0;n<4;n++) {	// R�ckmeldung wenn ein Ausgag sich ge�ndert hat
   0ABE 0F                 2470 	inc	r7
   0ABF 80 DA              2471 	sjmp	00106$
   0AC1                    2472 00109$:
                           2473 ;	../fb_app_out.c:619: oldportbuffer=portbuffer;
   0AC1 85 3A 3B           2474 	mov	_oldportbuffer,_portbuffer
                           2475 ;	../fb_app_out.c:620: portchanged=0;
   0AC4 C2 01              2476 	clr	_portchanged
   0AC6 22                 2477 	ret
                           2478 ;------------------------------------------------------------
                           2479 ;Allocation info for local variables in function 'sort_output'
                           2480 ;------------------------------------------------------------
                           2481 ;portbuffer                Allocated to registers r7 
                           2482 ;diff                      Allocated to registers r6 
                           2483 ;result                    Allocated to registers r4 r5 
                           2484 ;------------------------------------------------------------
                           2485 ;	../fb_app_out.c:626: unsigned int sort_output(unsigned char portbuffer){
                           2486 ;	-----------------------------------------
                           2487 ;	 function sort_output
                           2488 ;	-----------------------------------------
   0AC7                    2489 _sort_output:
   0AC7 AF 82              2490 	mov	r7,dpl
                           2491 ;	../fb_app_out.c:629: diff=portbuffer ^ oldportbuffer;
   0AC9 E5 3B              2492 	mov	a,_oldportbuffer
   0ACB 6F                 2493 	xrl	a,r7
   0ACC FE                 2494 	mov	r6,a
                           2495 ;	../fb_app_out.c:630: result=0;
                           2496 ;	../fb_app_out.c:632: if (diff & 0x01){
   0ACD E4                 2497 	clr	a
   0ACE FC                 2498 	mov	r4,a
   0ACF FD                 2499 	mov	r5,a
   0AD0 EE                 2500 	mov	a,r6
   0AD1 30 E0 0E           2501 	jnb	acc.0,00105$
                           2502 ;	../fb_app_out.c:633: if(portbuffer & 0x01){
   0AD4 EF                 2503 	mov	a,r7
   0AD5 30 E0 06           2504 	jnb	acc.0,00102$
                           2505 ;	../fb_app_out.c:634: result|=0x1000;
   0AD8 7C 00              2506 	mov	r4,#0x00
   0ADA 7D 10              2507 	mov	r5,#0x10
   0ADC 80 04              2508 	sjmp	00105$
   0ADE                    2509 00102$:
                           2510 ;	../fb_app_out.c:637: result|=0x2000;
   0ADE 7C 00              2511 	mov	r4,#0x00
   0AE0 7D 20              2512 	mov	r5,#0x20
   0AE2                    2513 00105$:
                           2514 ;	../fb_app_out.c:642: if (diff & 0x02){
   0AE2 EE                 2515 	mov	a,r6
   0AE3 30 E1 0C           2516 	jnb	acc.1,00110$
                           2517 ;	../fb_app_out.c:643: if(portbuffer & 0x02){
   0AE6 EF                 2518 	mov	a,r7
   0AE7 30 E1 05           2519 	jnb	acc.1,00107$
                           2520 ;	../fb_app_out.c:644: result|=0x0004;
   0AEA 43 04 04           2521 	orl	ar4,#0x04
   0AED 80 03              2522 	sjmp	00110$
   0AEF                    2523 00107$:
                           2524 ;	../fb_app_out.c:647: result|=0x0008;
   0AEF 43 04 08           2525 	orl	ar4,#0x08
   0AF2                    2526 00110$:
                           2527 ;	../fb_app_out.c:651: if (diff & 0x04){
   0AF2 EE                 2528 	mov	a,r6
   0AF3 30 E2 0C           2529 	jnb	acc.2,00115$
                           2530 ;	../fb_app_out.c:652: if(portbuffer & 0x04){
   0AF6 EF                 2531 	mov	a,r7
   0AF7 30 E2 05           2532 	jnb	acc.2,00112$
                           2533 ;	../fb_app_out.c:653: result|=0x4000;
   0AFA 43 05 40           2534 	orl	ar5,#0x40
   0AFD 80 03              2535 	sjmp	00115$
   0AFF                    2536 00112$:
                           2537 ;	../fb_app_out.c:656: result|=0x8000;
   0AFF 43 05 80           2538 	orl	ar5,#0x80
   0B02                    2539 00115$:
                           2540 ;	../fb_app_out.c:660: if (diff & 0x08){
   0B02 EE                 2541 	mov	a,r6
   0B03 30 E3 0C           2542 	jnb	acc.3,00120$
                           2543 ;	../fb_app_out.c:661: if(portbuffer & 0x08){
   0B06 EF                 2544 	mov	a,r7
   0B07 30 E3 05           2545 	jnb	acc.3,00117$
                           2546 ;	../fb_app_out.c:662: result|=0x0001;
   0B0A 43 04 01           2547 	orl	ar4,#0x01
   0B0D 80 03              2548 	sjmp	00120$
   0B0F                    2549 00117$:
                           2550 ;	../fb_app_out.c:665: result|=0x0002;
   0B0F 43 04 02           2551 	orl	ar4,#0x02
   0B12                    2552 00120$:
                           2553 ;	../fb_app_out.c:670: if (diff & 0x10){
   0B12 EE                 2554 	mov	a,r6
   0B13 30 E4 0C           2555 	jnb	acc.4,00125$
                           2556 ;	../fb_app_out.c:671: if(portbuffer & 0x10){
   0B16 EF                 2557 	mov	a,r7
   0B17 30 E4 05           2558 	jnb	acc.4,00122$
                           2559 ;	../fb_app_out.c:672: result|=0x0040;
   0B1A 43 04 40           2560 	orl	ar4,#0x40
   0B1D 80 03              2561 	sjmp	00125$
   0B1F                    2562 00122$:
                           2563 ;	../fb_app_out.c:675: result|=0x0080;
   0B1F 43 04 80           2564 	orl	ar4,#0x80
   0B22                    2565 00125$:
                           2566 ;	../fb_app_out.c:679: if (diff & 0x20){
   0B22 EE                 2567 	mov	a,r6
   0B23 30 E5 0C           2568 	jnb	acc.5,00130$
                           2569 ;	../fb_app_out.c:680: if(portbuffer & 0x20){
   0B26 EF                 2570 	mov	a,r7
   0B27 30 E5 05           2571 	jnb	acc.5,00127$
                           2572 ;	../fb_app_out.c:681: result|=0x0100;
   0B2A 43 05 01           2573 	orl	ar5,#0x01
   0B2D 80 03              2574 	sjmp	00130$
   0B2F                    2575 00127$:
                           2576 ;	../fb_app_out.c:684: result|=0x0200;
   0B2F 43 05 02           2577 	orl	ar5,#0x02
   0B32                    2578 00130$:
                           2579 ;	../fb_app_out.c:689: if (diff & 0x40){
   0B32 EE                 2580 	mov	a,r6
   0B33 30 E6 0C           2581 	jnb	acc.6,00135$
                           2582 ;	../fb_app_out.c:690: if(portbuffer & 0x40){
   0B36 EF                 2583 	mov	a,r7
   0B37 30 E6 05           2584 	jnb	acc.6,00132$
                           2585 ;	../fb_app_out.c:691: result|=0x0010;
   0B3A 43 04 10           2586 	orl	ar4,#0x10
   0B3D 80 03              2587 	sjmp	00135$
   0B3F                    2588 00132$:
                           2589 ;	../fb_app_out.c:694: result|=0x0020;
   0B3F 43 04 20           2590 	orl	ar4,#0x20
   0B42                    2591 00135$:
                           2592 ;	../fb_app_out.c:698: if (diff & 0x80){
   0B42 EE                 2593 	mov	a,r6
   0B43 30 E7 0C           2594 	jnb	acc.7,00140$
                           2595 ;	../fb_app_out.c:699: if(portbuffer & 0x80){
   0B46 EF                 2596 	mov	a,r7
   0B47 30 E7 05           2597 	jnb	acc.7,00137$
                           2598 ;	../fb_app_out.c:700: result|=0x0400;
   0B4A 43 05 04           2599 	orl	ar5,#0x04
   0B4D 80 03              2600 	sjmp	00140$
   0B4F                    2601 00137$:
                           2602 ;	../fb_app_out.c:703: result|=0x0800;
   0B4F 43 05 08           2603 	orl	ar5,#0x08
   0B52                    2604 00140$:
                           2605 ;	../fb_app_out.c:706: return result;
   0B52 8C 82              2606 	mov	dpl,r4
   0B54 8D 83              2607 	mov	dph,r5
   0B56 22                 2608 	ret
                           2609 ;------------------------------------------------------------
                           2610 ;Allocation info for local variables in function 'spi_2_out'
                           2611 ;------------------------------------------------------------
                           2612 ;daten                     Allocated to registers r6 r7 
                           2613 ;n                         Allocated to registers r6 
                           2614 ;unten                     Allocated to registers r4 
                           2615 ;mitte                     Allocated to registers r7 
                           2616 ;------------------------------------------------------------
                           2617 ;	../fb_app_out.c:711: void spi_2_out(unsigned int daten){
                           2618 ;	-----------------------------------------
                           2619 ;	 function spi_2_out
                           2620 ;	-----------------------------------------
   0B57                    2621 _spi_2_out:
   0B57 AE 82              2622 	mov	r6,dpl
   0B59 AF 83              2623 	mov	r7,dph
                           2624 ;	../fb_app_out.c:715: unten=daten & 0xFF;
   0B5B 8E 04              2625 	mov	ar4,r6
   0B5D 7D 00              2626 	mov	r5,#0x00
                           2627 ;	../fb_app_out.c:716: mitte=daten>>8;
                           2628 ;	../fb_app_out.c:718: WRITE=0;
   0B5F C2 82              2629 	clr	_P0_2
                           2630 ;	../fb_app_out.c:719: CLK=0;
   0B61 C2 83              2631 	clr	_P0_3
                           2632 ;	../fb_app_out.c:720: for(n=0;n<=7;n++){
   0B63 7E 00              2633 	mov	r6,#0x00
   0B65                    2634 00101$:
   0B65 EE                 2635 	mov	a,r6
   0B66 24 F8              2636 	add	a,#0xff - 0x07
   0B68 40 22              2637 	jc	00104$
                           2638 ;	../fb_app_out.c:723: BOT_OUT=(unten & 0x080)>>7;
   0B6A 74 80              2639 	mov	a,#0x80
   0B6C 5C                 2640 	anl	a,r4
   0B6D 23                 2641 	rl	a
   0B6E 54 01              2642 	anl	a,#0x01
   0B70 24 FF              2643 	add	a,#0xff
   0B72 92 80              2644 	mov	_P0_0,c
                           2645 ;	../fb_app_out.c:724: unten<<=1;
   0B74 EC                 2646 	mov	a,r4
   0B75 2C                 2647 	add	a,r4
   0B76 FC                 2648 	mov	r4,a
                           2649 ;	../fb_app_out.c:726: MID_OUT=(mitte & 0x080)>>7;
   0B77 74 80              2650 	mov	a,#0x80
   0B79 5F                 2651 	anl	a,r7
   0B7A 23                 2652 	rl	a
   0B7B 54 01              2653 	anl	a,#0x01
   0B7D FD                 2654 	mov	r5,a
   0B7E 24 FF              2655 	add	a,#0xff
   0B80 92 81              2656 	mov	_P0_1,c
                           2657 ;	../fb_app_out.c:727: mitte<<=1;
   0B82 EF                 2658 	mov	a,r7
   0B83 2F                 2659 	add	a,r7
   0B84 FF                 2660 	mov	r7,a
                           2661 ;	../fb_app_out.c:729: CLK=1;
   0B85 D2 83              2662 	setb	_P0_3
                           2663 ;	../fb_app_out.c:730: CLK=0;
   0B87 C2 83              2664 	clr	_P0_3
                           2665 ;	../fb_app_out.c:720: for(n=0;n<=7;n++){
   0B89 0E                 2666 	inc	r6
   0B8A 80 D9              2667 	sjmp	00101$
   0B8C                    2668 00104$:
                           2669 ;	../fb_app_out.c:734: WRITE=1;
   0B8C D2 82              2670 	setb	_P0_2
                           2671 ;	../fb_app_out.c:736: WRITE=0;
   0B8E C2 82              2672 	clr	_P0_2
   0B90 22                 2673 	ret
                           2674 ;------------------------------------------------------------
                           2675 ;Allocation info for local variables in function 'bus_return'
                           2676 ;------------------------------------------------------------
                           2677 ;n                         Allocated to registers r6 
                           2678 ;bw                        Allocated to registers r7 
                           2679 ;bwh                       Allocated to registers r5 
                           2680 ;pattern                   Allocated to registers r6 
                           2681 ;------------------------------------------------------------
                           2682 ;	../fb_app_out.c:745: void bus_return(void)		// Aktionen bei Busspannungswiederkehr
                           2683 ;	-----------------------------------------
                           2684 ;	 function bus_return
                           2685 ;	-----------------------------------------
   0B91                    2686 _bus_return:
                           2687 ;	../fb_app_out.c:749: portbuffer=eeprom[PORTSAVE];	// Verhalten nach Busspannungs-Wiederkehr
   0B91 90 1D 99           2688 	mov	dptr,#(_eeprom + 0x0099)
   0B94 E4                 2689 	clr	a
   0B95 93                 2690 	movc	a,@a+dptr
   0B96 F5 3A              2691 	mov	_portbuffer,a
                           2692 ;	../fb_app_out.c:751: bw=eeprom[0xF6];
   0B98 90 1D F6           2693 	mov	dptr,#(_eeprom + 0x00f6)
   0B9B E4                 2694 	clr	a
   0B9C 93                 2695 	movc	a,@a+dptr
   0B9D FF                 2696 	mov	r7,a
                           2697 ;	../fb_app_out.c:752: for(n=0;n<=3;n++) {			// Ausg�nge 1-4
   0B9E 7E 00              2698 	mov	r6,#0x00
   0BA0                    2699 00107$:
   0BA0 EE                 2700 	mov	a,r6
   0BA1 24 FC              2701 	add	a,#0xff - 0x03
   0BA3 40 46              2702 	jc	00110$
                           2703 ;	../fb_app_out.c:753: bwh=(bw>>(2*n))&0x03;
   0BA5 EE                 2704 	mov	a,r6
   0BA6 75 F0 02           2705 	mov	b,#0x02
   0BA9 A4                 2706 	mul	ab
   0BAA FC                 2707 	mov	r4,a
   0BAB AD F0              2708 	mov	r5,b
   0BAD 8C F0              2709 	mov	b,r4
   0BAF 05 F0              2710 	inc	b
   0BB1 EF                 2711 	mov	a,r7
   0BB2 80 02              2712 	sjmp	00135$
   0BB4                    2713 00134$:
   0BB4 C3                 2714 	clr	c
   0BB5 13                 2715 	rrc	a
   0BB6                    2716 00135$:
   0BB6 D5 F0 FB           2717 	djnz	b,00134$
   0BB9 FC                 2718 	mov	r4,a
   0BBA 74 03              2719 	mov	a,#0x03
   0BBC 5C                 2720 	anl	a,r4
   0BBD FD                 2721 	mov	r5,a
                           2722 ;	../fb_app_out.c:754: if(bwh==0x01)  portbuffer=portbuffer & (0xFF-(0x01<<n));
   0BBE BD 01 14           2723 	cjne	r5,#0x01,00102$
   0BC1 8E F0              2724 	mov	b,r6
   0BC3 05 F0              2725 	inc	b
   0BC5 74 01              2726 	mov	a,#0x01
   0BC7 80 02              2727 	sjmp	00140$
   0BC9                    2728 00138$:
   0BC9 25 E0              2729 	add	a,acc
   0BCB                    2730 00140$:
   0BCB D5 F0 FB           2731 	djnz	b,00138$
   0BCE FC                 2732 	mov	r4,a
   0BCF 74 FF              2733 	mov	a,#0xFF
   0BD1 C3                 2734 	clr	c
   0BD2 9C                 2735 	subb	a,r4
   0BD3 52 3A              2736 	anl	_portbuffer,a
   0BD5                    2737 00102$:
                           2738 ;	../fb_app_out.c:755: if(bwh==0x02)  portbuffer=portbuffer | (0x01<<n);
   0BD5 BD 02 10           2739 	cjne	r5,#0x02,00109$
   0BD8 8E F0              2740 	mov	b,r6
   0BDA 05 F0              2741 	inc	b
   0BDC 74 01              2742 	mov	a,#0x01
   0BDE 80 02              2743 	sjmp	00145$
   0BE0                    2744 00143$:
   0BE0 25 E0              2745 	add	a,acc
   0BE2                    2746 00145$:
   0BE2 D5 F0 FB           2747 	djnz	b,00143$
   0BE5 FD                 2748 	mov	r5,a
   0BE6 42 3A              2749 	orl	_portbuffer,a
   0BE8                    2750 00109$:
                           2751 ;	../fb_app_out.c:752: for(n=0;n<=3;n++) {			// Ausg�nge 1-4
   0BE8 0E                 2752 	inc	r6
   0BE9 80 B5              2753 	sjmp	00107$
   0BEB                    2754 00110$:
                           2755 ;	../fb_app_out.c:767: oldportbuffer=0; 	// auf 0 setzen, da sonst kein Vollstrom aktiviert wird
   0BEB 75 3B 00           2756 	mov	_oldportbuffer,#0x00
                           2757 ;	../fb_app_out.c:768: portchanged=1;		// Post hinterlegen damit in delaytimer nach portschalten springt
   0BEE D2 01              2758 	setb	_portchanged
                           2759 ;	../fb_app_out.c:771: rm_state=portbuffer ^ eeprom[RMINV];	// R�ckmeldeobjekte setzen
   0BF0 90 1D F3           2760 	mov	dptr,#(_eeprom + 0x00f3)
   0BF3 E4                 2761 	clr	a
   0BF4 93                 2762 	movc	a,@a+dptr
   0BF5 65 3A              2763 	xrl	a,_portbuffer
   0BF7 F5 38              2764 	mov	_rm_state,a
                           2765 ;	../fb_app_out.c:776: for (n=0;n<8;n++) {	// R�ckmeldung nur f�r Objekte mit Wert 0, da Wert 1 in normalem port_schalten eh gesendet wird
   0BF9 7F 00              2766 	mov	r7,#0x00
   0BFB                    2767 00111$:
   0BFB BF 08 00           2768 	cjne	r7,#0x08,00146$
   0BFE                    2769 00146$:
   0BFE 50 33              2770 	jnc	00115$
                           2771 ;	../fb_app_out.c:777: pattern=1<<n;
   0C00 8F F0              2772 	mov	b,r7
   0C02 05 F0              2773 	inc	b
   0C04 74 01              2774 	mov	a,#0x01
   0C06 80 02              2775 	sjmp	00150$
   0C08                    2776 00148$:
   0C08 25 E0              2777 	add	a,acc
   0C0A                    2778 00150$:
   0C0A D5 F0 FB           2779 	djnz	b,00148$
   0C0D FE                 2780 	mov	r6,a
                           2781 ;	../fb_app_out.c:778: if((~portbuffer)&pattern) send_obj_value(n+12);
   0C0E AC 3A              2782 	mov	r4,_portbuffer
   0C10 7D 00              2783 	mov	r5,#0x00
   0C12 EC                 2784 	mov	a,r4
   0C13 F4                 2785 	cpl	a
   0C14 FC                 2786 	mov	r4,a
   0C15 ED                 2787 	mov	a,r5
   0C16 F4                 2788 	cpl	a
   0C17 FD                 2789 	mov	r5,a
   0C18 7B 00              2790 	mov	r3,#0x00
   0C1A EE                 2791 	mov	a,r6
   0C1B 52 04              2792 	anl	ar4,a
   0C1D EB                 2793 	mov	a,r3
   0C1E 52 05              2794 	anl	ar5,a
   0C20 EC                 2795 	mov	a,r4
   0C21 4D                 2796 	orl	a,r5
   0C22 60 0C              2797 	jz	00113$
   0C24 74 0C              2798 	mov	a,#0x0C
   0C26 2F                 2799 	add	a,r7
   0C27 F5 82              2800 	mov	dpl,a
   0C29 C0 07              2801 	push	ar7
   0C2B 12 15 CC           2802 	lcall	_send_obj_value
   0C2E D0 07              2803 	pop	ar7
   0C30                    2804 00113$:
                           2805 ;	../fb_app_out.c:776: for (n=0;n<8;n++) {	// R�ckmeldung nur f�r Objekte mit Wert 0, da Wert 1 in normalem port_schalten eh gesendet wird
   0C30 0F                 2806 	inc	r7
   0C31 80 C8              2807 	sjmp	00111$
   0C33                    2808 00115$:
   0C33 22                 2809 	ret
                           2810 ;------------------------------------------------------------
                           2811 ;Allocation info for local variables in function 'restart_app'
                           2812 ;------------------------------------------------------------
                           2813 ;	../fb_app_out.c:783: void restart_app(void) 		// Alle Applikations-Parameter zur�cksetzen
                           2814 ;	-----------------------------------------
                           2815 ;	 function restart_app
                           2816 ;	-----------------------------------------
   0C34                    2817 _restart_app:
                           2818 ;	../fb_app_out.c:786: Tval=0x00;
   0C34 75 36 00           2819 	mov	_Tval,#0x00
                           2820 ;	../fb_app_out.c:788: P0=0;
   0C37 75 80 00           2821 	mov	_P0,#0x00
                           2822 ;	../fb_app_out.c:789: P0M1=0x00;		// Port 0 Modus push-pull f�r Ausgang
   0C3A 75 84 00           2823 	mov	_P0M1,#0x00
                           2824 ;	../fb_app_out.c:794: P0M2= 0x0F;
   0C3D 75 85 0F           2825 	mov	_P0M2,#0x0F
                           2826 ;	../fb_app_out.c:801: TMOD=(TMOD & 0xF0) + 2;		// Timer 0 als PWM
   0C40 74 F0              2827 	mov	a,#0xF0
   0C42 55 89              2828 	anl	a,_TMOD
   0C44 24 02              2829 	add	a,#0x02
   0C46 F5 89              2830 	mov	_TMOD,a
                           2831 ;	../fb_app_out.c:802: TAMOD=0x01;
   0C48 75 8F 01           2832 	mov	_TAMOD,#0x01
                           2833 ;	../fb_app_out.c:803: TH0=DUTY;		// Pulsverh�ltnis PWM
   0C4B 75 8C 50           2834 	mov	_TH0,#0x50
                           2835 ;	../fb_app_out.c:804: AUXR1|=0x10;	// PWM von Timer 0 auf Pin ausgeben, gleichzeitig low-powermode ein (da <8MHz)
   0C4E 43 A2 10           2836 	orl	_AUXR1,#0x10
                           2837 ;	../fb_app_out.c:805: TR0=1;			// Timer 0 starten (PWM)
   0C51 D2 8C              2838 	setb	_TCON_4
                           2839 ;	../fb_app_out.c:810: ET0=0;			// Interrupt f�r Timer 0 sperren
   0C53 C2 A9              2840 	clr	_IEN0_1
                           2841 ;	../fb_app_out.c:811: IT0=1;
   0C55 D2 88              2842 	setb	_TCON_0
                           2843 ;	../fb_app_out.c:812: zf_state=0x00;		// Zustand der Zusatzfunktionen 1-4
   0C57 75 39 00           2844 	mov	_zf_state,#0x00
                           2845 ;	../fb_app_out.c:813: blocked=0x00;		// Ausg�nge nicht gesperrt
                           2846 ;	../fb_app_out.c:814: timer=0;			// Timer-Variable, wird alle 130ms inkrementiert
                           2847 ;	../fb_app_out.c:816: logicstate=0;
   0C5A E4                 2848 	clr	a
   0C5B F5 3C              2849 	mov	_blocked,a
   0C5D F5 34              2850 	mov	_timer,a
   0C5F F5 35              2851 	mov	(_timer + 1),a
   0C61 F5 3D              2852 	mov	_logicstate,a
                           2853 ;	../fb_app_out.c:817: delay_toggle=0;
   0C63 C2 00              2854 	clr	_delay_toggle
                           2855 ;	../fb_app_out.c:819: EA=0;						// Interrupts sperren, damit flashen nicht unterbrochen wird
   0C65 C2 AF              2856 	clr	_IEN0_7
                           2857 ;	../fb_app_out.c:820: START_WRITECYCLE
   0C67 75 E4 00           2858 	mov	_FMCON,#0x00
                           2859 ;	../fb_app_out.c:821: WRITE_BYTE(0x01,0x03,0x00)	// Herstellercode 0x0004 = Jung
   0C6A 75 E7 1D           2860 	mov	_FMADRH,#0x1D
   0C6D 75 E6 03           2861 	mov	_FMADRL,#0x03
   0C70 75 E5 00           2862 	mov	_FMDATA,#0x00
                           2863 ;	../fb_app_out.c:822: WRITE_BYTE(0x01,0x04,0x04)
   0C73 75 E7 1D           2864 	mov	_FMADRH,#0x1D
   0C76 75 E6 04           2865 	mov	_FMADRL,#0x04
   0C79 75 E5 04           2866 	mov	_FMDATA,#0x04
                           2867 ;	../fb_app_out.c:828: WRITE_BYTE(0x01,0x05,0x20)	// Devicetype 0x2062 = Jung Aktor 2134.16
   0C7C 75 E7 1D           2868 	mov	_FMADRH,#0x1D
   0C7F 75 E6 05           2869 	mov	_FMADRL,#0x05
   0C82 75 E5 20           2870 	mov	_FMDATA,#0x20
                           2871 ;	../fb_app_out.c:829: WRITE_BYTE(0x01,0x06,0x62)
   0C85 75 E7 1D           2872 	mov	_FMADRH,#0x1D
   0C88 75 E6 06           2873 	mov	_FMADRL,#0x06
   0C8B 75 E5 62           2874 	mov	_FMDATA,#0x62
                           2875 ;	../fb_app_out.c:831: WRITE_BYTE(0x01,0x07,0x01)	// Versionnumber of application programm
   0C8E 75 E7 1D           2876 	mov	_FMADRH,#0x1D
   0C91 75 E6 07           2877 	mov	_FMADRL,#0x07
   0C94 75 E5 01           2878 	mov	_FMDATA,#0x01
                           2879 ;	../fb_app_out.c:832: WRITE_BYTE(0x01,0x0C,0x00)	// PORT A Direction Bit Setting
   0C97 75 E7 1D           2880 	mov	_FMADRH,#0x1D
   0C9A 75 E6 0C           2881 	mov	_FMADRL,#0x0C
   0C9D 75 E5 00           2882 	mov	_FMDATA,#0x00
                           2883 ;	../fb_app_out.c:833: WRITE_BYTE(0x01,0x0D,0xFF)	// Run-Status (00=stop FF=run)
   0CA0 75 E7 1D           2884 	mov	_FMADRH,#0x1D
   0CA3 75 E6 0D           2885 	mov	_FMADRL,#0x0D
   0CA6 75 E5 FF           2886 	mov	_FMDATA,#0xFF
                           2887 ;	../fb_app_out.c:834: WRITE_BYTE(0x01,0x12,0x9A)	// COMMSTAB Pointer
   0CA9 75 E7 1D           2888 	mov	_FMADRH,#0x1D
   0CAC 75 E6 12           2889 	mov	_FMADRL,#0x12
   0CAF 75 E5 9A           2890 	mov	_FMDATA,#0x9A
                           2891 ;	../fb_app_out.c:835: STOP_WRITECYCLE
   0CB2 75 E4 68           2892 	mov	_FMCON,#0x68
                           2893 ;	../fb_app_out.c:836: EA=1;						// Interrupts freigeben
   0CB5 D2 AF              2894 	setb	_IEN0_7
   0CB7 22                 2895 	ret
                           2896 	.area CSEG    (CODE)
                           2897 	.area CONST   (CODE)
                           2898 	.area XINIT   (CODE)
                           2899 	.area CABS    (ABS,CODE)
